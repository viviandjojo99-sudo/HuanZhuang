package com.jojo.dressup;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class DressUpPickActivity extends Activity {
    static String callbackObject = "ButtonInput";
    static String callbackMethod = "OnAndroidFilePicked";
    static boolean allowPng;
    boolean opened;

    public static void open(Activity activity, String objectName, String methodName, boolean png) {
        callbackObject = objectName;
        callbackMethod = methodName;
        allowPng = png;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    activity.startActivity(new Intent(activity, DressUpPickActivity.class));
                } catch (Exception exception) {
                    tell("error:打不开文件选择");
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (opened)
            return;
        opened = true;
        launchPicker();
    }

    void launchPicker() {
        try {
            startActivityForResult(documentIntent(Intent.ACTION_OPEN_DOCUMENT), 1);
        } catch (Exception first) {
            try {
                startActivityForResult(documentIntent(Intent.ACTION_GET_CONTENT), 1);
            } catch (Exception second) {
                tell("error:打不开文件选择");
                finish();
            }
        }
    }

    Intent documentIntent(String action) {
        Intent intent = new Intent(action);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
            "application/octet-stream",
            "image/vnd.adobe.photoshop",
            "image/png",
            "*/*"
        });
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 1 || resultCode != RESULT_OK || data == null || data.getData() == null) {
            tell("");
            finish();
            return;
        }

        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String message;
                try {
                    message = copy(uri);
                } catch (Exception exception) {
                    message = "error:读不到这个文件";
                }
                final String sent = message;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tell(sent);
                        finish();
                    }
                });
            }
        }).start();
    }

    String copy(Uri uri) throws Exception {
        File dir = getCacheDir();
        File out = new File(dir, "dressup-import-" + System.currentTimeMillis() + ".bin");
        InputStream input = getContentResolver().openInputStream(uri);
        if (input == null)
            return "error:读不到这个文件";
        try {
            FileOutputStream output = new FileOutputStream(out);
            try {
                byte[] buffer = new byte[1024 * 64];
                int read;
                while ((read = input.read(buffer)) > 0)
                    output.write(buffer, 0, read);
            } finally {
                output.close();
            }
        } finally {
            input.close();
        }

        String kind = sniff(out, displayName(uri));
        if (kind == null) {
            out.delete();
            return allowPng ? "error:请选 psd 或 png。" : "error:请选 psd 文件。";
        }

        File named = new File(dir, "dressup-import-" + System.currentTimeMillis() + "." + kind);
        if (!out.renameTo(named))
            return out.getAbsolutePath();
        return named.getAbsolutePath();
    }

    String sniff(File file, String name) throws Exception {
        byte[] header = new byte[8];
        int count = 0;
        FileInputStream input = new FileInputStream(file);
        try {
            count = input.read(header);
        } finally {
            input.close();
        }

        if (count >= 4 && header[0] == '8' && header[1] == 'B' && header[2] == 'P' && header[3] == 'S')
            return "psd";
        if (count >= 4 && (header[0] & 0xff) == 0x89 && header[1] == 'P' && header[2] == 'N' && header[3] == 'G')
            return allowPng ? "png" : null;

        String lower = name == null ? "" : name.toLowerCase();
        if (lower.endsWith(".psd"))
            return "psd";
        if (allowPng && lower.endsWith(".png"))
            return "png";
        return null;
    }

    static void tell(String message) {
        try {
            Class<?> player = Class.forName("com.unity3d.player.UnityPlayer");
            player.getMethod("UnitySendMessage", String.class, String.class, String.class)
                .invoke(null, callbackObject, callbackMethod, message);
        } catch (Exception ignored) {
        }
    }

    String displayName(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor == null)
            return "";
        try {
            int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (index >= 0 && cursor.moveToFirst()) {
                String name = cursor.getString(index);
                if (name != null)
                    return name;
            }
        } finally {
            cursor.close();
        }
        return "";
    }
}
