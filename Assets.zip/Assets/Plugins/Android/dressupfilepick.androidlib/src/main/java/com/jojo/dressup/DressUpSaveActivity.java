package com.jojo.dressup;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

public class DressUpSaveActivity extends Activity {
    static String callbackObject = "";
    static String callbackMethod = "";
    static String sourcePath = "";
    static String displayName = "export.png";
    boolean opened;

    public static void saveToGallery(Activity activity, String objectName, String methodName, String path, String name) {
        callbackObject = objectName;
        callbackMethod = methodName;
        sourcePath = path;
        if (name != null && name.length() > 0)
            displayName = name;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String message;
                try {
                    if (Build.VERSION.SDK_INT >= 29)
                        message = insertGallery(activity);
                    else
                        message = "picker";
                } catch (Exception exception) {
                    message = "error:保存失败";
                }
                if ("picker".equals(message)) {
                    open(activity, callbackObject, callbackMethod, sourcePath, displayName);
                    Toast.makeText(activity, "请选择保存位置", Toast.LENGTH_SHORT).show();
                    return;
                }
                deleteSource();
                if (message != null && message.startsWith("ok:"))
                    Toast.makeText(activity, "已保存到相册", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(activity, "保存失败", Toast.LENGTH_SHORT).show();
                tell(message);
            }
        });
    }

    static String insertGallery(Activity activity) throws Exception {
        File source = new File(sourcePath);
        if (!source.isFile())
            return "error:没有可保存的图片";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/赛博衣柜安");
        values.put(MediaStore.Images.Media.IS_PENDING, 1);
        Uri uri = activity.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null)
            return "picker";
        try {
            OutputStream output = activity.getContentResolver().openOutputStream(uri);
            if (output == null)
                throw new Exception("open");
            FileInputStream input = new FileInputStream(source);
            try {
                byte[] buffer = new byte[1024 * 64];
                int read;
                while ((read = input.read(buffer)) > 0)
                    output.write(buffer, 0, read);
            } finally {
                input.close();
                output.close();
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            activity.getContentResolver().update(uri, values, null, null);
            return "ok:" + displayName;
        } catch (Exception exception) {
            activity.getContentResolver().delete(uri, null, null);
            throw exception;
        }
    }

    public static void open(Activity activity, String objectName, String methodName, String path, String name) {
        callbackObject = objectName;
        callbackMethod = methodName;
        sourcePath = path;
        if (name != null && name.length() > 0)
            displayName = name;
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    activity.startActivity(new Intent(activity, DressUpSaveActivity.class));
                } catch (Exception exception) {
                    tell("error:打不开保存");
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (opened)
            return;
        opened = true;
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_TITLE, displayName);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, 1);
        } catch (Exception exception) {
            deleteSource();
            tell("error:打不开保存");
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 1 || resultCode != RESULT_OK || data == null || data.getData() == null) {
            deleteSource();
            tell("");
            finish();
            return;
        }

        final Uri uri = data.getData();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String message;
                try {
                    message = write(uri);
                } catch (Exception exception) {
                    message = "error:保存失败";
                }
                deleteSource();
                final String sent = message;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (sent != null && sent.startsWith("ok:"))
                            Toast.makeText(DressUpSaveActivity.this, "已保存", Toast.LENGTH_SHORT).show();
                        tell(sent);
                        finish();
                    }
                });
            }
        }).start();
    }

    String write(Uri uri) throws Exception {
        File source = new File(sourcePath);
        if (!source.isFile())
            return "error:没有可保存的图片";
        OutputStream output = getContentResolver().openOutputStream(uri);
        if (output == null)
            return "error:保存失败";
        FileInputStream input = new FileInputStream(source);
        try {
            byte[] buffer = new byte[1024 * 64];
            int read;
            while ((read = input.read(buffer)) > 0)
                output.write(buffer, 0, read);
        } finally {
            input.close();
            output.close();
        }
        return "ok:" + displayName;
    }

    static void deleteSource() {
        try {
            if (sourcePath != null && sourcePath.length() > 0)
                new File(sourcePath).delete();
        } catch (Exception ignored) {
        }
    }

    static void tell(String message) {
        try {
            Class<?> player = Class.forName("com.unity3d.player.UnityPlayer");
            player.getMethod("UnitySendMessage", String.class, String.class, String.class)
                .invoke(null, callbackObject, callbackMethod, message == null ? "" : message);
        } catch (Exception ignored) {
        }
    }
}
