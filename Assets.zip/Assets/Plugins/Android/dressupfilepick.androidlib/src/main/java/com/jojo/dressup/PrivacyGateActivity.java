package com.jojo.dressup;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 启动入口。用户同意之前不启动 Unity，因此不会初始化引擎，也不会读取传感器列表。
 */
public class PrivacyGateActivity extends Activity {
    static final String PREFS = "privacy_gate";
    static final String KEY_AGREED = "agreed";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (hasAgreed()) {
            startGame();
            return;
        }
        setContentView(buildUi());
    }

    boolean hasAgreed() {
        return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_AGREED, false);
    }

    void agree() {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
        editor.putBoolean(KEY_AGREED, true);
        editor.commit();
        startGame();
    }

    void refuse() {
        finishAffinity();
    }

    void startGame() {
        Intent intent = new Intent();
        intent.setClassName(getPackageName(), "com.unity3d.player.UnityPlayerGameActivity");
        startActivity(intent);
        finish();
    }

    View buildUi() {
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("隐私政策");
        title.setTextColor(Color.BLACK);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title, matchWrap());

        TextView summary = new TextView(this);
        summary.setText("目的：在本机运行换装游戏，并在您主动选择时读取选中的图片。\n方式：只在设备本地处理，不上传个人信息。\n范围：点击「同意」后才启动游戏引擎，引擎会读取一次传感器类型列表；导入图片时只读取您选中的文件。点击「拒绝」将退出，不初始化引擎、不读取传感器、不采集设备信息。拒绝后退出，下次启动会再次展示本政策。");
        summary.setTextColor(0xFF222222);
        summary.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        summary.setLineSpacing(dp(2), 1f);
        summary.setPadding(0, 0, 0, dp(12));
        root.addView(summary, matchWrap());

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        TextView body = new TextView(this);
        body.setText(readPolicy());
        body.setTextColor(0xFF333333);
        body.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        body.setLineSpacing(dp(3), 1f);
        scroll.addView(body, new ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(scroll, scrollParams);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(16), 0, dp(4));

        Button refuse = new Button(this);
        refuse.setText("拒绝");
        refuse.setAllCaps(false);
        refuse.setMinWidth(dp(120));
        refuse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refuse();
            }
        });
        Button agree = new Button(this);
        agree.setText("同意");
        agree.setAllCaps(false);
        agree.setMinWidth(dp(120));
        agree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agree();
            }
        });

        View gap = new View(this);
        LinearLayout.LayoutParams gapParams = new LinearLayout.LayoutParams(0, 0, 1f);
        row.addView(refuse, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)));
        row.addView(gap, gapParams);
        row.addView(agree, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52)));
        root.addView(row, matchWrap());
        return root;
    }

    static final String POLICY =
        "更新日期：【2026年11月14日】\n\n" +
        "告知：请您在点击「同意」前阅读本政策。目的：在您的设备上运行换装游戏，并在您主动选择时读取您选中的本地图片。方式：仅在设备本地处理，不上传个人信息。范围：您同意并启动游戏引擎后，引擎会读取一次传感器类型列表；您主动导入图片时，读取您选中的文件。点击「拒绝」将退出，且不会初始化游戏引擎、不会读取传感器、不会采集设备信息。拒绝后退出，下次启动会再次展示本政策。点击「同意」后才进入。\n\n" +
        "一、运营主体与联系方式\n" +
        "本游戏《赛博衣柜安》（以下称“本游戏”）由【赛博凌月娘】开发和运营。如对本政策有任何疑问，可通过【262804512@qq.com】与我们联系。\n\n" +
        "二、我们收集的信息与用途\n" +
        "本游戏为单机游戏，不设账号注册，不需要您提供姓名、手机号等身份信息。我们不会主动收集、上传您的个人信息。\n\n" +
        "首次启动时，我们以弹窗明示上述目的、方式和范围。只有您点击「同意」之后，才会初始化游戏引擎并进入游戏。同意之前不读取传感器列表，不采集设备信息。启动时不申请任何权限。\n\n" +
        "您同意后，游戏引擎为识别本机是否具备加速度计、陀螺仪等输入传感器，会在每次启动且您已同意后读取一次传感器类型列表，不持续读取。本游戏不使用陀螺仪、加速度计玩法，已关闭加速度计采样，也不上传该列表。\n\n" +
        "三、本地文件访问说明\n" +
        "导入 PSD 或 PNG 时，通过系统文件选择器由您主动选择一个文件。本游戏只在设备本地读取并处理您选中的这一个文件，仅用于在游戏内展示与编辑；该文件不会上传至服务器，也不会提供给任何第三方。除您主动选择的文件外，本游戏不会读取设备上的其他文件。\n\n" +
        "四、权限申请说明\n" +
        "启动时不申请任何权限。本安装包声明的系统权限只有网络权限（android.permission.INTERNET），在安装时由系统授予，启动时不会弹出权限申请框，本游戏不使用该权限上传您的个人信息。\n" +
        "本安装包未声明存储、定位、相机、麦克风、通讯录、电话状态权限。导入文件不申请存储权限，只通过系统文件选择器由您主动选择。传感器类型列表的读取发生在您点击同意并启动引擎之后，由游戏引擎在本地完成。\n\n" +
        "五、信息的共享、转让与公开披露\n" +
        "我们不会将您的信息共享、转让或公开披露给任何第三方。游戏引擎读取的传感器类型列表只留在设备本地，不向第三方提供。\n\n" +
        "六、信息的存储与保存期限\n" +
        "本游戏不将您的文件上传至服务器，因此不涉及服务器端的保存。设备本地的文件由您自行管理，删除游戏或相应文件后即不再保留于本游戏可访问范围内。是否已同意本政策，仅保存在您的设备本地，用于下次启动时不再重复询问；卸载游戏后即删除。\n\n" +
        "七、您的权利\n" +
        "您可以点击「拒绝」。拒绝后游戏退出，不初始化引擎，不读取传感器。下次启动会再次展示本政策。您也可以随时停止使用相关功能、删除本地文件，或卸载本游戏。\n\n" +
        "八、未成年人保护\n" +
        "如您是未成年人，请在监护人指导下阅读本政策并使用本游戏。如您不满14周岁，本游戏不收集您的个人信息，请在监护人同意并指导下使用。\n\n" +
        "九、政策更新\n" +
        "本政策如有变更，我们会在本页面更新并标注更新日期。重大变更将以显著方式提示。\n\n" +
        "十、接入第三方 SDK 情况说明\n" +
        "以下为会涉及个人信息处理的第三方 SDK。本游戏未接入统计、广告、登录、支付、推送类 SDK。\n\n" +
        "SDK 名称：Unity 引擎\n" +
        "开发者名称（全称）：Unity Technologies S.F.\n" +
        "使用目的：提供游戏运行、画面渲染和触控输入所需的引擎能力。\n" +
        "使用场景：您点击同意并进入游戏之后，用于衣柜展示、换装和本地导入图片。\n" +
        "调用权限说明：不向系统申请存储、定位、相机、麦克风、通讯录、电话状态权限。安装包声明网络权限（android.permission.INTERNET），安装时由系统授予，不用于上传个人信息。您同意后，引擎在本地读取传感器类型列表。导入图片通过系统文件选择器由您主动选择，不申请存储权限。\n" +
        "个人信息收集类型及方式：您同意并启动引擎时，在设备本地读取传感器类型列表。不收集姓名、手机号、通讯录、精确位置、短信和设备唯一标识，也不上传该列表。本游戏未启用 Unity 的广告、统计、内购和崩溃上报。\n" +
        "隐私政策链接：https://unity.com/legal/game-player-and-app-user-privacy-policy\n" +
        "频次时机：每次启动且您已同意后读取一次，不持续读取。\n";

    String readPolicy() {
        return POLICY;
    }

    int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    static LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT);
    }
}
