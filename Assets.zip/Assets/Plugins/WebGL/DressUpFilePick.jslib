mergeInto(LibraryManager.library, {
  $dressUpFilePick: {
    android: function () {
      return /Android/i.test(navigator.userAgent);
    },

    element: function () {
      var input = document.getElementById("dressup-file-input");
      if (input)
        return input;

      input = document.createElement("input");
      input.id = "dressup-file-input";
      input.type = "file";
      input.style.cssText = "display:none;position:fixed;z-index:50;margin:0;padding:0;opacity:0;font-size:16px;border:0;pointer-events:none;touch-action:manipulation;width:0;height:0;";
      input.addEventListener("change", function (event) { dressUpFilePick.read(event); });
      document.body.appendChild(input);
      if (!dressUpFilePick.bound) {
        dressUpFilePick.bound = true;
        var openFromPoint = function () {
          return;
        };
        document.addEventListener("touchend", function (event) {
          var touch = event.changedTouches && event.changedTouches[0];
          if (touch)
            openFromPoint(touch.clientX, touch.clientY, event);
        }, true);
        document.addEventListener("pointerup", function (event) {
          if (event.pointerType === "mouse")
            return;
          openFromPoint(event.clientX, event.clientY, event);
        }, true);
      }
      return input;
    },

    place: function (input, x, y, w, h) {
      var canvas = document.querySelector("#unity-canvas");
      if (!canvas || !canvas.width || !canvas.height)
        return;

      var rect = canvas.getBoundingClientRect();
      var scaleX = rect.width / canvas.width;
      var scaleY = rect.height / canvas.height;
      input.style.left = (rect.left + x * scaleX) + "px";
      input.style.top = (rect.top + (canvas.height - (y + h)) * scaleY) + "px";
      input.style.width = Math.max(w * scaleX, 1) + "px";
      input.style.height = Math.max(h * scaleY, 1) + "px";
    },

    read: function (event) {
      var input = event.target;
      var file = input.files && input.files[0];
      var objectName = input.dataset.object;
      var methodName = input.dataset.method;
      input.value = "";
      if (!file || !objectName || !methodName)
        return;

      input.dataset.reading = "1";
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var data = new Uint8Array(reader.result);
          var name = file.name || "";
          var dot = name.lastIndexOf(".");
          var ext = dot >= 0 ? name.substring(dot).toLowerCase() : "";
          if (ext !== ".psd" && ext !== ".png")
            ext = ".bin";
          try { FS.mkdir("/tmp"); } catch (ignored) {}
          var path = "/tmp/dressup-import" + ext;
          try { FS.unlink(path); } catch (ignored) {}
          FS.writeFile(path, data);
          SendMessage(objectName, methodName, path);
        } catch (exception) {
          SendMessage(objectName, methodName, "error:" + (exception && exception.message ? exception.message : "读不到这个文件"));
        }
        input.dataset.reading = "0";
      };
      reader.onerror = function () {
        input.dataset.reading = "0";
        SendMessage(objectName, methodName, "error:读不到这个文件");
      };
      reader.readAsArrayBuffer(file);
    }
  },

  DressUpShowFileInput__deps: ["$dressUpFilePick"],
  DressUpShowFileInput: function (acceptPtr, x, y, w, h, objectPtr, methodPtr) {
    var input = dressUpFilePick.element();
    if (input.dataset.reading === "1")
      return;

    input.dataset.object = UTF8ToString(objectPtr);
    input.dataset.method = UTF8ToString(methodPtr);
    var accept = UTF8ToString(acceptPtr);
    var phone = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    if (phone)
      accept = "*/*";
    if (input.getAttribute("accept") !== accept)
      input.setAttribute("accept", accept);
    dressUpFilePick.place(input, x, y, w, h);
    input.style.opacity = "0";
    input.style.pointerEvents = "auto";
    if (dressUpFilePick.android()) {
      input.style.touchAction = "auto";
      input.style.opacity = "0.01";
    }
    input.style.display = "block";
  },

  DressUpHideFileInput__deps: ["$dressUpFilePick"],
  DressUpHideFileInput: function () {
    var input = document.getElementById("dressup-file-input");
    if (!input || input.dataset.reading === "1")
      return;
    input.style.display = "none";
    input.style.pointerEvents = "none";
    input.style.width = "0px";
    input.style.height = "0px";
  },

  DressUpClickFileInput__deps: ["$dressUpFilePick"],
  DressUpClickFileInput: function () {
    var input = document.getElementById("dressup-file-input");
    if (!input || input.dataset.reading === "1")
      return;
    if (dressUpFilePick.android()) {
      var now = Date.now();
      if (input.dataset.opened && now - Number(input.dataset.opened) < 700)
        return;
    }
    input.style.display = "block";
    input.click();
  }
});
