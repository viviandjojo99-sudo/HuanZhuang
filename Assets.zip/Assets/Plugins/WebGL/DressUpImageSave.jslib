mergeInto(LibraryManager.library, {
  DressUpSaveImage: function (dataPtr, size, namePtr) {
    var filename = UTF8ToString(namePtr).replace(/zhipai/ig, "").replace(/^[_\\-]+/, "");
    if (!filename || filename === ".png")
      filename = "export.png";
    var bytes = new Uint8Array(size);
    bytes.set(HEAPU8.subarray(dataPtr, dataPtr + size));
    var blob = new Blob([bytes], { type: "image/png" });
    var file = new File([blob], filename, { type: "image/png" });

    function isIOS() {
      return /iPad|iPhone|iPod/.test(navigator.userAgent)
        || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    }

    function downloadFile() {
      var url = URL.createObjectURL(blob);
      var link = document.createElement("a");
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    }

    function showLongPress() {
      var previous = document.getElementById("dressup-save-overlay");
      if (previous)
        previous.remove();

      var url = URL.createObjectURL(blob);
      var overlay = document.createElement("div");
      overlay.id = "dressup-save-overlay";
      overlay.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.75);display:flex;flex-direction:column;align-items:center;justify-content:center;";

      var image = document.createElement("img");
      image.src = url;
      image.alt = filename;
      image.style.cssText = "max-width:92vw;max-height:78vh;";

      var hint = document.createElement("p");
      hint.textContent = "长按图片，点存储图像";
      hint.style.cssText = "color:#fff;font:16px sans-serif;margin:12px 0 0;";

      var close = document.createElement("button");
      close.textContent = "关闭";
      close.style.cssText = "margin-top:12px;font:16px sans-serif;padding:8px 18px;";
      close.onclick = function () {
        URL.revokeObjectURL(url);
        overlay.remove();
      };

      overlay.appendChild(image);
      overlay.appendChild(hint);
      overlay.appendChild(close);
      document.body.appendChild(overlay);
    }

    if (isIOS()) {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: filename }).catch(function (err) {
          if (!err || err.name !== "AbortError")
            showLongPress();
        });
      } else {
        showLongPress();
      }
      return;
    }

    if (/Android/i.test(navigator.userAgent) && navigator.canShare && navigator.canShare({ files: [file] })) {
      navigator.share({ files: [file], title: filename }).catch(function (err) {
        if (!err || err.name !== "AbortError")
          downloadFile();
      });
      return;
    }

    downloadFile();
  }
});
