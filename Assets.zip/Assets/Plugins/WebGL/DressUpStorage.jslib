mergeInto(LibraryManager.library, {
  DressUpSyncFiles: function () {
    FS.syncfs(false, function (err) {
      if (err)
        console.warn("DressUp syncfs " + err);
    });
  },

  DressUpRequestStorage: function () {
    try {
      if (navigator.storage && navigator.storage.persist)
        navigator.storage.persist();
    } catch (ignored) {}
  }
});
