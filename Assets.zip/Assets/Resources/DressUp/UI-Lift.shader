Shader "DressUp/UI-Lift"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _Lift ("Lift", Range(0, 1)) = 0
        _Curve ("Curve", Range(0, 1)) = 0
        _Grad ("Gradient", Range(0, 2)) = 0
        _GradEnd ("Gradient End", Color) = (1,1,1,1)
        _KeepValue ("Keep Line Value", Range(0, 1)) = 0
        _TintMode ("Tint Mode", Range(0, 3)) = 0

        _StencilComp ("Stencil Comparison", Float) = 8
        _Stencil ("Stencil ID", Float) = 0
        _StencilOp ("Stencil Operation", Float) = 0
        _StencilWriteMask ("Stencil Write Mask", Float) = 255
        _StencilReadMask ("Stencil Read Mask", Float) = 255
        _ColorMask ("Color Mask", Float) = 15

        [Toggle(UNITY_UI_ALPHACLIP)] _UseUIAlphaClip ("Use Alpha Clip", Float) = 0
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "IgnoreProjector"="True"
            "RenderType"="Transparent"
            "PreviewType"="Plane"
            "CanUseSpriteAtlas"="True"
        }

        Stencil
        {
            Ref [_Stencil]
            Comp [_StencilComp]
            Pass [_StencilOp]
            ReadMask [_StencilReadMask]
            WriteMask [_StencilWriteMask]
        }

        Cull Off
        Lighting Off
        ZWrite Off
        ZTest [unity_GUIZTestMode]
        Blend SrcAlpha OneMinusSrcAlpha
        ColorMask [_ColorMask]

        Pass
        {
            Name "Default"
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 2.0

            #include "UnityCG.cginc"
            #include "UnityUI.cginc"

            #pragma multi_compile_local _ UNITY_UI_CLIP_RECT
            #pragma multi_compile_local _ UNITY_UI_ALPHACLIP

            struct appdata_t
            {
                float4 vertex   : POSITION;
                float4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct v2f
            {
                float4 vertex        : SV_POSITION;
                fixed4 color         : COLOR;
                float2 texcoord      : TEXCOORD0;
                float4 worldPosition : TEXCOORD1;
                float gradY          : TEXCOORD2;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            sampler2D _MainTex;
            fixed4 _Color;
            fixed4 _TextureSampleAdd;
            float4 _ClipRect;
            float4 _MainTex_ST;
            float _Lift;
            float _Curve;
            float _Grad;
            fixed4 _GradEnd;
            float _KeepValue;
            float _TintMode;

            v2f vert(appdata_t v)
            {
                v2f o;
                UNITY_SETUP_INSTANCE_ID(v);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.worldPosition = v.vertex;
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.texcoord = TRANSFORM_TEX(v.texcoord, _MainTex);
                o.gradY = v.texcoord.y;
                o.color = v.color * _Color;
                return o;
            }

            fixed4 frag(v2f i) : SV_Target
            {
                half4 tex = tex2D(_MainTex, i.texcoord) + _TextureSampleAdd;
                half3 A = i.color.rgb;
                half3 B = _GradEnd.rgb;
                half luma = saturate(dot(tex.rgb, half3(0.299, 0.587, 0.114)));
                half shade = luma;
                // 图片上方为 A，下方为 B。Unity 贴图 v=1 在上。
                half3 tint = _Grad > 1.5 ? lerp(B, A, saturate(i.gradY)) : A;
                bool pair = _Grad > 0.5;
                bool blank = pair
                    ? (A.r > 0.96 && A.g > 0.96 && A.b > 0.96 && B.r > 0.96 && B.g > 0.96 && B.b > 0.96)
                    : (A.r > 0.96 && A.g > 0.96 && A.b > 0.96);
                half4 color = tex * i.color;
                // 线稿：换成起色的色相，每个像素自己的明暗不动。
                if (_KeepValue > 0.5)
                {
                    half srcV = max(tex.r, max(tex.g, tex.b));
                    half tintV = max(A.r, max(A.g, A.b));
                    color.rgb = A * (srcV / max(tintV, 0.001));
                    color.a = tex.a * i.color.a;
                }
                else if (blank)
                {
                    // 纯白是没染色。提亮仍然要往白走，避免滑到这一角时从白突然跳回原图。
                    color.rgb = lerp(tex.rgb, half3(1.0, 1.0, 1.0), saturate(_Lift));
                    color.a = tex.a * i.color.a;
                }
                else if (_Curve > 0.5 && _Grad > 0.5 && _Grad < 1.5)
                {
                    // 曲线 + 明暗：色稿最暗是 B，最亮是 A。
                    half3 graded = lerp(B, A, shade);
                    color.rgb = lerp(tex.rgb, graded, 0.8);
                    color.a = tex.a * i.color.a;
                }
                else if (_Curve > 0.5)
                {
                    // 曲线。颜色渐变时 tint 已是上 A 下 B。
                    half curveShade = smoothstep(0.05, 0.92, luma);
                    half3 shadowCol = tint * 0.45;
                    half3 highCol = lerp(tint, half3(1.0, 1.0, 1.0), 0.55 + 0.45 * saturate(_Lift));
                    half3 graded = lerp(shadowCol, highCol, curveShade);
                    color.rgb = lerp(tex.rgb, graded, 0.8);
                    color.a = tex.a * i.color.a;
                }
                else if (_Grad > 0.5 && _Grad < 1.5)
                {
                    // 色相 + 明暗：色稿最亮是 A，最暗是 B。
                    color.rgb = lerp(lerp(B, A, shade), half3(1.0, 1.0, 1.0), saturate(_Lift));
                    color.a = tex.a * i.color.a;
                }
                else if (_Grad > 1.5)
                {
                    // 色相 + 颜色渐变：上 A，下 B。颜色里已经含提亮。
                    color.rgb = tex.rgb * tint;
                    color.a = tex.a * i.color.a;
                }
                else
                    color.rgb = tex.rgb * A;

                #ifdef UNITY_UI_CLIP_RECT
                color.a *= UnityGet2DClipping(i.worldPosition.xy, _ClipRect);
                #endif

                #ifdef UNITY_UI_ALPHACLIP
                clip(color.a - 0.001);
                #endif

                return color;
            }
            ENDCG
        }
    }
}
