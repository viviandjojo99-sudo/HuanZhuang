using UnityEngine;

namespace DressUp.Actions
{
    public static class AndroidImageSaver
    {
        public static void Toast(string message)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (AndroidJavaClass player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                {
                    AndroidJavaObject activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                    if (activity == null)
                        return;
                    activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
                    {
                        using (AndroidJavaClass toastClass = new AndroidJavaClass("android.widget.Toast"))
                        using (AndroidJavaObject toast = toastClass.CallStatic<AndroidJavaObject>(
                            "makeText", activity, message, 0))
                            toast.Call("show");
                    }));
                }
            }
            catch (System.Exception exception)
            {
                Debug.LogError("[AndroidImageSaver] " + exception);
            }
#else
            Debug.Log("[AndroidImageSaver] " + message);
#endif
        }

        public static void SaveToGallery(string gameObjectName, string methodName, string filePath, string displayName)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (AndroidJavaClass player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                {
                    AndroidJavaObject activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                    if (activity == null)
                    {
                        player.CallStatic("UnitySendMessage", gameObjectName, methodName, "error:打不开保存");
                        Toast("导出失败");
                        return;
                    }

                    activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
                    {
                        try
                        {
                            using (AndroidJavaClass saver = new AndroidJavaClass("com.jojo.dressup.DressUpSaveActivity"))
                                saver.CallStatic("saveToGallery", activity, gameObjectName, methodName, filePath, displayName);
                        }
                        catch (System.Exception exception)
                        {
                            Toast("导出失败");
                            Debug.LogError("[AndroidImageSaver] " + exception);
                        }
                    }));
                }
            }
            catch (System.Exception exception)
            {
                Toast("导出失败");
                Debug.LogError("[AndroidImageSaver] " + exception);
            }
#else
            Debug.LogWarning("[AndroidImageSaver] 只在安卓播放器里保存图片。 " + filePath);
#endif
        }

        public static void Save(string gameObjectName, string methodName, string filePath, string displayName)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (AndroidJavaClass player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                {
                    AndroidJavaObject activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                    if (activity == null)
                    {
                        player.CallStatic("UnitySendMessage", gameObjectName, methodName, "error:打不开保存");
                        return;
                    }

                    activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
                    {
                        try
                        {
                            using (AndroidJavaClass saver = new AndroidJavaClass("com.jojo.dressup.DressUpSaveActivity"))
                                saver.CallStatic("open", activity, gameObjectName, methodName, filePath, displayName);
                        }
                        catch (System.Exception exception)
                        {
                            using (AndroidJavaClass again = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                                again.CallStatic("UnitySendMessage", gameObjectName, methodName, "error:打不开保存");
                            Debug.LogError("[AndroidImageSaver] " + exception);
                        }
                    }));
                }
            }
            catch (System.Exception exception)
            {
                Debug.LogError("[AndroidImageSaver] " + exception);
            }
#else
            Debug.LogWarning("[AndroidImageSaver] 只在安卓播放器里保存图片。");
#endif
        }
    }
}
