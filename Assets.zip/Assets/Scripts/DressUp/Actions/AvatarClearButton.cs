using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Tinting;
using DressUp.Wardrobe;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Actions
{
    [RequireComponent(typeof(Button))]
    public class AvatarClearButton : MonoBehaviour
    {
        [SerializeField] BodyAvatar targetAvatar;
        [SerializeField] WardrobeController wardrobe;
        [SerializeField] LayerColorController colorController;

        Button button;

        public BodyAvatar TargetAvatar => targetAvatar;

        void Awake()
        {
            button = GetComponent<Button>();
            button.onClick.AddListener(Clear);
        }

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(Clear);
        }

        public void SetTargetAvatar(BodyAvatar avatar) => targetAvatar = avatar;

        public void SetWardrobe(WardrobeController controller) => wardrobe = controller;

        public void SetColorController(LayerColorController controller) => colorController = controller;

        public void Clear()
        {
            if (targetAvatar == null)
                targetAvatar = FindAnyObjectByType<ActiveAvatarBinder>()?.ActiveAvatar
                               ?? FindAnyObjectByType<BodyAvatar>();

            if (targetAvatar == null)
            {
                Debug.LogWarning("[AvatarClearButton] 未指定 BodyAvatar", this);
                return;
            }

            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            if (binder != null)
            {
                // 清改色记忆 → 脱光 → 穿回初始内衣套装
                binder.ResetToDefaultOutfit();
            }
            else
            {
                targetAvatar.ClearChosenColors();
                targetAvatar.ClearClothes();

                if (wardrobe == null)
                    wardrobe = FindAnyObjectByType<WardrobeController>();
                wardrobe?.RefreshSelection();

                if (colorController == null)
                    colorController = FindAnyObjectByType<LayerColorController>();
                colorController?.ClearTintTarget();
            }

            DressUpAudio.Instance?.PlayClear();
        }
    }
}
