using DressUp.Audio;
using DressUp.Avatar;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DressUp.Actions
{
    [RequireComponent(typeof(Button))]
    public class AvatarExportButton : MonoBehaviour
    {
        const string NoticeName = "TC";
        const string PrivacyAgreedKey = "DressUp.PrivacyAgreed";

        [SerializeField] BodyAvatar targetAvatar;
        [Tooltip("留空 = 导出整个面板；填写则只导出该图层名")]
        [SerializeField] string layerFilter;
        [SerializeField] int textureWidth = 1024;
        [SerializeField] int textureHeight = 1024;
        [Tooltip("隐私政策面板（场景里的 TC）")]
        [SerializeField] GameObject trialNoticePanel;
        [SerializeField] Color dimColor = new Color(0f, 0f, 0f, 0.45f);

        const string PolicyText =
            "更新日期：【2026年11月14日】\n\n" +
            "告知：请您在点击「同意」前阅读本政策。目的：在您的设备上运行换装游戏，并在您主动选择时读取您选中的本地图片。方式：仅在设备本地处理，不上传个人信息。范围：您同意并启动游戏引擎后，引擎会读取一次传感器类型列表；您主动导入图片时，读取您选中的文件。点击「拒绝」将退出，且不会初始化游戏引擎、不会读取传感器、不会采集设备信息。拒绝后退出，下次启动会再次展示本政策。点击「同意」后才进入。\n\n" +
            "一、运营主体与联系方式\n" +
            "本游戏《赛博衣柜安》（以下称“本游戏”）由【赛博凌月娘】开发和运营。如对本政策有任何疑问，可通过【262804512@qq.com】与我们联系。\n\n" +
            "二、我们收集的信息与用途\n" +
            "本游戏为单机游戏，不设账号注册，不需要您提供姓名、手机号等身份信息。我们不会主动收集、上传您的个人信息。\n\n" +
            "首次启动时，我们以弹窗明示上述目的、方式和范围。只有您点击「同意」之后，才会初始化游戏引擎并进入游戏。同意之前不读取传感器列表，不采集设备信息。启动时不申请任何权限。\n\n" +
            "您同意后，游戏引擎为识别本机是否具备加速度计、陀螺仪等输入传感器，会在每次启动且您已同意后读取一次传感器类型列表，不持续读取。本游戏不使用陀螺仪、加速度计玩法，已关闭加速度计采样，也不上传该列表。\n\n" +
            "三、本地文件访问说明\n" +
            "导入 PSD 或 PNG 时，通过系统文件选择器由您主动选择一个文件。本游戏只在设备本地读取并处理您选中的这一个文件，仅用于在游戏内展示与编辑；该文件不会上传至服务器，也不会提供给任何第三方。除您主动选择的文件外，本游戏不会读取设备上的其他文件。\n\n" +
            "四、权限申请说明\n" +
            "启动时不申请任何权限。本安装包声明的系统权限只有网络权限（android.permission.INTERNET），在安装时由系统授予，启动时不会弹出权限申请框，本游戏不使用该权限上传您的个人信息。\n" +
            "本安装包未声明存储、定位、相机、麦克风、通讯录、电话状态权限。导入文件不申请存储权限，只通过系统文件选择器由您主动选择。传感器类型列表的读取发生在您点击同意并启动引擎之后，由游戏引擎在本地完成。\n\n" +
            "五、信息的共享、转让与公开披露\n" +
            "我们不会将您的信息共享、转让或公开披露给任何第三方。游戏引擎读取的传感器类型列表只留在设备本地，不向第三方提供。\n\n" +
            "六、信息的存储与保存期限\n" +
            "本游戏不将您的文件上传至服务器，因此不涉及服务器端的保存。设备本地的文件由您自行管理，删除游戏或相应文件后即不再保留于本游戏可访问范围内。是否已同意本政策，仅保存在您的设备本地，用于下次启动时不再重复询问；卸载游戏后即删除。\n\n" +
            "七、您的权利\n" +
            "您可以点击「拒绝」。拒绝后游戏退出，不初始化引擎，不读取传感器。下次启动会再次展示本政策。您也可以随时停止使用相关功能、删除本地文件，或卸载本游戏。\n\n" +
            "八、未成年人保护\n" +
            "如您是未成年人，请在监护人指导下阅读本政策并使用本游戏。如您不满14周岁，本游戏不收集您的个人信息，请在监护人同意并指导下使用。\n\n" +
            "九、政策更新\n" +
            "本政策如有变更，我们会在本页面更新并标注更新日期。重大变更将以显著方式提示。\n\n" +
            "十、接入第三方 SDK 情况说明\n" +
            "以下为会涉及个人信息处理的第三方 SDK。本游戏未接入统计、广告、登录、支付、推送类 SDK。\n\n" +
            "SDK 名称：Unity 引擎\n" +
            "开发者名称（全称）：Unity Technologies S.F.\n" +
            "使用目的：提供游戏运行、画面渲染和触控输入所需的引擎能力。\n" +
            "使用场景：您点击同意并进入游戏之后，用于衣柜展示、换装和本地导入图片。\n" +
            "调用权限说明：不向系统申请存储、定位、相机、麦克风、通讯录、电话状态权限。安装包声明网络权限（android.permission.INTERNET），安装时由系统授予，不用于上传个人信息。您同意后，引擎在本地读取传感器类型列表。导入图片通过系统文件选择器由您主动选择，不申请存储权限。\n" +
            "个人信息收集类型及方式：您同意并启动引擎时，在设备本地读取传感器类型列表。不收集姓名、手机号、通讯录、精确位置、短信和设备唯一标识，也不上传该列表。本游戏未启用 Unity 的广告、统计、内购和崩溃上报。\n" +
            "隐私政策链接：https://unity.com/legal/game-player-and-app-user-privacy-policy\n" +
            "频次时机：每次启动且您已同意后读取一次，不持续读取。";

        static readonly Color BodyColor = new Color(0.5647059f, 0.45098042f, 0.38823533f, 1f);
        static readonly Color LinkColor = new Color(0xB9 / 255f, 0x72 / 255f, 0x72 / 255f, 1f);
        static readonly Color PolicyLinkColor = new Color(0.15f, 0.38f, 0.86f, 1f);
        const float ConsentFontSize = 36f;

        Button button;
        GameObject dimmerRoot;
        bool showNoticeOnStart = true;
        bool entryGate;

        TMP_Text noticeBody;
        TMP_Text noticeHandle;
        GameObject consentRoot;
        Image consentDot;
        ScrollRect policyScroll;
        bool policyReady;

        public BodyAvatar TargetAvatar => targetAvatar;

        void Awake()
        {
            button = GetComponent<Button>();
            if (trialNoticePanel == null)
                trialNoticePanel = FindNamed(NoticeName);

            if (trialNoticePanel != null)
                trialNoticePanel.SetActive(false);

            // 旧版水印物体若还在场景里，永久关掉。
            GameObject watermark = FindNamed("SY");
            if (watermark != null)
                watermark.SetActive(false);

            button.onClick.AddListener(Export);
        }

        void Start()
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            // 安卓由 PrivacyGateActivity 在进引擎前拦截；已同意则不会再进 Unity 弹层。
            return;
#endif
            if (!showNoticeOnStart)
                return;

            // 首次进入需勾选同意；同意后写入本地，之后不再显示。
            if (HasAgreedPrivacy())
                return;

            entryGate = true;
            ShowTrialNotice();
            EnsureConsent();
            ShowPrivacyPolicy();
        }

        static bool HasAgreedPrivacy() => PlayerPrefs.GetInt(PrivacyAgreedKey, 0) != 0;

        static void RememberPrivacyAgreed()
        {
            PlayerPrefs.SetInt(PrivacyAgreedKey, 1);
            PlayerPrefs.Save();
        }

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(Export);
        }

        public void SetTargetAvatar(BodyAvatar avatar) => targetAvatar = avatar;

        bool exporting;

        public void Export()
        {
            if (targetAvatar == null)
            {
                Debug.LogWarning("[AvatarExportButton] 未指定 BodyAvatar", this);
                AndroidImageSaver.Toast("导出失败：没有人物");
                return;
            }

            DressUpAudio.Instance?.PlayError2();

#if UNITY_ANDROID && !UNITY_EDITOR
            if (exporting)
                return;
            StartCoroutine(ExportOnAndroid());
#else
            try
            {
                byte[] png = AvatarTransparentExporter.RenderPng(targetAvatar, layerFilter, textureWidth, textureHeight);
                string fileName = AvatarTransparentExporter.NewFileName();
#if UNITY_WEBGL && !UNITY_EDITOR
                WebGlImageSaver.Save(fileName, png);
                Debug.Log($"导出已交给浏览器: {fileName}", this);
#else
                string path = AvatarTransparentExporter.WritePng(targetAvatar.CharacterId, png);
                Debug.Log($"导出成功: {path}", this);
#endif
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"导出失败: {ex.Message}", this);
            }
#endif
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        System.Collections.IEnumerator ExportOnAndroid()
        {
            exporting = true;
            AndroidImageSaver.Toast("正在导出");
            AvatarTransparentExporter.FrameCapture capture = null;
            try
            {
                capture = AvatarTransparentExporter.BeginCapture(targetAvatar, layerFilter, textureWidth, textureHeight);
            }
            catch (System.Exception ex)
            {
                exporting = false;
                Debug.LogError($"导出失败: {ex.Message}", this);
                AndroidImageSaver.Toast("导出失败");
                yield break;
            }

            yield return null;
            yield return new WaitForEndOfFrame();

            byte[] png;
            try
            {
                png = capture.ReadPng();
            }
            catch (System.Exception ex)
            {
                capture.Dispose();
                exporting = false;
                Debug.LogError($"导出失败: {ex.Message}", this);
                AndroidImageSaver.Toast("导出失败");
                yield break;
            }

            capture.Dispose();
            if (png == null || png.Length == 0)
            {
                exporting = false;
                AndroidImageSaver.Toast("导出失败");
                yield break;
            }

            string fileName = AvatarTransparentExporter.NewFileName();
            string staging = System.IO.Path.Combine(Application.temporaryCachePath, fileName);
            try
            {
                System.IO.File.WriteAllBytes(staging, png);
                AndroidImageSaver.SaveToGallery(gameObject.name, nameof(OnAndroidImageSaved), staging, fileName);
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"导出失败: {ex.Message}", this);
                AndroidImageSaver.Toast("导出失败");
            }

            exporting = false;
        }
#endif

        public void OnAndroidImageSaved(string message)
        {
            if (string.IsNullOrEmpty(message))
                Debug.Log("[AvatarExportButton] 已取消保存", this);
            else if (message.StartsWith("error:"))
                Debug.LogError("[AvatarExportButton] " + message, this);
            else
                Debug.Log("[AvatarExportButton] 已保存 " + message, this);
        }

        public void ShowTrialNotice()
        {
            if (trialNoticePanel == null)
                trialNoticePanel = FindNamed(NoticeName);
            if (trialNoticePanel == null)
            {
                Debug.LogWarning("[AvatarExportButton] 找不到试用面板 TC。", this);
                return;
            }

            EnsureDimmer();
            if (dimmerRoot != null)
            {
                dimmerRoot.SetActive(true);
                dimmerRoot.transform.SetAsLastSibling();
            }

            trialNoticePanel.SetActive(true);
            trialNoticePanel.transform.SetAsLastSibling();
            if (consentRoot != null)
                consentRoot.transform.SetAsLastSibling();
        }

        public void HideTrialNotice()
        {
            if (entryGate)
                return;

            if (trialNoticePanel != null)
                trialNoticePanel.SetActive(false);
            if (dimmerRoot != null)
                dimmerRoot.SetActive(false);
            if (consentRoot != null)
                consentRoot.SetActive(false);
        }

        public void ShowPrivacyPolicy()
        {
            if (trialNoticePanel == null)
                return;

            BindNoticeTexts();
            if (noticeBody == null)
                return;

            if (noticeHandle != null)
                noticeHandle.gameObject.SetActive(false);

            EnsurePolicyScroll();
            if (consentRoot != null)
                consentRoot.transform.SetAsLastSibling();
            noticeBody.text = PolicyText;
            noticeBody.enableAutoSizing = false;
            noticeBody.fontSize = ConsentFontSize;
            noticeBody.alignment = TextAlignmentOptions.TopLeft;
            noticeBody.textWrappingMode = TextWrappingModes.Normal;
            noticeBody.overflowMode = TextOverflowModes.Overflow;
            noticeBody.ForceMeshUpdate();
            if (policyScroll != null)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(policyScroll.content);
                policyScroll.verticalNormalizedPosition = 1f;
                StartCoroutine(ScrollPolicyToTop());
            }
        }

        System.Collections.IEnumerator ScrollPolicyToTop()
        {
            yield return null;
            if (policyScroll != null)
                policyScroll.verticalNormalizedPosition = 1f;
        }

        public void AgreeAndClose()
        {
            entryGate = false;
            RememberPrivacyAgreed();
            if (consentDot != null)
                consentDot.enabled = true;
            HideTrialNotice();
        }

        void EnsureDimmer()
        {
            if (dimmerRoot != null)
                return;

            Canvas canvas = GetComponentInParent<Canvas>()
                           ?? (trialNoticePanel != null ? trialNoticePanel.GetComponentInParent<Canvas>() : null)
                           ?? FindAnyObjectByType<Canvas>();
            if (canvas == null)
                return;

            dimmerRoot = new GameObject("TrialNoticeDimmer", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            dimmerRoot.transform.SetParent(canvas.transform, false);

            RectTransform rt = dimmerRoot.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;

            Image img = dimmerRoot.GetComponent<Image>();
            img.color = dimColor;
            img.raycastTarget = true;

            var click = dimmerRoot.AddComponent<DimmerClickClose>();
            click.Owner = this;
            dimmerRoot.SetActive(false);
        }

        static GameObject FindNamed(string name)
        {
            Transform[] all = FindObjectsByType<Transform>(FindObjectsInactive.Include);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].name == name)
                    return all[i].gameObject;
            }

            return null;
        }

        class DimmerClickClose : MonoBehaviour, IPointerClickHandler
        {
            public AvatarExportButton Owner;

            public void OnPointerClick(PointerEventData eventData)
            {
                if (Owner != null && Owner.entryGate)
                    return;
                if (eventData.pointerCurrentRaycast.gameObject == gameObject)
                    Owner?.HideTrialNotice();
            }
        }

        void BindNoticeTexts()
        {
            if (trialNoticePanel == null || (noticeBody != null && noticeHandle != null))
                return;

            TMP_Text[] texts = trialNoticePanel.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                TMP_Text text = texts[i];
                if (text == null)
                    continue;
                if (text.text.IndexOf("@", System.StringComparison.Ordinal) >= 0)
                    noticeHandle = text;
                else if (noticeBody == null)
                    noticeBody = text;
            }
        }

        void EnsureConsent()
        {
            if (consentRoot != null || trialNoticePanel == null)
                return;

            BindNoticeTexts();
            TMP_FontAsset font = noticeBody != null ? noticeBody.font : noticeHandle != null ? noticeHandle.font : null;

            consentRoot = new GameObject("PrivacyConsent", typeof(RectTransform), typeof(HorizontalLayoutGroup), typeof(ContentSizeFitter));
            consentRoot.transform.SetParent(trialNoticePanel.transform, false);
            var rowRt = consentRoot.GetComponent<RectTransform>();
            rowRt.anchorMin = rowRt.anchorMax = new Vector2(0.5f, 0f);
            rowRt.pivot = new Vector2(0.5f, 0f);
            rowRt.anchoredPosition = new Vector2(0f, 16f);

            var layout = consentRoot.GetComponent<HorizontalLayoutGroup>();
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.spacing = 12f;
            layout.childControlWidth = false;
            layout.childControlHeight = false;
            layout.childForceExpandWidth = false;
            layout.childForceExpandHeight = false;
            var fit = consentRoot.GetComponent<ContentSizeFitter>();
            fit.horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
            fit.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            var circle = new GameObject("Circle", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(CircleClick));
            circle.transform.SetParent(consentRoot.transform, false);
            var circleRt = circle.GetComponent<RectTransform>();
            circleRt.anchorMin = circleRt.anchorMax = new Vector2(0.5f, 0.5f);
            circleRt.sizeDelta = new Vector2(52f, 52f);
            Image ring = circle.GetComponent<Image>();
            ring.sprite = RingSprite();
            ring.color = BodyColor;
            ring.raycastTarget = true;
            circle.GetComponent<CircleClick>().Owner = this;

            var dotGo = new GameObject("Dot", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            dotGo.transform.SetParent(circle.transform, false);
            var dotRt = dotGo.GetComponent<RectTransform>();
            dotRt.anchorMin = dotRt.anchorMax = new Vector2(0.5f, 0.5f);
            dotRt.sizeDelta = new Vector2(22f, 22f);
            consentDot = dotGo.GetComponent<Image>();
            consentDot.sprite = DotSprite();
            consentDot.color = LinkColor;
            consentDot.raycastTarget = false;
            consentDot.enabled = false;

            CreateConsentLabel(consentRoot.transform, "请先同意", BodyColor, font, false);
            CreateConsentLabel(consentRoot.transform, "隐私政策", PolicyLinkColor, font, true);
            consentRoot.transform.SetAsLastSibling();
        }

        void CreateConsentLabel(Transform parent, string text, Color color, TMP_FontAsset font, bool opensPolicy)
        {
            var go = new GameObject(text, typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(opensPolicy ? 180f : 190f, 52f);
            var tmp = go.GetComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = ConsentFontSize;
            tmp.fontStyle = FontStyles.Underline;
            if (!opensPolicy)
                tmp.fontStyle = FontStyles.Normal;
            tmp.alignment = TextAlignmentOptions.MidlineLeft;
            tmp.color = color;
            tmp.raycastTarget = opensPolicy;
            if (font != null)
                tmp.font = font;
            if (opensPolicy)
                go.AddComponent<PolicyClick>().Owner = this;
        }

        void EnsurePolicyScroll()
        {
            if (policyReady || noticeBody == null || trialNoticePanel == null)
                return;

            RectTransform bodyRt = noticeBody.rectTransform;
            var viewportGo = new GameObject("PolicyViewport", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(RectMask2D));
            viewportGo.transform.SetParent(trialNoticePanel.transform, false);
            var viewportRt = viewportGo.GetComponent<RectTransform>();
            viewportRt.anchorMin = bodyRt.anchorMin;
            viewportRt.anchorMax = bodyRt.anchorMax;
            viewportRt.pivot = bodyRt.pivot;
            viewportRt.anchoredPosition = bodyRt.anchoredPosition + new Vector2(-12f, 36f);
            viewportRt.sizeDelta = bodyRt.sizeDelta + new Vector2(-36f, -88f);
            Image hit = viewportGo.GetComponent<Image>();
            hit.color = new Color(1f, 1f, 1f, 0f);
            hit.raycastTarget = true;

            bodyRt.SetParent(viewportRt, false);
            bodyRt.anchorMin = new Vector2(0f, 1f);
            bodyRt.anchorMax = new Vector2(1f, 1f);
            bodyRt.pivot = new Vector2(0.5f, 1f);
            bodyRt.anchoredPosition = Vector2.zero;
            bodyRt.sizeDelta = new Vector2(-12f, 0f);

            var fitter = noticeBody.gameObject.AddComponent<ContentSizeFitter>();
            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            policyScroll = viewportGo.AddComponent<ScrollRect>();
            policyScroll.content = bodyRt;
            policyScroll.viewport = viewportRt;
            policyScroll.horizontal = false;
            policyScroll.vertical = true;
            policyScroll.movementType = ScrollRect.MovementType.Clamped;
            policyScroll.scrollSensitivity = 36f;
            policyScroll.verticalScrollbar = CreatePolicyScrollbar(trialNoticePanel.transform);
            policyScroll.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
            policyReady = true;
        }

        static Scrollbar CreatePolicyScrollbar(Transform parent)
        {
            var barGo = new GameObject("PolicyScrollbar", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Scrollbar));
            barGo.transform.SetParent(parent, false);
            var barRt = barGo.GetComponent<RectTransform>();
            barRt.anchorMin = new Vector2(1f, 0f);
            barRt.anchorMax = new Vector2(1f, 1f);
            barRt.pivot = new Vector2(1f, 0.5f);
            barRt.offsetMin = new Vector2(-40f, 84f);
            barRt.offsetMax = new Vector2(-22f, -28f);
            Image track = barGo.GetComponent<Image>();
            track.color = new Color(0.56f, 0.45f, 0.39f, 0.25f);
            track.raycastTarget = true;

            var sliding = new GameObject("Sliding Area", typeof(RectTransform));
            sliding.transform.SetParent(barGo.transform, false);
            var slidingRt = sliding.GetComponent<RectTransform>();
            slidingRt.anchorMin = Vector2.zero;
            slidingRt.anchorMax = Vector2.one;
            slidingRt.offsetMin = new Vector2(2f, 2f);
            slidingRt.offsetMax = new Vector2(-2f, -2f);

            var handleGo = new GameObject("Handle", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            handleGo.transform.SetParent(sliding.transform, false);
            var handleRt = handleGo.GetComponent<RectTransform>();
            handleRt.anchorMin = Vector2.zero;
            handleRt.anchorMax = Vector2.one;
            handleRt.offsetMin = Vector2.zero;
            handleRt.offsetMax = Vector2.zero;
            Image handle = handleGo.GetComponent<Image>();
            handle.color = LinkColor;
            handle.raycastTarget = true;

            Scrollbar bar = barGo.GetComponent<Scrollbar>();
            bar.handleRect = handleRt;
            bar.targetGraphic = handle;
            bar.direction = Scrollbar.Direction.BottomToTop;
            return bar;
        }

        static Sprite ringSprite;
        static Sprite dotSprite;

        static Sprite RingSprite()
        {
            if (ringSprite != null)
                return ringSprite;
            ringSprite = CircleSprite(64, 26f, 22f, true);
            return ringSprite;
        }

        static Sprite DotSprite()
        {
            if (dotSprite != null)
                return dotSprite;
            dotSprite = CircleSprite(64, 18f, 0f, false);
            return dotSprite;
        }

        static Sprite CircleSprite(int size, float outer, float inner, bool ring)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            float center = (size - 1) * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                    bool on = ring ? d <= outer && d >= inner : d <= outer;
                    tex.SetPixel(x, y, on ? Color.white : Color.clear);
                }
            }

            tex.Apply();
            return Sprite.Create(tex, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
        }

        class PolicyClick : MonoBehaviour, IPointerClickHandler
        {
            public AvatarExportButton Owner;

            public void OnPointerClick(PointerEventData eventData) => Owner?.ShowPrivacyPolicy();
        }

        class CircleClick : MonoBehaviour, IPointerClickHandler
        {
            public AvatarExportButton Owner;

            public void OnPointerClick(PointerEventData eventData) => Owner?.AgreeAndClose();
        }
    }
}
