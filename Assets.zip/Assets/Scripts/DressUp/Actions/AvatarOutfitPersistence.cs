using System.IO;
using DressUp.Avatar;
using DressUp.Data;
using UnityEngine;

namespace DressUp.Actions
{
    public static class AvatarOutfitPersistence
    {
        const string FolderName = "DressUpSaves";

        public static string GetSavePath(string characterId)
        {
            string safe = string.IsNullOrEmpty(characterId) ? "Default" : characterId;
            foreach (char c in Path.GetInvalidFileNameChars())
                safe = safe.Replace(c, '_');

            string dir = Path.Combine(Application.persistentDataPath, FolderName);
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, safe + ".json");
        }

        public static void Save(BodyAvatar avatar)
        {
            if (avatar == null)
                return;

            OutfitSnapshot snapshot = avatar.CaptureOutfit();
            string json = JsonUtility.ToJson(snapshot, true);
            string path = GetSavePath(avatar.CharacterId);
            File.WriteAllText(path, json);
            Debug.Log($"[DressUp] 已保存穿搭: {path}");
        }

        public static bool TryLoad(BodyAvatar avatar, ClothingCatalog catalog)
        {
            if (avatar == null)
                return false;

            string path = GetSavePath(avatar.CharacterId);
            if (!File.Exists(path))
                return false;

            string json = File.ReadAllText(path);
            OutfitSnapshot snapshot = JsonUtility.FromJson<OutfitSnapshot>(json);
            if (snapshot == null)
                return false;

            avatar.ApplyOutfit(snapshot, catalog);
            return true;
        }
    }
}
