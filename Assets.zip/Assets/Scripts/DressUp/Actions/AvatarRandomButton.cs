using System.Collections.Generic;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Import;
using DressUp.Tinting;
using DressUp.Wardrobe;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Actions
{
    /// <summary>
    /// 随机穿搭：按 Catalog 每个可换图层随机一件（跳过联动附属层）；
    /// 并给头发统一随机色相（保留饱和度/明度）。
    /// </summary>
    [RequireComponent(typeof(Button))]
    public class AvatarRandomButton : MonoBehaviour
    {
        const float MinRandomInterval = 0.08f;

        [SerializeField] BodyAvatar targetAvatar;
        [SerializeField] ClothingCatalog catalog;
        [SerializeField] WardrobeController wardrobe;
        [SerializeField] LayerColorController colorController;

        Button button;
        float nextRandomTime;

        ClothingCatalog poolCatalog;
        int poolImportCount = -1;
        List<ClothingItem> poolCache;
        HashSet<string> companionCache;

        public BodyAvatar TargetAvatar => targetAvatar;

        void Awake()
        {
            button = GetComponent<Button>();
            button.onClick.AddListener(Randomize);
        }

        void Start()
        {
            RandomSettingsPanel.Wire();
        }

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(Randomize);
        }

        public void SetTargetAvatar(BodyAvatar avatar) => targetAvatar = avatar;

        public void SetCatalog(ClothingCatalog next)
        {
            catalog = next;
            InvalidatePool();
        }

        public void SetWardrobe(WardrobeController controller) => wardrobe = controller;

        public void SetColorController(LayerColorController controller) => colorController = controller;

        void InvalidatePool()
        {
            poolCache = null;
            companionCache = null;
            poolCatalog = null;
            poolImportCount = -1;
        }

        void EnsurePool()
        {
            int importCount = ImportedWardrobe.Instance != null ? ImportedWardrobe.Instance.ImportedCount : 0;
            if (poolCache != null && poolCatalog == catalog && poolImportCount == importCount)
                return;

            poolCatalog = catalog;
            poolImportCount = importCount;
            companionCache = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            if (catalog?.items != null)
            {
                for (int i = 0; i < catalog.items.Count; i++)
                {
                    ClothingItem item = catalog.items[i];
                    if (item != null && !string.IsNullOrEmpty(item.tintCompanionLayer))
                        companionCache.Add(item.tintCompanionLayer);
                }
            }

            poolCache = ImportedWardrobe.MergeAll(catalog);
        }

        public void Randomize()
        {
            // 连点合并：上一轮还没消化完就再点，直接跳过，避免曲线材质反复重建。
            if (Time.unscaledTime < nextRandomTime)
                return;
            nextRandomTime = Time.unscaledTime + MinRandomInterval;

            if (targetAvatar == null)
                targetAvatar = FindAnyObjectByType<ActiveAvatarBinder>()?.ActiveAvatar
                               ?? FindAnyObjectByType<BodyAvatar>();

            if (catalog == null && wardrobe != null)
                catalog = wardrobe.Catalog;

            if (targetAvatar == null || catalog == null || catalog.items == null)
            {
                Debug.LogWarning("[AvatarRandomButton] 缺少 Avatar 或 Catalog。", this);
                return;
            }

            RandomSettingsPanel settings = RandomSettingsPanel.Current;
            OutfitSnapshot keep = targetAvatar.CaptureOutfit();
            bool willTint = settings != null && settings.HasColorChecks();
            // 有随机变色时：素色批量穿戴 → 一次上色；关掉逐件 WearPop / 存档抖动。
            targetAvatar.BeginOutfitBatch(plainEquipColors: willTint);
            int equipped = 0;
            bool tinted = false;
            Color tintedColor = Color.white;
            var randomizedLayers = new List<string>(16);
            var paintedLayers = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            try
            {
                EnsurePool();
                var byLayer = new Dictionary<string, List<ClothingItem>>(System.StringComparer.OrdinalIgnoreCase);
                List<ClothingItem> pool = poolCache;
                for (int i = 0; i < pool.Count; i++)
                {
                    ClothingItem item = pool[i];
                    if (item == null || string.IsNullOrEmpty(item.layerName))
                        continue;
                    // 面饰不参与随机；YF 内衣 YF_0 也不进池
                    if (string.Equals(item.layerName, "MS", System.StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (string.Equals(item.itemId, "YF_0", System.StringComparison.OrdinalIgnoreCase))
                        continue;
                    if (companionCache != null && companionCache.Contains(item.layerName))
                        continue;
                    if (!ImportedSave.HasPicture(item))
                        continue;
                    if (!targetAvatar.TryGetLayer(item.layerName, out _))
                        continue;
                    if (settings != null && !settings.PartEnabled(item.layerName, catalog))
                        continue;

                    if (!byLayer.TryGetValue(item.layerName, out List<ClothingItem> list))
                    {
                        list = new List<ClothingItem>();
                        byLayer[item.layerName] = list;
                    }

                    list.Add(item);
                }

                targetAvatar.ClearClothes();

                equipped = RestoreKept(targetAvatar, catalog, keep, settings);
                foreach (KeyValuePair<string, List<ClothingItem>> pair in byLayer)
                {
                    List<ClothingItem> options = pair.Value;
                    if (options == null || options.Count == 0)
                        continue;

                    ClothingItem pick = options[Random.Range(0, options.Count)];
                    if (!targetAvatar.Equip(pick))
                        continue;

                    equipped++;
                    // 只记录本轮随机换上的层；保留件不进 DUANG。
                    if (!string.IsNullOrEmpty(pick.layerName))
                        randomizedLayers.Add(pick.layerName);
                    if (pick.HasCompanion && !string.IsNullOrEmpty(pick.tintCompanionLayer))
                        randomizedLayers.Add(pick.tintCompanionLayer);
                }

                if (settings != null)
                    tinted = settings.ApplyChecked(targetAvatar, catalog, colorController, out tintedColor);

                if (willTint && settings != null)
                {
                    CollectColorCheckedLayers(settings, catalog, paintedLayers);
                    RestoreKeptColors(targetAvatar, catalog, keep, settings);
                }
            }
            finally
            {
                targetAvatar.EndOutfitBatch();
                // 只给「没走随机上色」但仍带色的层补曲线，避免整身 RefreshTintStyle。
                if (willTint && (TintStyle.Curve || TintStyle.TwoColor))
                    targetAvatar.RefreshCurveOnWornExcept(paintedLayers);
            }

            // 批量换装时关掉了逐件 Equipped；对本轮随机到的层按零件 DUANG（S/B 各弹）。
            BodyAvatarWearPop wearPop = targetAvatar.GetComponent<BodyAvatarWearPop>();
            if (wearPop != null && randomizedLayers.Count > 0)
                wearPop.PopLayers(randomizedLayers);

            DressUpAudio.Instance?.PlayPopup();

            if (wardrobe == null)
                wardrobe = FindAnyObjectByType<WardrobeController>();
            wardrobe?.RefreshSelection();

            if (colorController == null)
                colorController = FindAnyObjectByType<LayerColorController>();
            colorController?.ClearTintTarget();
            if (tinted && (settings == null || !settings.LockGradientActive))
                colorController?.SetBarColor(tintedColor);

            if (equipped == 0)
                Debug.LogWarning("[AvatarRandomButton] 没有可随机的衣服。", this);
        }

        static void CollectColorCheckedLayers(RandomSettingsPanel settings, ClothingCatalog catalog, HashSet<string> into)
        {
            into.Clear();
            if (settings == null || catalog?.tags == null || into == null)
                return;

            var seen = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < catalog.tags.Count; i++)
            {
                WardrobeTagDef tag = catalog.tags[i];
                if (tag?.layers == null)
                    continue;
                for (int L = 0; L < tag.layers.Count; L++)
                {
                    string layer = tag.layers[L];
                    if (string.IsNullOrEmpty(layer) || !seen.Add(layer))
                        continue;
                    if (settings.ColorEnabled(layer, catalog))
                        into.Add(layer);
                }
            }
        }

        static void RestoreKeptColors(BodyAvatar avatar, ClothingCatalog catalog, OutfitSnapshot snapshot, RandomSettingsPanel settings)
        {
            if (avatar == null || snapshot?.layerColors == null || settings == null)
                return;

            for (int i = 0; i < snapshot.layerColors.Count; i++)
            {
                LayerColorEntry entry = snapshot.layerColors[i];
                if (entry == null || string.IsNullOrEmpty(entry.layerName))
                    continue;
                // 仅补「部件保留」且本轮没随机变色的层；变色勾了的以 ApplyChecked 为准。
                if (settings.PartEnabled(entry.layerName, catalog))
                    continue;
                if (settings.ColorEnabled(entry.layerName, catalog))
                    continue;
                if (!avatar.TryGetWearOnLayer(entry.layerName, out _))
                    continue;
                Color? end = entry.hasEnd != 0 ? entry.EndColor() : (Color?)null;
                avatar.SetLayerColor(entry.layerName, entry.ToColor(), entry.lift, noteSave: false, end);
            }
        }

        static int RestoreKept(BodyAvatar avatar, ClothingCatalog catalog, OutfitSnapshot snapshot, RandomSettingsPanel settings)
        {
            if (avatar == null || catalog == null || snapshot?.slots == null || settings == null)
                return 0;

            int kept = 0;
            for (int i = 0; i < snapshot.slots.Count; i++)
            {
                EquippedSlot slot = snapshot.slots[i];
                if (slot == null || string.IsNullOrEmpty(slot.layerName) || string.IsNullOrEmpty(slot.itemId))
                    continue;
                if (settings.PartEnabled(slot.layerName, catalog))
                    continue;

                ClothingItem item = ImportedWardrobe.Find(slot.layerName, slot.itemId)
                                    ?? catalog.Find(slot.layerName, slot.itemId)
                                    ?? catalog.Find(slot.itemId);
                if (item != null && avatar.Equip(item))
                    kept++;
            }

            return kept;
        }

        static readonly HashSet<string> HairTintSkipLayers =
            new HashSet<string>(System.StringComparer.OrdinalIgnoreCase) { "GG", "HFBZZS" };

        public static List<string> CollectHairTintLayers(ClothingCatalog cat)
        {
            var result = new List<string>();
            if (cat?.tags == null)
                return result;

            var seen = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < cat.tags.Count; i++)
            {
                WardrobeTagDef tag = cat.tags[i];
                if (tag == null || tag.layers == null || tag.layers.Count == 0)
                    continue;

                bool underHair = IsHairParent(tag.parentTag);
                bool hairRootWithLayers = IsHairParent(tag.tagName) && string.IsNullOrEmpty(tag.parentTag);
                if (!underHair && !hairRootWithLayers)
                    continue;

                for (int L = 0; L < tag.layers.Count; L++)
                {
                    string layer = tag.layers[L];
                    if (string.IsNullOrEmpty(layer) || HairTintSkipLayers.Contains(layer))
                        continue;
                    if (seen.Add(layer))
                        result.Add(layer);
                }
            }

            return result;
        }

        static bool IsHairParent(string name)
        {
            return name == "头发";
        }
    }
}
