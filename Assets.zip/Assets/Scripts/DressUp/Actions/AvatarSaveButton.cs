using System;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Data;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Actions
{
    [RequireComponent(typeof(Button))]
    public class AvatarSaveButton : MonoBehaviour
    {
        [SerializeField] BodyAvatar targetAvatar;
        [SerializeField] ClothingCatalog catalog;
        [SerializeField] bool loadOnStart;

        Button button;

        public BodyAvatar TargetAvatar => targetAvatar;

        /// <summary>保存成功后触发（用于关柜等）。</summary>
        public event Action Saved;

        void Awake()
        {
            button = GetComponent<Button>();
            button.onClick.AddListener(Save);
        }

        void Start()
        {
            if (loadOnStart)
                Load();
        }

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(Save);
        }

        public void SetTargetAvatar(BodyAvatar avatar) => targetAvatar = avatar;
        public void SetCatalog(ClothingCatalog next) => catalog = next;

        public void Save()
        {
            if (targetAvatar == null)
            {
                Debug.LogWarning("[AvatarSaveButton] 未指定 BodyAvatar", this);
                return;
            }

            AvatarOutfitPersistence.Save(targetAvatar);
            DressUpAudio.Instance?.PlayConfirm();
            Saved?.Invoke();
        }

        public bool Load()
        {
            if (targetAvatar == null)
                return false;

            return AvatarOutfitPersistence.TryLoad(targetAvatar, catalog);
        }
    }
}
