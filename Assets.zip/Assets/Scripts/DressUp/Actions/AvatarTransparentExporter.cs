using System.IO;
using DressUp.Avatar;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Actions
{
    /// <summary>
    /// 将 BodyAvatar 面板合成为透明底 PNG（不要求 Sprite 开启 Read/Write）。
    /// </summary>
    public static class AvatarTransparentExporter
    {
        public static string Export(BodyAvatar avatar, string layerFilter = null, int width = 1024, int height = 1024)
        {
            byte[] png = RenderPng(avatar, layerFilter, width, height);
            return WritePng(avatar.CharacterId, png);
        }

        public static byte[] RenderPng(BodyAvatar avatar, string layerFilter = null, int width = 1024, int height = 1024)
        {
            FrameCapture capture = BeginCapture(avatar, layerFilter, width, height);
            try
            {
                capture.Camera.Render();
                return capture.ReadPng();
            }
            finally
            {
                capture.Dispose();
            }
        }

        public static FrameCapture BeginCapture(BodyAvatar avatar, string layerFilter, int width, int height)
        {
            if (avatar == null)
                throw new System.ArgumentNullException(nameof(avatar));

            RectTransform sourceRoot = avatar.transform as RectTransform;
            if (sourceRoot == null)
                throw new System.InvalidOperationException("BodyAvatar 需要挂在 UI RectTransform 上。");

            width = Mathf.Max(8, width);
            height = Mathf.Max(8, height);

            GameObject cloneRoot = Object.Instantiate(sourceRoot.gameObject);
            cloneRoot.name = sourceRoot.name + "_ExportClone";

            // WearPop 依赖 BodyAvatar，要先拆依赖再删，否则储存预览会报错。
            BodyAvatarWearPop wearPop = cloneRoot.GetComponent<BodyAvatarWearPop>();
            if (wearPop != null)
                Object.DestroyImmediate(wearPop);
            BodyAvatar cloneAvatar = cloneRoot.GetComponent<BodyAvatar>();
            if (cloneAvatar != null)
                Object.DestroyImmediate(cloneAvatar);

            if (!string.IsNullOrEmpty(layerFilter))
            {
                for (int i = cloneRoot.transform.childCount - 1; i >= 0; i--)
                {
                    Transform child = cloneRoot.transform.GetChild(i);
                    if (child.name != layerFilter)
                        Object.DestroyImmediate(child.gameObject);
                }
            }

            Image rootImage = cloneRoot.GetComponent<Image>();
            if (rootImage != null)
                rootImage.enabled = false;

            var canvasGo = new GameObject("DressUpExportCanvas", typeof(Canvas), typeof(CanvasScaler));
            Canvas canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceCamera;
            canvasGo.layer = 5;

            var camGo = new GameObject("DressUpExportCamera");
            Camera cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0f, 0f, 0f, 0f);
            cam.cullingMask = 1 << 5;
            cam.depth = -100f;
            canvas.worldCamera = cam;
            canvas.planeDistance = 1f;

            RectTransform cloneRt = cloneRoot.GetComponent<RectTransform>();
            cloneRt.SetParent(canvasGo.transform, false);
            cloneRt.anchorMin = cloneRt.anchorMax = new Vector2(0.5f, 0.5f);
            cloneRt.pivot = new Vector2(0.5f, 0.5f);
            cloneRt.anchoredPosition = Vector2.zero;
            cloneRt.sizeDelta = sourceRoot.rect.size;
            SetLayerRecursive(cloneRoot, 5);

            float panelHeight = Mathf.Max(1f, cloneRt.rect.height);
            float panelWidth = Mathf.Max(1f, cloneRt.rect.width);
            cam.aspect = (float)width / height;
            cam.orthographicSize = panelHeight * 0.5f;
            if (panelWidth / panelHeight > cam.aspect)
                cam.orthographicSize = panelWidth * 0.5f / cam.aspect;

            cam.transform.position = new Vector3(0f, 0f, -10f);

            var rt = new RenderTexture(width, height, 24, RenderTextureFormat.ARGB32);
            rt.Create();
            cam.targetTexture = rt;
            cam.enabled = true;
            return new FrameCapture(cam, rt, canvasGo, camGo);
        }

        public sealed class FrameCapture : System.IDisposable
        {
            public readonly Camera Camera;
            readonly RenderTexture target;
            readonly GameObject canvas;
            readonly GameObject cameraObject;
            bool disposed;

            internal FrameCapture(Camera camera, RenderTexture target, GameObject canvas, GameObject cameraObject)
            {
                Camera = camera;
                this.target = target;
                this.canvas = canvas;
                this.cameraObject = cameraObject;
            }

            public byte[] ReadPng()
            {
                RenderTexture prev = RenderTexture.active;
                RenderTexture.active = target;
                var tex = new Texture2D(target.width, target.height, TextureFormat.RGBA32, false);
                tex.ReadPixels(new Rect(0, 0, target.width, target.height), 0, 0);
                tex.Apply();
                RenderTexture.active = prev;
                byte[] png = tex.EncodeToPNG();
                Object.Destroy(tex);
                return png;
            }

            public void Dispose()
            {
                if (disposed)
                    return;
                disposed = true;
                if (Camera != null)
                    Camera.targetTexture = null;
                if (target != null)
                    Object.Destroy(target);
                if (canvas != null)
                    Object.Destroy(canvas);
                if (cameraObject != null)
                    Object.Destroy(cameraObject);
            }
        }

        public static string WritePng(string characterId, byte[] png)
        {
            string dir = Path.Combine(Application.persistentDataPath, "DressUpExports");
            Directory.CreateDirectory(dir);
            string fileName = NewFileName();
            string fullPath = Path.Combine(dir, fileName);
            File.WriteAllBytes(fullPath, png);
            Debug.Log($"[DressUp] 已导出透明图: {fullPath}");
            return fullPath;
        }

        public static string NewFileName()
        {
            return System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png";
        }

        static void SetLayerRecursive(GameObject go, int layer)
        {
            go.layer = layer;
            for (int i = 0; i < go.transform.childCount; i++)
                SetLayerRecursive(go.transform.GetChild(i).gameObject, layer);
        }
    }
}
