using System.Collections;
using System.Collections.Generic;
using System.IO;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Import;
using DressUp.Wardrobe;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Actions
{
    /// <summary>
    /// 历史衣柜 Page2。返回一直可点。删除和打开默认是灰的，点中某个编号后才亮。
    /// 储存衣柜把整份导入模板写进手机，预览画成 180×180，放进格子里的 Image。
    /// 最左边默认是初始衣柜。满了就提示，不删掉旧的。
    /// </summary>
    public class SaveMaletaHistory : MonoBehaviour
    {
        const int PreviewSize = 180;
        const int SlotCount = 6;
        const string BuiltinId = "builtin";
        const string ChangeHome = "我的衣柜";
        const string ChangeFull = "衣柜已满，请先删除";

        readonly Dictionary<Button, Color> labelColors = new Dictionary<Button, Color>();
        readonly List<Button> slots = new List<Button>();
        readonly List<MaletaRecord> records = new List<MaletaRecord>();
        readonly List<Sprite> runtimeSprites = new List<Sprite>();

        Button backButton;
        Button openButton;
        Button deleteButton;
        Button selected;
        Image frame;
        TMP_Text changeText;
        Sprite builtinArt;
        bool ready;
        bool saving;

        public Button Selected => selected;

        public static void Wire()
        {
            Transform page = FindNamed("Page2");
            if (page == null)
                return;

            SaveMaletaHistory history = page.GetComponent<SaveMaletaHistory>();
            if (history == null)
                history = page.gameObject.AddComponent<SaveMaletaHistory>();
            history.Bind();
            PadHost.Wire();
        }

        void OnEnable()
        {
            if (ready)
                ClearSelection();
        }

        void Bind()
        {
            backButton = FindChildButton("back");
            openButton = FindChildButton("open");
            deleteButton = FindChildButton("delete");
            Listen(backButton, Back);
            Listen(openButton, Open);
            Listen(deleteButton, Delete);
            RememberLabel(deleteButton);
            RememberLabel(openButton);
            if (backButton != null)
                backButton.interactable = true;

            slots.Clear();
            Transform grid = transform.Find("ImageGrid");
            EnsureSixSlots(grid);
            if (grid != null)
            {
                for (int i = 0; i < grid.childCount; i++)
                {
                    Button slot = grid.GetChild(i).GetComponent<Button>();
                    if (slot == null)
                        continue;
                    slots.Add(slot);
                    SaveMaletaSlot marker = slot.GetComponent<SaveMaletaSlot>();
                    if (marker == null)
                        marker = slot.gameObject.AddComponent<SaveMaletaSlot>();
                    marker.Bind(this);
                }
            }

            Transform saveNow = FindNamed("SaveNow");
            if (saveNow != null)
                Listen(saveNow.GetComponent<Button>(), SaveNow);

            Transform clear = FindNamed("ClearMaleta");
            if (clear != null)
                Listen(clear.GetComponent<Button>(), ClearWorking);

            CaptureBuiltinArt();
            LoadRecords();
            Paint();

            Transform historyButton = FindNamed("PreMaleta");
            if (historyButton != null)
                Listen(historyButton.GetComponent<Button>(), ShowHistory);

            Transform opener = FindNamed("ButtonMaleta");
            if (opener != null)
                Listen(opener.GetComponent<Button>(), OpenPad);

            ready = true;
            ClearSelection();
        }

        public void Select(Button slot)
        {
            int index = IndexOf(slot);
            if (slot == null || index < 0 || index >= records.Count)
                return;

            DressUpAudio.Instance?.PlayKey();
            selected = slot;
            EnsureFrame();
            frame.transform.SetParent(slot.transform, false);
            frame.transform.SetAsFirstSibling();
            frame.gameObject.SetActive(true);
            SetActions(true);
        }

        void Back()
        {
            DressUpAudio.Instance?.PlayBack();
            Transform page1 = FindNamed("Page1");
            if (page1 != null)
                page1.gameObject.SetActive(true);
            ClearSelection();
            gameObject.SetActive(false);
        }

        void ClosePad()
        {
            PadHost.Close();
        }

        void OpenPad()
        {
            DressUpAudio.Instance?.PlayKey();
            PadHost.Show("SaveMaleta");
            Transform save = FindNamed("SaveMaleta");
            Transform page1 = save != null ? save.Find("Page1") : FindNamed("Page1");
            if (page1 != null)
                page1.gameObject.SetActive(true);
            SetChange(ChangeHome);
            ClearSelection();
            gameObject.SetActive(false);
        }

        void ShowHistory()
        {
            DressUpAudio.Instance?.PlayKey();
            Transform page1 = FindNamed("Page1");
            if (page1 != null)
                page1.gameObject.SetActive(false);
            gameObject.SetActive(true);
            ClearSelection();
        }

        void SaveNow()
        {
            if (saving)
                return;
            DressUpAudio.Instance?.PlayConfirm();
            if (!HasRoom())
            {
                SetChange(ChangeFull);
                return;
            }

            if (ImportedSave.CountPlayerItems() == 0)
            {
                AndroidImageSaver.Toast("请先导入模板");
                return;
            }

            SetChange(ChangeHome);

            MonoBehaviour host = isActiveAndEnabled ? this : Runner();
            if (host == null)
                return;
            host.StartCoroutine(SaveCurrent());
        }

        void ClearWorking()
        {
            PlayerImportButton import = FindAnyObjectByType<PlayerImportButton>();
            if (import != null)
                import.ClearWardrobe();
        }

        IEnumerator SaveCurrent()
        {
            saving = true;
            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            BodyAvatar avatar = binder != null ? binder.ActiveAvatar : FindAnyObjectByType<BodyAvatar>();
            if (avatar == null || slots.Count == 0)
            {
                saving = false;
                yield break;
            }

            OutfitSnapshot outfit = avatar.CaptureOutfit();
            int source = CaptureSize(avatar);
            AvatarTransparentExporter.FrameCapture capture;
            try
            {
                capture = AvatarTransparentExporter.BeginCapture(avatar, null, source, source);
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning("[DressUp] 储存预览失败：" + exception.Message);
                saving = false;
                yield break;
            }

            yield return null;
            yield return new WaitForEndOfFrame();

            byte[] png;
            try
            {
                png = FitPreview(capture.ReadPng());
            }
            catch (System.Exception exception)
            {
                capture.Dispose();
                Debug.LogWarning("[DressUp] 储存预览失败：" + exception.Message);
                saving = false;
                yield break;
            }

            capture.Dispose();
            if (!HasRoom())
            {
                SetChange(ChangeFull);
                saving = false;
                yield break;
            }

            AndroidImageSaver.Toast("正在储存...");
            yield return null;

            string id = System.Guid.NewGuid().ToString("N");
            string folder = SlotFolder(id);
            bool wrote;
            try
            {
                wrote = ImportedSave.WritePlayerSnapshot(folder, outfit);
                if (wrote && png != null)
                    File.WriteAllBytes(Path.Combine(folder, "preview.png"), png);
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning("[DressUp] 储存衣柜失败：" + exception.Message);
                AndroidImageSaver.Toast("储存失败");
                saving = false;
                yield break;
            }

            if (!wrote)
            {
                AndroidImageSaver.Toast("请先导入模板");
                saving = false;
                yield break;
            }

            records.Insert(0, new MaletaRecord { id = id, builtin = false });
            WriteIndex();
            Paint();
            SetChange(ChangeHome);
            saving = false;
        }

        bool HasRoom()
        {
            return records.Count < SlotCount && records.Count < slots.Count;
        }

        static int CaptureSize(BodyAvatar avatar)
        {
            var panel = avatar != null ? avatar.transform as RectTransform : null;
            if (panel == null)
                return 888;
            int side = Mathf.RoundToInt(Mathf.Max(panel.rect.width, panel.rect.height));
            return Mathf.Clamp(side, PreviewSize, 1024);
        }

        byte[] FitPreview(byte[] png)
        {
            if (png == null || png.Length == 0)
                return png;

            var source = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            if (!source.LoadImage(png))
            {
                Destroy(source);
                return png;
            }

            if (source.width == PreviewSize && source.height == PreviewSize)
            {
                Destroy(source);
                return png;
            }

            source.filterMode = FilterMode.Bilinear;
            RenderTexture rt = RenderTexture.GetTemporary(PreviewSize, PreviewSize, 0, RenderTextureFormat.ARGB32);
            RenderTexture prev = RenderTexture.active;
            Graphics.Blit(source, rt);
            RenderTexture.active = rt;
            var small = new Texture2D(PreviewSize, PreviewSize, TextureFormat.RGBA32, false);
            small.ReadPixels(new Rect(0, 0, PreviewSize, PreviewSize), 0, 0);
            small.Apply();
            RenderTexture.active = prev;
            RenderTexture.ReleaseTemporary(rt);
            byte[] fitted = small.EncodeToPNG();
            Destroy(source);
            Destroy(small);
            return fitted;
        }

        static void EnsureSixSlots(Transform grid)
        {
            if (grid == null)
                return;

            Transform template = null;
            int buttons = 0;
            for (int i = 0; i < grid.childCount; i++)
            {
                Transform child = grid.GetChild(i);
                if (child.GetComponent<Button>() == null)
                    continue;
                buttons++;
                if (template == null)
                    template = child;
            }

            if (template == null)
                return;

            var layout = grid.GetComponent<GridLayoutGroup>();
            if (layout != null)
            {
                layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
                layout.constraintCount = 3;
            }

            while (buttons < SlotCount)
            {
                Transform copy = Object.Instantiate(template, grid);
                copy.name = template.name;
                copy.SetAsLastSibling();
                Image preview = copy.Find("Image") != null ? copy.Find("Image").GetComponent<Image>() : null;
                if (preview != null)
                {
                    preview.sprite = null;
                    preview.enabled = false;
                }

                TMP_Text label = copy.GetComponentInChildren<TMP_Text>(true);
                if (label != null)
                    label.text = (buttons + 1).ToString();
                buttons++;
            }
        }

        void Open()
        {
            int index = IndexOf(selected);
            if (index < 0 || index >= records.Count)
                return;

            DressUpAudio.Instance?.PlayConfirm();
            MaletaRecord record = records[index];
            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            BodyAvatar avatar = binder != null ? binder.ActiveAvatar : FindAnyObjectByType<BodyAvatar>();
            WardrobeController wardrobe = FindAnyObjectByType<WardrobeController>();
            if (record.builtin)
            {
                ImportedSave.UseBuiltin();
                if (binder != null)
                    binder.ResetToDefaultOutfit();
            }
            else
            {
                string folder = SlotFolder(record.id);
                OutfitSnapshot outfit = ImportedSave.ReadSnapshotOutfit(folder);
                ImportedSave.UseSnapshot(folder);
                if (avatar != null)
                    avatar.ApplyOutfit(outfit, wardrobe != null ? wardrobe.Catalog : null);
            }

            if (wardrobe != null)
            {
                wardrobe.RebuildPlots();
                wardrobe.RefreshTagButtons();
            }
            ClosePad();
        }

        void Delete()
        {
            int index = IndexOf(selected);
            if (index < 0 || index >= records.Count)
                return;

            DressUpAudio.Instance?.PlayDelete();
            MaletaRecord record = records[index];
            records.RemoveAt(index);
            if (!record.builtin)
            {
                try
                {
                    string folder = SlotFolder(record.id);
                    if (Directory.Exists(folder))
                        Directory.Delete(folder, true);
                }
                catch (System.Exception exception)
                {
                    Debug.LogWarning("[DressUp] 删除衣柜失败：" + exception.Message);
                }
            }

            WriteIndex();
            Paint();
            ClearSelection();
        }

        void CaptureBuiltinArt()
        {
            if (builtinArt != null || slots.Count == 0)
                return;
            Image image = FindPreview(slots[0]);
            if (image != null)
                builtinArt = image.sprite;
        }

        void LoadRecords()
        {
            records.Clear();
            string path = IndexPath();
            if (!File.Exists(path))
            {
                records.Add(new MaletaRecord { id = BuiltinId, builtin = true });
                WriteIndex();
                return;
            }

            try
            {
                MaletaFile file = JsonUtility.FromJson<MaletaFile>(File.ReadAllText(path));
                if (file?.slots != null)
                    records.AddRange(file.slots);
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning("[DressUp] 读衣柜列表失败：" + exception.Message);
                records.Add(new MaletaRecord { id = BuiltinId, builtin = true });
            }
        }

        void WriteIndex()
        {
            Directory.CreateDirectory(Root());
            var file = new MaletaFile();
            file.slots.AddRange(records);
            File.WriteAllText(IndexPath(), JsonUtility.ToJson(file));
        }

        void Paint()
        {
            for (int i = 0; i < runtimeSprites.Count; i++)
                DestroySprite(runtimeSprites[i]);
            runtimeSprites.Clear();

            for (int i = 0; i < slots.Count; i++)
            {
                bool occupied = i < records.Count;
                Image image = occupied ? EnsurePreview(slots[i]) : FindPreview(slots[i]);
                if (image == null)
                    continue;
                if (!occupied)
                {
                    image.sprite = null;
                    image.enabled = false;
                    continue;
                }

                MaletaRecord record = records[i];
                if (record.builtin)
                {
                    image.sprite = builtinArt;
                    image.enabled = builtinArt != null;
                    image.preserveAspect = true;
                    continue;
                }

                Sprite preview = LoadPreview(record.id);
                image.sprite = preview;
                image.enabled = preview != null;
                image.preserveAspect = true;
                image.color = Color.white;
                if (preview != null)
                    runtimeSprites.Add(preview);
            }
        }

        Image EnsurePreview(Button slot)
        {
            Image image = FindPreview(slot);
            if (image != null || slot == null)
                return image;

            var go = new GameObject("Image", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(slot.transform, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = new Vector2(PreviewSize, PreviewSize);
            image = go.GetComponent<Image>();
            image.raycastTarget = false;
            image.preserveAspect = true;
            return image;
        }

        static Image FindPreview(Button slot)
        {
            if (slot == null)
                return null;
            Transform child = slot.transform.Find("Image");
            return child != null ? child.GetComponent<Image>() : null;
        }

        Sprite LoadPreview(string id)
        {
            string path = Path.Combine(SlotFolder(id), "preview.png");
            if (!File.Exists(path))
                return null;
            byte[] png = File.ReadAllBytes(path);
            return SpriteFromPng(png);
        }

        static string Root()
        {
            return Path.Combine(Application.persistentDataPath, "DressUpMaletas");
        }

        static string IndexPath()
        {
            return Path.Combine(Root(), "index.json");
        }

        static string SlotFolder(string id)
        {
            return Path.Combine(Root(), id);
        }

        int IndexOf(Button slot)
        {
            if (slot == null)
                return -1;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i] == slot)
                    return i;
            }

            return -1;
        }

        static Sprite SpriteFromPng(byte[] png)
        {
            if (png == null || png.Length == 0)
                return null;
            var tex = new Texture2D(PreviewSize, PreviewSize, TextureFormat.RGBA32, false);
            if (!tex.LoadImage(png))
            {
                Destroy(tex);
                return null;
            }

            tex.filterMode = FilterMode.Bilinear;
            return Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
        }

        void DestroySprite(Sprite sprite)
        {
            if (sprite == null || sprite == builtinArt)
                return;
            if (sprite.texture != null)
                Destroy(sprite.texture);
            Destroy(sprite);
        }

        MonoBehaviour Runner()
        {
            Transform pad = FindNamed("Pad");
            if (pad == null)
                return null;
            SaveMaletaRunner runner = pad.GetComponent<SaveMaletaRunner>();
            if (runner == null)
                runner = pad.gameObject.AddComponent<SaveMaletaRunner>();
            return runner;
        }

        void ClearSelection()
        {
            selected = null;
            if (frame != null)
                frame.gameObject.SetActive(false);
            SetActions(false);
        }

        void SetActions(bool on)
        {
            if (backButton != null)
                backButton.interactable = true;
            if (deleteButton != null)
                deleteButton.interactable = on;
            if (openButton != null)
                openButton.interactable = on;
            DimLabel(deleteButton, on);
            DimLabel(openButton, on);
        }

        void RememberLabel(Button button)
        {
            if (button == null || labelColors.ContainsKey(button))
                return;
            TMP_Text text = button.GetComponentInChildren<TMP_Text>(true);
            if (text != null)
                labelColors[button] = text.color;
        }

        void DimLabel(Button button, bool lit)
        {
            if (button == null)
                return;
            TMP_Text text = button.GetComponentInChildren<TMP_Text>(true);
            if (text == null || !labelColors.TryGetValue(button, out Color color))
                return;
            text.color = lit ? color : new Color(color.r, color.g, color.b, color.a * 0.45f);
        }

        void EnsureFrame()
        {
            if (frame != null)
                return;

            var go = new GameObject("SelectedFrame", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = new Vector2(4f, 4f);
            rect.offsetMax = new Vector2(-4f, -4f);
            frame = go.GetComponent<Image>();
            frame.sprite = FrameSprite();
            frame.type = Image.Type.Sliced;
            frame.color = new Color(0.72f, 0.32f, 0.12f, 1f);
            frame.raycastTarget = false;
        }

        static Sprite frameSprite;

        static Sprite FrameSprite()
        {
            if (frameSprite != null)
                return frameSprite;

            const int size = 64;
            const int edge = 6;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            var pixels = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    bool border = x < edge || y < edge || x >= size - edge || y >= size - edge;
                    pixels[y * size + x] = border
                        ? new Color32(255, 255, 255, 255)
                        : new Color32(255, 255, 255, 0);
                }
            }

            tex.SetPixels32(pixels);
            tex.Apply();
            frameSprite = Sprite.Create(
                tex,
                new Rect(0, 0, size, size),
                new Vector2(0.5f, 0.5f),
                100f,
                0,
                SpriteMeshType.FullRect,
                new Vector4(edge, edge, edge, edge));
            return frameSprite;
        }

        void SetChange(string message)
        {
            if (changeText == null)
            {
                Transform save = FindNamed("SaveMaleta");
                Transform change = save != null ? save.Find("Change") : FindNamed("Change");
                if (change != null)
                    changeText = change.GetComponent<TMP_Text>();
            }

            if (changeText != null)
                changeText.text = message;
        }

        Button FindChildButton(string objectName)
        {
            Transform child = transform.Find(objectName);
            return child != null ? child.GetComponent<Button>() : null;
        }

        static void Listen(Button button, UnityEngine.Events.UnityAction action)
        {
            if (button == null)
                return;
            button.onClick.RemoveListener(action);
            button.onClick.AddListener(action);
        }

        static Transform FindNamed(string objectName)
        {
            Transform[] all = UnityEngine.Object.FindObjectsByType<Transform>(FindObjectsInactive.Include);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] != null && all[i].name == objectName)
                    return all[i];
            }

            return null;
        }
    }

    /// <summary>储存页把历史页关掉时，协程挂在一直开着的 Pad 上。</summary>
    public class SaveMaletaRunner : MonoBehaviour
    {
    }

    public class SaveMaletaSlot : MonoBehaviour
    {
        SaveMaletaHistory owner;

        public void Bind(SaveMaletaHistory history)
        {
            owner = history;
            Button button = GetComponent<Button>();
            if (button == null)
                return;
            button.onClick.RemoveListener(Click);
            button.onClick.AddListener(Click);
        }

        void Click()
        {
            if (owner != null)
                owner.Select(GetComponent<Button>());
        }
    }

    [System.Serializable]
    public class MaletaRecord
    {
        public string id;
        public bool builtin;
    }

    [System.Serializable]
    public class MaletaFile
    {
        public List<MaletaRecord> slots = new List<MaletaRecord>();
    }
}
