using System.Runtime.InteropServices;
using UnityEngine;

namespace DressUp.Actions
{
    public static class WebGlImageSaver
    {
#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        static extern void DressUpSaveImage(byte[] data, int size, string filename);
#endif

        public static void Save(string filename, byte[] png)
        {
            if (png == null || png.Length == 0)
                return;

#if UNITY_WEBGL && !UNITY_EDITOR
            DressUpSaveImage(png, png.Length, filename);
#else
            Debug.Log($"[DressUp] 浏览器保存只在网页包里生效: {filename}");
#endif
        }
    }
}
