using UnityEngine;

namespace DressUp.Audio
{
    /// <summary>
    /// 换装音效 / BGM。场景里放一个即可；没有时会自动创建。
    /// 默认从 Resources/Audio 加载。
    /// </summary>
    public class DressUpAudio : MonoBehaviour
    {
        public static DressUpAudio Instance { get; private set; }

        [Header("SFX")]
        [SerializeField] AudioClip selectClip;
        [SerializeField] AudioClip popupClip;
        [SerializeField] AudioClip errorClip;
        [SerializeField] AudioClip error2Clip;
        [SerializeField] AudioClip confirmClip;
        [SerializeField] AudioClip backClip;
        [SerializeField] AudioClip deleteClip;

        [Header("BGM")]
        [SerializeField] AudioClip bgmClip;
        [SerializeField] [Range(0f, 1f)] float bgmVolume = 0.35f;
        [SerializeField] [Range(0f, 1f)] float sfxVolume = 1f;

        AudioSource sfxSource;
        AudioSource bgmSource;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void EnsureExists()
        {
            if (Instance != null)
                return;

            var existing = Object.FindAnyObjectByType<DressUpAudio>();
            if (existing != null)
            {
                Instance = existing;
                return;
            }

            var go = new GameObject("DressUpAudio");
            DontDestroyOnLoad(go);
            Instance = go.AddComponent<DressUpAudio>();
        }

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            EnsureSources();
            ResolveClips();
        }

        void Start()
        {
            ResolveClips();
            PlayBgm();
        }

        void ResolveClips()
        {
            if (selectClip == null)
                selectClip = LoadClip("select");
            if (popupClip == null)
                popupClip = LoadClip("Popup");
            if (errorClip == null)
                errorClip = LoadClip("Error");
            if (error2Clip == null)
                error2Clip = LoadClip("Error2");
            if (confirmClip == null)
                confirmClip = LoadClip("select");
            if (backClip == null)
                backClip = LoadClip("undo");
            if (deleteClip == null)
                deleteClip = LoadClip("Error");
            if (bgmClip == null)
                bgmClip = LoadClip("Lofi1");
        }

        static AudioClip LoadClip(string resourcesName)
        {
            if (string.IsNullOrEmpty(resourcesName))
                return null;

            // 优先 Resources/Audio，兼容旧 DressUp 路径。
            AudioClip clip = Resources.Load<AudioClip>("Audio/" + resourcesName);
            if (clip != null)
                return clip;
            clip = Resources.Load<AudioClip>("DressUp/" + resourcesName);
            if (clip != null)
                return clip;
            return Resources.Load<AudioClip>(resourcesName);
        }

        void EnsureSources()
        {
            if (sfxSource == null)
            {
                sfxSource = gameObject.AddComponent<AudioSource>();
                sfxSource.playOnAwake = false;
                sfxSource.loop = false;
            }

            if (bgmSource == null)
            {
                bgmSource = gameObject.AddComponent<AudioSource>();
                bgmSource.playOnAwake = false;
                bgmSource.loop = true;
            }
        }

        public void PlaySelect() => PlaySfx(selectClip);
        /// <summary>按键音：我的衣柜 / 储存衣柜 / 历史衣柜等。</summary>
        public void PlayKey() => PlaySfx(selectClip);
        public void PlayPopup() => PlaySfx(popupClip);
        public void PlayError() => PlaySfx(errorClip);
        public void PlayError2() => PlaySfx(error2Clip);
        public void PlayConfirm() => PlaySfx(selectClip);
        public void PlayBack() => PlaySfx(selectClip);
        public void PlayDelete() => PlaySfx(deleteClip != null ? deleteClip : errorClip);
        /// <summary>Clear / 切角色。</summary>
        public void PlayClear() => PlaySfx(errorClip);

        public void PlayBgm()
        {
            EnsureSources();
            ResolveClips();
            if (bgmClip == null || bgmSource == null)
                return;

            if (bgmSource.clip == bgmClip && bgmSource.isPlaying)
                return;

            bgmSource.clip = bgmClip;
            bgmSource.volume = bgmVolume;
            bgmSource.loop = true;
            bgmSource.Play();
        }

        void PlaySfx(AudioClip clip)
        {
            ResolveClips();
            if (clip == null)
                return;
            EnsureSources();
            sfxSource.PlayOneShot(clip, sfxVolume);
        }
    }
}
