using System;
using System.Collections.Generic;
using DressUp.Actions;
using DressUp.Import;
using DressUp.Audio;
using DressUp.Tinting;
using DressUp.Data;
using DressUp.Motion;
using DressUp.Wardrobe;
using UnityEngine;

namespace DressUp.Avatar
{
    [Serializable]
    public class TagSlotDef
    {
        public string category = "";
        public bool active = true;
        [Tooltip("空 = 保留/恢复场景里原有 Tag 图标（BodyPanel）；古鸟填 Art/maleta/Tag_*")]
        public Sprite icon;
    }

    [Serializable]
    public class CharacterBinding
    {
        public string displayName;
        [Tooltip("与密码锁 templateId 对齐：BodyPanel / GuNiao")]
        public string templateId;
        public GameObject bodyPanelRoot;
        public BodyAvatar avatar;
        public ClothingCatalog catalog;
        [Tooltip("空着时，BodyPanel 直接用 Tag 按钮上 Wardrobe Tag 的 Category。古鸟仍用自己的一套。")]
        public List<TagSlotDef> tagASlots = new List<TagSlotDef>();
        [Tooltip("无存档时的初始穿戴（Catalog itemId）")]
        public List<string> defaultOutfitItemIds = new List<string>();
    }

    /// <summary>
    /// 同步按钮等到当前角色。密码解锁时按 templateId 切换并重绑 TagA。
    /// </summary>
    public class ActiveAvatarBinder : MonoBehaviour
    {
        [SerializeField] List<CharacterBinding> characters = new List<CharacterBinding>();
        [SerializeField] int activeIndex;

        [Header("同步目标（可空）")]
        [SerializeField] WardrobeController wardrobe;
        [SerializeField] LayerColorController colorController;
        [SerializeField] AvatarExportButton exportButton;
        [SerializeField] AvatarClearButton clearButton;
        [SerializeField] AvatarRandomButton randomButton;
        [SerializeField] AvatarSaveButton saveButton;

        [Tooltip("进游戏时是否自动读档。关闭则穿该角色 defaultOutfitItemIds")]
        [SerializeField] bool loadOutfitOnStart;

        [Tooltip("兼容旧场景：角色绑定未填 default 时用这份")]
        [SerializeField] List<string> defaultOutfitItemIds = new List<string>();

        WardrobeTagNavigator tagNavigator;

        public int ActiveIndex => activeIndex;
        public BodyAvatar ActiveAvatar => ResolveAvatar();
        public ClothingCatalog ActiveCatalog => ResolveCatalog(ResolveAvatar());
        public string ActiveTemplateId
        {
            get
            {
                if (characters == null || activeIndex < 0 || activeIndex >= characters.Count)
                    return ActiveTemplateIds.BodyPanel;
                CharacterBinding binding = characters[activeIndex];
                if (!string.IsNullOrEmpty(binding.templateId))
                    return binding.templateId;
                return string.IsNullOrEmpty(binding.displayName)
                    ? ActiveTemplateIds.BodyPanel
                    : binding.displayName;
            }
        }

        void Start()
        {
            SaveMaletaHistory.Wire();
            EnsureTagNavigator();
            EnsureDefaultProfiles();

            // 记住解锁时优先切到对应模板（避免与 PasscodePrompt 抢 Start 顺序）
            PasscodeConfig passcode = Resources.Load<PasscodeConfig>(PasscodePrompt.ResourcePath);
            if (passcode != null && passcode.IsRememberedUnlocked())
            {
                int remembered = FindTemplateIndex(passcode.GetRememberedTemplateId());
                if (remembered >= 0)
                    activeIndex = remembered;
            }

            if (characters != null && characters.Count > 0)
            {
                activeIndex = Mathf.Clamp(activeIndex, 0, characters.Count - 1);
                for (int i = 0; i < characters.Count; i++)
                {
                    CharacterBinding binding = characters[i];
                    if (binding.bodyPanelRoot != null)
                        binding.bodyPanelRoot.SetActive(i == activeIndex);
                }

                CharacterBinding current = characters[activeIndex];
                if (current.avatar != null)
                {
                    WireTo(current.avatar, current.catalog, false);
                    ApplyTagProfileForActive();
                    ApplySavedOrInitial(current.avatar, current.catalog);
                    return;
                }
            }

            BodyAvatar avatar = ResolveAvatar();
            ClothingCatalog catalog = ResolveCatalog(avatar);
            if (avatar == null)
            {
                Debug.LogWarning(
                    "[DressUpBinder] 找不到可用 BodyAvatar。请在 Maleta 的 WardrobeController 上指定 Target Avatar。",
                    this);
                return;
            }

            SyncActiveIndexToAvatar(avatar);
            WireTo(avatar, catalog, false);
            ApplyTagProfileForActive();
            ApplySavedOrInitial(avatar, catalog);
        }

        int FindTemplateIndex(string templateId)
        {
            if (string.IsNullOrEmpty(templateId) || characters == null)
                return -1;
            for (int i = 0; i < characters.Count; i++)
            {
                CharacterBinding binding = characters[i];
                if (binding == null)
                    continue;
                if (IdsMatch(binding.templateId, templateId)
                    || IdsMatch(binding.displayName, templateId)
                    || IdsMatch(binding.avatar != null ? binding.avatar.CharacterId : null, templateId))
                    return i;
            }

            return -1;
        }

        public void SelectByTemplateId(string templateId)
        {
            if (string.IsNullOrEmpty(templateId) || characters == null)
                return;

            for (int i = 0; i < characters.Count; i++)
            {
                CharacterBinding binding = characters[i];
                if (binding == null)
                    continue;
                if (IdsMatch(binding.templateId, templateId)
                    || IdsMatch(binding.displayName, templateId)
                    || IdsMatch(binding.avatar != null ? binding.avatar.CharacterId : null, templateId))
                {
                    SelectByIndex(i);
                    return;
                }
            }

            Debug.LogWarning($"[DressUpBinder] 找不到模板「{templateId}」。", this);
        }

        public void SelectByIndex(int index)
        {
            if (characters == null || characters.Count == 0)
                return;

            EnsureTagNavigator();
            EnsureDefaultProfiles();

            int next = Mathf.Clamp(index, 0, characters.Count - 1);
            bool switched = next != activeIndex;
            activeIndex = next;

            for (int i = 0; i < characters.Count; i++)
            {
                CharacterBinding binding = characters[i];
                if (binding.bodyPanelRoot != null)
                    binding.bodyPanelRoot.SetActive(i == activeIndex);
            }

            CharacterBinding current = characters[activeIndex];
            if (current.avatar == null)
            {
                Debug.LogWarning($"[DressUpBinder] 模板「{current.displayName}」未绑定 Avatar。", this);
                return;
            }

            WireTo(current.avatar, current.catalog, false);
            ApplyTagProfileForActive();
            ApplySavedOrInitial(current.avatar, current.catalog);

            if (switched)
                DressUpAudio.Instance?.PlayClear();
        }

        void ApplyTagProfileForActive()
        {
            if (characters == null || activeIndex < 0 || activeIndex >= characters.Count)
                return;
            CharacterBinding current = characters[activeIndex];
            if (tagNavigator == null || current?.tagASlots == null)
                return;

            tagNavigator.ApplyTagASlots(current.tagASlots);
            wardrobe?.RebindAllTags();
            wardrobe?.ClearCategoryView();
            wardrobe?.RefreshTagButtons();
        }

        void ApplySavedOrInitial(BodyAvatar avatar, ClothingCatalog catalog)
        {
            ImportedSave.EnsureLoaded();
            if (ImportedSave.TryApplyOutfit(avatar, catalog))
            {
                wardrobe?.RefreshSelection();
                wardrobe?.RefreshTagButtons();
                return;
            }

            bool loaded = loadOutfitOnStart && saveButton != null && saveButton.Load();
            if (!loaded)
            {
                avatar.ClearClothes();
                ApplyDefaultOutfit(avatar, catalog);
            }

            wardrobe?.RefreshSelection();
            wardrobe?.RefreshTagButtons();
        }

        /// <summary>清空改色记忆 + 衣服，再穿回该角色 defaultOutfitItemIds。</summary>
        public void ResetToDefaultOutfit()
        {
            BodyAvatar avatar = ResolveAvatar();
            ClothingCatalog catalog = ResolveCatalog(avatar);
            if (avatar == null)
                return;

            avatar.ClearChosenColors();
            avatar.ClearClothes();
            ApplyDefaultOutfit(avatar, catalog);

            wardrobe?.RefreshSelection();
            wardrobe?.RefreshTagButtons();
            colorController?.ClearTintTarget();
        }

        public void ApplyDefaultOutfit(BodyAvatar avatar, ClothingCatalog catalog)
        {
            if (avatar == null || catalog == null)
                return;

            List<string> ids = null;
            if (characters != null && activeIndex >= 0 && activeIndex < characters.Count)
                ids = characters[activeIndex].defaultOutfitItemIds;
            if (ids == null || ids.Count == 0)
                ids = defaultOutfitItemIds;
            if (ids == null)
                return;

            for (int i = 0; i < ids.Count; i++)
            {
                string id = ids[i];
                if (string.IsNullOrEmpty(id))
                    continue;

                ClothingItem item = catalog.Find(id);
                if (item == null)
                {
                    Debug.LogWarning($"[DressUpBinder] 初始穿戴找不到「{id}」", this);
                    continue;
                }

                if (item.CollectFillSprites().Count == 0)
                    continue;

                avatar.Equip(item);
            }
        }

        public void SelectByCharacterId(string characterId)
        {
            for (int i = 0; i < characters.Count; i++)
            {
                CharacterBinding binding = characters[i];
                if (binding.avatar != null && binding.avatar.CharacterId == characterId)
                {
                    SelectByIndex(i);
                    return;
                }
            }
        }

        void WireTo(BodyAvatar avatar, ClothingCatalog catalog, bool loadSavedOutfit)
        {
            if (wardrobe != null)
            {
                wardrobe.SetTargetAvatar(avatar);
                if (catalog != null)
                    wardrobe.SetCatalog(catalog);
                wardrobe.SetColorController(colorController);
            }

            EnsureWearPop(avatar);

            if (exportButton != null)
                exportButton.SetTargetAvatar(avatar);

            if (clearButton != null)
            {
                clearButton.SetTargetAvatar(avatar);
                clearButton.SetWardrobe(wardrobe);
                clearButton.SetColorController(colorController);
            }

            if (randomButton != null)
            {
                randomButton.SetTargetAvatar(avatar);
                randomButton.SetCatalog(catalog);
                randomButton.SetWardrobe(wardrobe);
                randomButton.SetColorController(colorController);
            }

            if (saveButton != null)
            {
                saveButton.SetTargetAvatar(avatar);
                saveButton.SetCatalog(catalog);
                if (loadSavedOutfit)
                    saveButton.Load();
            }
        }

        BodyAvatar ResolveAvatar()
        {
            if (wardrobe != null && wardrobe.TargetAvatar != null)
                return wardrobe.TargetAvatar;

            if (characters != null)
            {
                for (int i = 0; i < characters.Count; i++)
                {
                    CharacterBinding binding = characters[i];
                    if (binding?.avatar == null)
                        continue;
                    if (binding.bodyPanelRoot != null && binding.bodyPanelRoot.activeInHierarchy)
                        return binding.avatar;
                    if (binding.avatar.gameObject.activeInHierarchy)
                        return binding.avatar;
                }

                if (activeIndex >= 0 && activeIndex < characters.Count && characters[activeIndex].avatar != null)
                    return characters[activeIndex].avatar;
            }

            return FindAnyObjectByType<BodyAvatar>();
        }

        ClothingCatalog ResolveCatalog(BodyAvatar avatar)
        {
            if (wardrobe != null && wardrobe.Catalog != null)
                return wardrobe.Catalog;

            if (avatar != null && characters != null)
            {
                for (int i = 0; i < characters.Count; i++)
                {
                    if (characters[i].avatar == avatar && characters[i].catalog != null)
                        return characters[i].catalog;
                }
            }

            return null;
        }

        void SyncActiveIndexToAvatar(BodyAvatar avatar)
        {
            if (avatar == null || characters == null)
                return;
            for (int i = 0; i < characters.Count; i++)
            {
                if (characters[i].avatar == avatar)
                {
                    activeIndex = i;
                    return;
                }
            }
        }

        void EnsureTagNavigator()
        {
            if (tagNavigator != null)
                return;
            if (wardrobe != null)
                tagNavigator = wardrobe.GetComponent<WardrobeTagNavigator>()
                               ?? wardrobe.GetComponentInChildren<WardrobeTagNavigator>(true);
            if (tagNavigator == null)
                tagNavigator = FindAnyObjectByType<WardrobeTagNavigator>();
        }

        void EnsureDefaultProfiles()
        {
            if (characters == null)
                return;

            for (int i = 0; i < characters.Count; i++)
            {
                CharacterBinding binding = characters[i];
                if (binding == null)
                    continue;

                if (string.IsNullOrEmpty(binding.templateId))
                {
                    if (IdsMatch(binding.displayName, ActiveTemplateIds.GuNiao)
                        || (binding.avatar != null && IdsMatch(binding.avatar.CharacterId, ActiveTemplateIds.GuNiao)))
                        binding.templateId = ActiveTemplateIds.GuNiao;
                    else
                        binding.templateId = ActiveTemplateIds.BodyPanel;
                }

                if (binding.tagASlots != null && binding.tagASlots.Count > 0)
                {
                    // 古鸟槽已有但缺图标时补上 Art/maleta
                    if (IdsMatch(binding.templateId, ActiveTemplateIds.GuNiao))
                        FillGuNiaoIconsIfMissing(binding.tagASlots);
                    continue;
                }

                binding.tagASlots = IdsMatch(binding.templateId, ActiveTemplateIds.GuNiao)
                    ? CreateGuNiaoTagA()
                    : CaptureBodyPanelTagA();
            }
        }

        List<TagSlotDef> CaptureBodyPanelTagA()
        {
            EnsureTagNavigator();
            if (tagNavigator != null)
            {
                List<TagSlotDef> scene = tagNavigator.CaptureTagASlots();
                if (scene != null && scene.Count > 0)
                    return scene;
            }

            return CreateBodyPanelTagA();
        }

        public static List<TagSlotDef> CreateBodyPanelTagA()
        {
            return new List<TagSlotDef>
            {
                new TagSlotDef { category = "人模", active = true },
                new TagSlotDef { category = "眼睛", active = true },
                new TagSlotDef { category = "眉毛", active = true },
                new TagSlotDef { category = "嘴", active = true },
                new TagSlotDef { category = "头发", active = true },
                new TagSlotDef { category = "衣服", active = true },
                new TagSlotDef { category = "裤子", active = true },
                new TagSlotDef { category = "鞋子", active = true },
                new TagSlotDef { category = "袜子", active = true },
                new TagSlotDef { category = "外套", active = true },
                new TagSlotDef { category = "其它饰品", active = true },
                new TagSlotDef { category = "未分类", active = true }
            };
        }

        public const string GuNiaoTagIconsResource = "DressUp/GuNiaoTagIcons";

        public static List<TagSlotDef> CreateGuNiaoTagA()
        {
            TagIconSet icons = Resources.Load<TagIconSet>(GuNiaoTagIconsResource);
            if (icons != null)
                return icons.CreateGuNiaoSlots();

            Debug.LogWarning($"[DressUpBinder] 找不到 {GuNiaoTagIconsResource}，古鸟 Tag 将无专用图标。");
            return new List<TagSlotDef>
            {
                new TagSlotDef { category = "Hair", active = true },
                new TagSlotDef { category = "Top", active = true },
                new TagSlotDef { category = "Pant", active = true },
                new TagSlotDef { category = "Dec", active = true },
                new TagSlotDef { category = "Back", active = true },
                new TagSlotDef { category = "Hat", active = true },
                new TagSlotDef { category = "Hand", active = true },
                new TagSlotDef { category = "Shoes", active = true }
            };
        }

        static void FillGuNiaoIconsIfMissing(List<TagSlotDef> slots)
        {
            if (slots == null)
                return;
            bool anyMissing = false;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i] != null && slots[i].icon == null)
                {
                    anyMissing = true;
                    break;
                }
            }

            if (!anyMissing)
                return;

            List<TagSlotDef> filled = CreateGuNiaoTagA();
            for (int i = 0; i < slots.Count && i < filled.Count; i++)
            {
                if (slots[i] == null)
                    slots[i] = filled[i];
                else if (slots[i].icon == null)
                    slots[i].icon = filled[i].icon;
            }
        }

        static bool IdsMatch(string a, string b)
        {
            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b))
                return false;
            return string.Equals(a.Trim(), b.Trim(), StringComparison.OrdinalIgnoreCase);
        }

        static void EnsureWearPop(BodyAvatar avatar)
        {
            if (avatar == null)
                return;
            if (avatar.GetComponent<BodyAvatarWearPop>() == null)
                avatar.gameObject.AddComponent<BodyAvatarWearPop>();
        }
    }
}
