using System.Collections.Generic;
using DressUp.Data;
using DressUp.Motion;
using UnityEngine;

namespace DressUp.Avatar
{
    /// <summary>
    /// 订阅 BodyAvatar.Equipped，穿上时只对「新穿上的前件」做 WearPop（双饰品时旧件在 _back 不弹）。
    /// </summary>
    [RequireComponent(typeof(BodyAvatar))]
    public class BodyAvatarWearPop : MonoBehaviour
    {
        [SerializeField] BodyAvatar avatar;
        [SerializeField] AvatarWearPopMotion popMotion;

        readonly List<RectTransform> partBuffer = new List<RectTransform>(8);

        void Awake()
        {
            if (avatar == null)
                avatar = GetComponent<BodyAvatar>();
            if (popMotion == null)
                popMotion = GetComponent<AvatarWearPopMotion>() ?? gameObject.AddComponent<AvatarWearPopMotion>();
        }

        void OnEnable()
        {
            if (avatar != null)
                avatar.Equipped += HandleEquipped;
        }

        void OnDisable()
        {
            if (avatar != null)
                avatar.Equipped -= HandleEquipped;
        }

        void HandleEquipped(BodyAvatar body, ClothingItem item)
        {
            if (item == null || popMotion == null || body == null)
                return;

            PopLayerParts(body, item.layerName);

            if (item.HasCompanion && !string.IsNullOrEmpty(item.tintCompanionLayer))
                PopLayerParts(body, item.tintCompanionLayer);
        }

        /// <summary>只弹指定层（随机换装：仅本轮随机到的部件，保留件不 DUANG）。</summary>
        public void PopLayers(IEnumerable<string> layerNames)
        {
            if (avatar == null || popMotion == null || layerNames == null)
                return;

            var seen = new HashSet<string>(System.StringComparer.OrdinalIgnoreCase);
            foreach (string layerName in layerNames)
            {
                if (string.IsNullOrEmpty(layerName) || !seen.Add(layerName))
                    continue;
                PopLayerParts(avatar, layerName);
            }
        }

        void PopLayerParts(BodyAvatar body, string layerName)
        {
            if (string.IsNullOrEmpty(layerName))
                return;

            // 不缩大画布父节点（会像整个人胀）；缩该部件下的 S/B，且共用一个弹簧。
            if (body.TryGetLayerRootRect(layerName, out RectTransform root))
                root.localScale = Vector3.one;

            body.CollectActivePartRects(layerName, partBuffer);
            if (partBuffer.Count == 0)
                return;
            popMotion.PlayGroup(partBuffer);
        }
    }
}
