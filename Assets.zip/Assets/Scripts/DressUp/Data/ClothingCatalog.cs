using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Data
{
    [CreateAssetMenu(fileName = "ClothingCatalog", menuName = "DressUp/Clothing Catalog", order = 0)]
    public class ClothingCatalog : ScriptableObject
    {
        [Tooltip("先在这里配：每个 Tag 叫什么、包含哪些图层。不同 BodyPanel 用不同 Catalog")]
        public List<WardrobeTagDef> tags = new List<WardrobeTagDef>();

        [Tooltip("衣服列表：每件只记属于哪个图层")]
        public List<ClothingItem> items = new List<ClothingItem>();

        [Tooltip("导入用：文件名前缀 → 图层名。如 Pant→Pants。可在图鉴浏览器③里改")]
        public List<FilePrefixAlias> filePrefixAliases = new List<FilePrefixAlias>();

        public static List<FilePrefixAlias> CreateDefaultAliases()
        {
            return new List<FilePrefixAlias>
            {
                new FilePrefixAlias { filePrefix = "Pant", layerName = "Pants" },
                new FilePrefixAlias { filePrefix = "HatBack", layerName = "BackHat" },
                new FilePrefixAlias { filePrefix = "BackHair", layerName = "HairBack" }
            };
        }

        public void EnsureDefaultAliasesIfEmpty()
        {
            if (filePrefixAliases == null)
                filePrefixAliases = new List<FilePrefixAlias>();
            if (filePrefixAliases.Count == 0)
                filePrefixAliases.AddRange(CreateDefaultAliases());
        }

        public WardrobeTagDef FindTag(string tagName)
        {
            if (tags == null || string.IsNullOrEmpty(tagName))
                return null;

            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag != null && tag.tagName == tagName)
                    return tag;
            }

            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag != null && string.Equals(tag.tagName, tagName, System.StringComparison.OrdinalIgnoreCase))
                    return tag;
            }

            // 特例：导入页「角」并进兽耳（层 J）；图鉴不单独建角 Tag。
            if (tagName == "角")
                return FindTagExact("兽耳");
            // 特例：导入页「纹身」并进人模（层 WS）；图鉴不单独建纹身 Tag。
            if (tagName == "纹身")
                return FindTagExact("人模");

            // 图层代号反查，例如 RM → 人模
            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag?.layers == null)
                    continue;
                for (int layer = 0; layer < tag.layers.Count; layer++)
                {
                    if (string.Equals(tag.layers[layer], tagName, System.StringComparison.OrdinalIgnoreCase))
                        return tag;
                }
            }

            return null;
        }

        /// <summary>叶子 Tag 的主图层代号；多图层时取第一项。角→J，纹身→WS。</summary>
        public string PrimaryLayerForTag(string tagName)
        {
            if (tagName == "角")
                return "J";
            if (tagName == "纹身")
                return "WS";
            WardrobeTagDef tag = FindTag(tagName);
            if (tag?.layers == null || tag.layers.Count == 0)
                return tagName;
            return tag.layers[0];
        }

        WardrobeTagDef FindTagExact(string tagName)
        {
            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag != null && string.Equals(tag.tagName, tagName, System.StringComparison.OrdinalIgnoreCase))
                    return tag;
            }

            return null;
        }

        public bool LayerBelongsToTag(string layerName, string tagName)
        {
            WardrobeTagDef tag = FindTag(tagName);
            if (tag?.layers == null)
                return false;

            for (int i = 0; i < tag.layers.Count; i++)
            {
                if (tag.layers[i] == layerName)
                    return true;
            }

            return false;
        }

        /// <summary>解析后的规范 Tag 名（角→兽耳、纹身→人模等）。</summary>
        public string ResolveTagName(string tagName)
        {
            WardrobeTagDef tag = FindTag(tagName);
            return tag != null ? tag.tagName : tagName;
        }

        public bool HasChildTags(string parentTagName)
        {
            return GetChildTags(parentTagName).Count > 0;
        }

        /// <summary>某一级下的二级 Tag（按 Catalog 顺序）。</summary>
        public List<WardrobeTagDef> GetChildTags(string parentTagName)
        {
            var result = new List<WardrobeTagDef>();
            if (tags == null || string.IsNullOrEmpty(parentTagName))
                return result;

            string resolved = ResolveTagName(parentTagName);
            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag == null || string.IsNullOrEmpty(tag.parentTag))
                    continue;

                if (string.Equals(tag.parentTag, resolved, System.StringComparison.OrdinalIgnoreCase)
                    || string.Equals(tag.parentTag, parentTagName, System.StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(tag);
                }
            }

            return result;
        }

        public List<WardrobeTagDef> GetRootTags()
        {
            var result = new List<WardrobeTagDef>();
            if (tags == null)
                return result;

            for (int i = 0; i < tags.Count; i++)
            {
                WardrobeTagDef tag = tags[i];
                if (tag != null && tag.IsRoot && !string.IsNullOrEmpty(tag.tagName))
                    result.Add(tag);
            }

            return result;
        }

        /// <summary>点某个 Tag 时，列出该 Tag 下所有图层上的衣服。</summary>
        public List<ClothingItem> GetItemsForTag(string tagName)
        {
            var result = new List<ClothingItem>();
            WardrobeTagDef tag = FindTag(tagName);
            if (tag?.layers == null || items == null)
                return result;

            // 有子 Tag 的一级本身不直接列衣服（由二级分别列）
            if (HasChildTags(tag.tagName) && tag.layers.Count == 0)
                return result;

            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (item == null || string.IsNullOrEmpty(item.layerName))
                    continue;

                for (int L = 0; L < tag.layers.Count; L++)
                {
                    if (tag.layers[L] == item.layerName)
                    {
                        result.Add(item);
                        break;
                    }
                }
            }

            return result;
        }

        public List<ClothingItem> GetItemsForLayer(string layerName)
        {
            var result = new List<ClothingItem>();
            if (items == null || string.IsNullOrEmpty(layerName))
                return result;

            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (item != null && item.layerName == layerName)
                    result.Add(item);
            }

            return result;
        }

        public ClothingItem Find(string itemId)
        {
            if (items == null || string.IsNullOrEmpty(itemId))
                return null;

            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (item != null && item.itemId == itemId)
                    return item;
            }

            return null;
        }

        public ClothingItem Find(string layerName, string itemId)
        {
            if (items == null)
                return null;

            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (item != null && item.layerName == layerName && item.itemId == itemId)
                    return item;
            }

            return null;
        }

        public List<string> GetTagNames()
        {
            var names = new List<string>();
            if (tags == null)
                return names;

            for (int i = 0; i < tags.Count; i++)
            {
                if (tags[i] != null && !string.IsNullOrEmpty(tags[i].tagName))
                    names.Add(tags[i].tagName);
            }

            return names;
        }
    }
}
