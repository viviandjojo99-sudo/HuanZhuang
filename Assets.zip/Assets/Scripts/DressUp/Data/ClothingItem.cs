using System;
using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Data
{
    /// <summary>
    /// 一件衣服：只属于某一个 BodyPanel 图层。
    /// 出现在哪个 Tag 下，由 Catalog 里「Tag → 图层列表」决定。
    /// 可含多张描边/填色；眼睛还可带 YJT 联动层。
    /// </summary>
    [Serializable]
    public class ClothingItem
    {
        [Tooltip("穿到 BodyPanel 的哪个图层，例如 Mask、Neck、HairLeft")]
        public string layerName;

        [Tooltip("同图层内唯一，存档用，例如 Mask_1")]
        public string itemId;

        [Tooltip("主填色（S1），同时用作衣柜缩略图；调色改所有填色层")]
        public Sprite sprite;

        [Tooltip("主描边（B/B1），可选")]
        public Sprite outlineSprite;

        [Tooltip("额外填色 S2、S3…（不含 sprite）")]
        public List<Sprite> extraFillSprites = new List<Sprite>();

        [Tooltip("额外描边 B2、B3…（不含 outlineSprite）")]
        public List<Sprite> extraOutlineSprites = new List<Sprite>();

        [Tooltip("联动图层名，例如眼睛的 YJT：穿脱/染色时一起改")]
        public string tintCompanionLayer;

        [Tooltip("联动层贴图（YJT 只有一层填色）")]
        public Sprite companionSprite;

        [Tooltip("穿上时的颜色。玩家之后仍可用调色盘修改。")]
        public Color presetColor = Color.white;

        public bool tintable = true;

        public Sprite Thumbnail => sprite;

        public Color ResolvePresetColor()
        {
            if (presetColor.a <= 0f)
                return Color.white;
            return presetColor;
        }

        public List<Sprite> CollectFillSprites()
        {
            var list = new List<Sprite>();
            if (sprite != null)
                list.Add(sprite);
            if (extraFillSprites != null)
            {
                for (int i = 0; i < extraFillSprites.Count; i++)
                {
                    if (extraFillSprites[i] != null)
                        list.Add(extraFillSprites[i]);
                }
            }

            return list;
        }

        public List<Sprite> CollectOutlineSprites()
        {
            var list = new List<Sprite>();
            if (outlineSprite != null)
                list.Add(outlineSprite);
            if (extraOutlineSprites != null)
            {
                for (int i = 0; i < extraOutlineSprites.Count; i++)
                {
                    if (extraOutlineSprites[i] != null)
                        list.Add(extraOutlineSprites[i]);
                }
            }

            return list;
        }

        public bool HasCompanion =>
            !string.IsNullOrEmpty(tintCompanionLayer) && companionSprite != null;
    }
}
