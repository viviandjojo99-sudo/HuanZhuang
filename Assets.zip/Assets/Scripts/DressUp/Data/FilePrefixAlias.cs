using System;

namespace DressUp.Data
{
    /// <summary>
    /// 美术文件名前缀 → BodyPanel 图层名（命名不完全一致时用）。
    /// </summary>
    [Serializable]
    public class FilePrefixAlias
    {
        public string filePrefix;
        public string layerName;
    }
}
