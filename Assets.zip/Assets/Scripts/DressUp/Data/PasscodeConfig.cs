using System;
using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Data
{
    [Serializable]
    public class PasscodeUnlock
    {
        [Tooltip("正确密码（只含数字）")]
        public string code = "";

        [Tooltip("解锁后切到的模板：BodyPanel / GuNiao")]
        public string templateId = ActiveTemplateIds.BodyPanel;
    }

    /// <summary>与 ActiveAvatarBinder.CharacterBinding.templateId 对齐。</summary>
    public static class ActiveTemplateIds
    {
        public const string BodyPanel = "BodyPanel";
        public const string GuNiao = "GuNiao";
    }

    /// <summary>
    /// 内置密码锁：密码 → 模板。KEY 面板输入匹配后解锁对应模板。
    /// </summary>
    [CreateAssetMenu(fileName = "PasscodeConfig", menuName = "DressUp/密码锁", order = 4)]
    public class PasscodeConfig : ScriptableObject
    {
        [Tooltip("密码与模板对应表")]
        public List<PasscodeUnlock> unlocks = new List<PasscodeUnlock>();

        [Tooltip("解锁后是否写入 PlayerPrefs，下次进游戏仍切到该模板并全开")]
        public bool rememberUnlock = false;

        const string PrefUnlockedKey = "DressUp.PasscodeUnlocked";
        const string PrefTemplateKey = "DressUp.UnlockedTemplate";

        public bool IsValid(string code) => FindUnlock(code) != null;

        public string ResolveTemplateId(string code)
        {
            PasscodeUnlock entry = FindUnlock(code);
            if (entry == null || string.IsNullOrEmpty(entry.templateId))
                return ActiveTemplateIds.BodyPanel;
            return entry.templateId.Trim();
        }

        public PasscodeUnlock FindUnlock(string code)
        {
            if (string.IsNullOrEmpty(code) || unlocks == null)
                return null;

            string key = code.Trim();
            for (int i = 0; i < unlocks.Count; i++)
            {
                PasscodeUnlock entry = unlocks[i];
                if (entry == null || string.IsNullOrEmpty(entry.code))
                    continue;
                if (entry.code.Trim() == key)
                    return entry;
            }

            return null;
        }

        public bool IsRememberedUnlocked()
        {
            return rememberUnlock && PlayerPrefs.GetInt(PrefUnlockedKey, 0) == 1;
        }

        public string GetRememberedTemplateId()
        {
            if (!IsRememberedUnlocked())
                return null;
            string id = PlayerPrefs.GetString(PrefTemplateKey, ActiveTemplateIds.BodyPanel);
            return string.IsNullOrEmpty(id) ? ActiveTemplateIds.BodyPanel : id;
        }

        public void RememberUnlock(string templateId)
        {
            if (!rememberUnlock)
                return;
            PlayerPrefs.SetInt(PrefUnlockedKey, 1);
            PlayerPrefs.SetString(PrefTemplateKey, string.IsNullOrEmpty(templateId)
                ? ActiveTemplateIds.BodyPanel
                : templateId);
            PlayerPrefs.Save();
        }

        public void ClearRememberedUnlock()
        {
            PlayerPrefs.DeleteKey(PrefUnlockedKey);
            PlayerPrefs.DeleteKey(PrefTemplateKey);
            PlayerPrefs.Save();
        }
    }
}
