using System.Collections.Generic;
using DressUp.Avatar;
using UnityEngine;

namespace DressUp.Data
{
    /// <summary>古鸟等模板的 TagA 图标（Art/maleta/Tag_*）。</summary>
    [CreateAssetMenu(fileName = "TagIconSet", menuName = "DressUp/Tag 图标集", order = 5)]
    public class TagIconSet : ScriptableObject
    {
        public Sprite hair;
        public Sprite top;
        public Sprite pant;
        public Sprite dec;
        public Sprite back;
        public Sprite hat;
        public Sprite hand;
        public Sprite shoes;

        public List<TagSlotDef> CreateGuNiaoSlots()
        {
            return new List<TagSlotDef>
            {
                new TagSlotDef { category = "Hair", active = true, icon = hair },
                new TagSlotDef { category = "Top", active = true, icon = top },
                new TagSlotDef { category = "Pant", active = true, icon = pant },
                new TagSlotDef { category = "Dec", active = true, icon = dec },
                new TagSlotDef { category = "Back", active = true, icon = back },
                new TagSlotDef { category = "Hat", active = true, icon = hat },
                new TagSlotDef { category = "Hand", active = true, icon = hand },
                new TagSlotDef { category = "Shoes", active = true, icon = shoes }
            };
        }
    }
}
