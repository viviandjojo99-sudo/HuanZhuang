using System;
using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Data
{
    /// <summary>
    /// 一个衣柜 Tag：名字 + 它下面有哪些 BodyPanel 图层。
    /// parentTag 为空 = 一级（Tag1）；非空 = 挂在某一级下的二级（Tag2）。
    /// </summary>
    [Serializable]
    public class WardrobeTagDef
    {
        [Tooltip("与场景里 WardrobeTag 的 Category 一致，例如 Dec、Hat、刘海")]
        public string tagName;

        [Tooltip("一级 Tag 名。留空表示本身是一级；填写后出现在对应一级的 Tag2 里")]
        public string parentTag;

        [Tooltip("属于这个 Tag 的 BodyPanel 图层名（二级叶子填一层即可）")]
        public List<string> layers = new List<string>();

        public bool IsRoot => string.IsNullOrEmpty(parentTag);
    }
}
