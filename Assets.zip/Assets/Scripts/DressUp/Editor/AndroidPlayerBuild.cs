using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using UnityEditor;
#if UNITY_ANDROID
using UnityEditor.Android;
#endif
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace DressUp.EditorTools
{
    /// <summary>打出可安装的安卓包，并和网页包一起由同一个请求触发。</summary>
    public static class AndroidPlayerBuild
    {
        const string OutputDir = "Builds/Android";
        const string ApkName = "SaiBoYiGui.apk";
        const string PackageId = "com.saiboyigui";
        const string Alias = "huanzhuang";
        const string Password = "huanzhuang0818";
        const string ToolsRoot = @"C:\Users\YXY\JOJO\android-tools";

        [MenuItem("Tools/换装/导出安卓", false, 2)]
        public static void BuildFromMenu()
        {
            BuildResult result = BuildInternal();
            if (result != BuildResult.Succeeded)
                EditorUtility.DisplayDialog("安卓导出失败", $"结果：{result}\n详见 Console。", "OK");
        }

        /// <summary>命令行：-executeMethod DressUp.EditorTools.AndroidPlayerBuild.Build</summary>
        public static void Build()
        {
            BuildResult result = BuildInternal();
            EditorApplication.Exit(result == BuildResult.Succeeded ? 0 : 1);
        }

        public static BuildResult BuildInternal()
        {
            Directory.CreateDirectory(@"C:\g");
            Directory.CreateDirectory(@"C:\t");
            System.Environment.SetEnvironmentVariable("GRADLE_USER_HOME", @"C:\g");
            System.Environment.SetEnvironmentVariable("TEMP", @"C:\t");
            System.Environment.SetEnvironmentVariable("TMP", @"C:\t");

            PlayerSettings.companyName = "JOJO";
            PlayerSettings.productName = "赛博衣柜安";
            PlayerSettings.accelerometerFrequency = 0;
            // 每次导出抬 versionCode，避免手机覆盖安装时仍跑旧包。
            PlayerSettings.Android.bundleVersionCode = Math.Max(
                PlayerSettings.Android.bundleVersionCode + 1,
                int.Parse(DateTime.Now.ToString("yyMMddHH")));
            PlayerSettings.bundleVersion = DateTime.Now.ToString("yyyy.M.d.HHmm");
            ApplyIcon();
#pragma warning disable CS0618
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, PackageId);
#pragma warning restore CS0618
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            EditorUserBuildSettings.buildAppBundle = false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
            PointAtTools();
            if (!EnsureKeystore())
                return BuildResult.Failed;

            string[] scenes = WhereEnabled();
            if (scenes.Length == 0)
            {
                Debug.LogError("[AndroidBuild] Build Settings 里没有启用的场景。");
                return BuildResult.Failed;
            }

            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogError(
                    "[AndroidBuild] 当前 Unity 没有 Android 模块（PlaybackEngines/AndroidPlayer 不存在）。" +
                    "请打开 Unity Hub → 安装 → 齿轮 → 添加模块 → 勾选 Android Build Support（含 SDK/NDK/OpenJDK）后重试。");
                return BuildResult.Failed;
            }

            Directory.CreateDirectory(OutputDir);
            string apk = Path.GetFullPath(Path.Combine(OutputDir, ApkName));
            BuildReport report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = apk,
                target = BuildTarget.Android,
                options = BuildOptions.None
            });
            BuildResult result = report != null ? report.summary.result : BuildResult.Failed;
            if (result == BuildResult.Succeeded)
                Debug.Log($"[AndroidBuild] 成功 → {apk}");
            else
            {
                string detail = result.ToString();
                if (report != null)
                {
                    foreach (BuildStep step in report.steps)
                    {
                        if (step.messages == null)
                            continue;
                        for (int i = 0; i < step.messages.Length; i++)
                        {
                            if (step.messages[i].type == LogType.Error || step.messages[i].type == LogType.Exception)
                                detail += "\n" + step.messages[i].content;
                        }
                    }
                }

                Debug.LogError($"[AndroidBuild] 失败：{detail}");
            }

            return result == BuildResult.Unknown ? BuildResult.Failed : result;
        }

        static string[] WhereEnabled()
        {
            var list = new System.Collections.Generic.List<string>();
            foreach (EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
            {
                if (scene.enabled)
                    list.Add(scene.path);
            }
            return list.ToArray();
        }

        static void PointAtTools()
        {
            System.Type settings = System.Type.GetType("UnityEditor.Android.AndroidExternalToolsSettings, UnityEditor.Android.Extensions");
            if (settings == null)
                return;

            string sdk = Path.Combine(ToolsRoot, "SDK");
            string ndk = Path.Combine(ToolsRoot, "NDK");
            string jdk = Path.Combine(ToolsRoot, "OpenJDK");
            if (Directory.Exists(sdk))
                SetToolPath(settings, "sdkRootPath", sdk);
            if (Directory.Exists(ndk))
                SetToolPath(settings, "ndkRootPath", ndk);
            if (Directory.Exists(jdk))
                SetToolPath(settings, "jdkRootPath", jdk);
        }

        static void SetToolPath(System.Type settings, string propertyName, string path)
        {
            PropertyInfo property = settings.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Static);
            if (property != null && property.CanWrite)
                property.SetValue(null, path);
        }

        static bool EnsureKeystore()
        {
            Directory.CreateDirectory(ToolsRoot);
            Directory.CreateDirectory(OutputDir);
            string keystore = Path.Combine(ToolsRoot, "huanzhuang.keystore");
            if (!File.Exists(keystore) && !CreateKeystore(keystore))
                return false;

            PlayerSettings.Android.useCustomKeystore = true;
            PlayerSettings.Android.keystoreName = keystore;
            PlayerSettings.Android.keystorePass = Password;
            PlayerSettings.Android.keyaliasName = Alias;
            PlayerSettings.Android.keyaliasPass = Password;

            string note = Path.Combine(OutputDir, "keystore-pass.txt");
            File.WriteAllText(note,
                "包名 " + PackageId + "\r\n别名 " + Alias + "\r\n密码 " + Password + "\r\nkeystore " + keystore + "\r\n");
            return true;
        }

        static bool CreateKeystore(string keystore)
        {
            string keytool = Path.Combine(ToolsRoot, "OpenJDK", "bin", "keytool.exe");
            if (!File.Exists(keytool))
            {
                Debug.LogError("[AndroidBuild] 找不到 keytool，无法新建签名：" + keytool);
                return false;
            }

            var start = new ProcessStartInfo
            {
                FileName = keytool,
                Arguments =
                    "-genkeypair -v -keystore \"" + keystore + "\" -alias " + Alias +
                    " -keyalg RSA -keysize 2048 -validity 10000" +
                    " -storepass " + Password + " -keypass " + Password +
                    " -dname \"CN=JOJO, OU=DressUp, O=JOJO, L=Shanghai, ST=Shanghai, C=CN\"",
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using (Process process = Process.Start(start))
            {
                process.WaitForExit();
                if (process.ExitCode != 0 || !File.Exists(keystore))
                {
                    Debug.LogError("[AndroidBuild] keytool 退出码 " + process.ExitCode);
                    return false;
                }
            }

            return true;
        }

        static void ApplyIcon()
        {
            const string path = "Assets/Art/AppIcon.png";
            Texture2D icon = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            if (icon == null)
            {
                Debug.LogError("[AndroidBuild] 找不到桌面图标：" + path);
                return;
            }

            PlayerSettings.SetIcons(NamedBuildTarget.Unknown, new[] { icon }, IconKind.Any);
#if UNITY_ANDROID
            Stamp(AndroidPlatformIconKind.Legacy, icon);
            Stamp(AndroidPlatformIconKind.Round, icon);
            Stamp(AndroidPlatformIconKind.Adaptive, icon);
#endif
        }

#if UNITY_ANDROID
        static void Stamp(PlatformIconKind kind, Texture2D icon)
        {
            PlatformIcon[] icons = PlayerSettings.GetPlatformIcons(NamedBuildTarget.Android, kind);
            for (int i = 0; i < icons.Length; i++)
            {
                int layers = icons[i].maxLayerCount;
                if (layers < 1)
                    layers = 1;
                var textures = new Texture2D[layers];
                for (int layer = 0; layer < layers; layer++)
                    textures[layer] = icon;
                icons[i].SetTextures(textures);
            }

            PlayerSettings.SetPlatformIcons(NamedBuildTarget.Android, kind, icons);
        }
#endif
    }

    [InitializeOnLoad]
    public static class PlayerPackageBuildTrigger
    {
        const string FlagPath = "Builds/request-player-builds.flag";
        const string AndroidFlagPath = "Builds/request-android-build.flag";
        static bool building;

        public static void BuildAndroidNow()
        {
            Debug.Log("[PlayerBuild] 命令行只导出安卓包。");
            BuildResult android = AndroidPlayerBuild.BuildInternal();
            Debug.Log($"[PlayerBuild] 安卓 {android}");
            EditorApplication.Exit(android == BuildResult.Succeeded ? 0 : 1);
        }

        public static void BuildNow()
        {
            Debug.Log("[PlayerBuild] 命令行开始导出网页，然后导出安卓包。");
            BuildResult web = WebPlayerBuild.BuildSilent(false);
            BuildResult android = AndroidPlayerBuild.BuildInternal();
            Debug.Log($"[PlayerBuild] 网页 {web}，安卓 {android}");
            EditorApplication.Exit(web == BuildResult.Succeeded && android == BuildResult.Succeeded ? 0 : 1);
        }

        static PlayerPackageBuildTrigger()
        {
            EditorApplication.update -= Poll;
            EditorApplication.update += Poll;
        }

        static double nextPoll;

        static void Poll()
        {
            if (building || EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
                return;
            double now = EditorApplication.timeSinceStartup;
            if (now < nextPoll)
                return;
            nextPoll = now + 1.5;

            string androidFlag = Path.GetFullPath(AndroidFlagPath);
            if (File.Exists(androidFlag))
            {
                try { File.Delete(androidFlag); }
                catch { return; }

                building = true;
                try
                {
                    Debug.Log("[PlayerBuild] 开始只导出安卓包 → Builds/Android/SaiBoYiGui.apk");
                    BuildResult android = AndroidPlayerBuild.BuildInternal();
                    Debug.Log($"[PlayerBuild] 安卓 {android}");
                }
                finally
                {
                    building = false;
                }

                return;
            }

            string flag = Path.GetFullPath(FlagPath);
            if (!File.Exists(flag))
                return;
            try { File.Delete(flag); }
            catch { return; }

            building = true;
            try
            {
                Debug.Log("[PlayerBuild] 开始导出网页，然后导出安卓包。");
                BuildResult web = WebPlayerBuild.BuildSilent(false);
                BuildResult android = AndroidPlayerBuild.BuildInternal();
                Debug.Log($"[PlayerBuild] 网页 {web}，安卓 {android}");
            }
            finally
            {
                building = false;
            }
        }
    }
}
