using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Wardrobe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Editor
{
    /// <summary>
    /// 装配 BodyPanel：每层建 B1/B2/S1/S2，写入 Catalog，按文件夹导入衣服。
    /// </summary>
    public static class BodyPanelCatalogSetup
    {
        const string ScenePath = "Assets/Scenes/SampleScene.unity";
        const string CatalogPath = "Assets/ScriptableObjects/DressUp/Catalog_BodyPanel.asset";
        const string ArtRoot = "Assets/Art/BodyPanel";

        /// <summary>文件夹名 → 场景图层（无映射则同名）。SH 已并入 MS，不再映射 HY。</summary>
        static readonly Dictionary<string, string> FolderToLayer =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        static readonly Regex ItemFileRegex = new Regex(
            @"^(?<prefix>[A-Za-z]+)(?<num>\d+)(?:_(?<part>[BS]\d*))?$",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);

        public static void RunFromMenu()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            try
            {
                string report = Run();
                EditorUtility.DisplayDialog("BodyPanel 图鉴", report, "OK");
            }
            catch (Exception ex)
            {
                Debug.LogException(ex);
                EditorUtility.DisplayDialog("BodyPanel 图鉴失败", ex.Message, "OK");
            }
        }

        public static void NativeSizeBodyPanelLayersMenu()
        {
            GameObject rootGo = GameObject.Find("BodyPanel");
            if (rootGo == null)
            {
                EditorUtility.DisplayDialog("BodyPanel", "场景中找不到 BodyPanel", "OK");
                return;
            }

            EnsureLayerImages(rootGo.transform);
            if (rootGo.GetComponent<BodyAvatar>() is BodyAvatar avatar)
                avatar.RebuildLayerCache();

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            EditorUtility.DisplayDialog("BodyPanel", "已将全部子层与 B/S 设为居中 + 原图 888×888。", "OK");
        }

        public static string Run()
        {
            var scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
            GameObject rootGo = GameObject.Find("BodyPanel");
            if (rootGo == null)
                throw new Exception("场景中找不到 BodyPanel");

            EnsureLayerImages(rootGo.transform);
            BodyAvatar avatar = EnsureAvatar(rootGo);

            ClothingCatalog catalog = EnsureCatalog();
            // Catalog 资源是唯一对照表：已有 tags 不覆盖，只校验层。
            ConfigureTags(catalog, rootGo.transform);
            int itemCount = ImportAllItems(catalog, rootGo.transform);

            ApplyDefaultBody(avatar, catalog);
            WireBinder(avatar, catalog, rootGo);

            EditorUtility.SetDirty(catalog);
            EditorUtility.SetDirty(avatar);
            EditorSceneManager.MarkSceneDirty(scene);
            AssetDatabase.SaveAssets();
            EditorSceneManager.SaveScene(scene);

            return $"图层 {rootGo.transform.childCount}；Tag {catalog.tags.Count}；衣服 {itemCount}；已保存。";
        }

        const float BodyPanelNativeSize = 888f;

        static void EnsureLayerImages(Transform root)
        {
            // 子层与 B/S：居中 + 原图像素尺寸 888×888，绝不 Stretch 拉伸
            for (int i = 0; i < root.childCount; i++)
            {
                Transform layer = root.GetChild(i);
                CenterNativeSize(layer as RectTransform, BodyPanelNativeSize);

                // 与 PSD 一致：填色在下，描边在上（Hierarchy 越靠后越在上面）
                EnsureChildImage(layer, "S1", 0);
                EnsureChildImage(layer, "S2", 1);
                EnsureChildImage(layer, "B1", 2);
                EnsureChildImage(layer, "B2", 3);

                Image self = layer.GetComponent<Image>();
                if (self != null)
                    self.enabled = false;
            }
        }

        /// <summary>锚点居中，宽高用原图像素（默认 888），不拉伸。</summary>
        static void CenterNativeSize(RectTransform rt, float size)
        {
            if (rt == null)
                return;
            Undo.RecordObject(rt, "BodyPanel Native Size");
            rt.localScale = Vector3.one;
            rt.localRotation = Quaternion.identity;
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(size, size);
        }

        static Image EnsureChildImage(Transform layer, string childName, int siblingIndex)
        {
            Transform t = layer.Find(childName);
            GameObject go;
            if (t == null)
            {
                go = new GameObject(childName, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                Undo.RegisterCreatedObjectUndo(go, "Create " + childName);
                go.transform.SetParent(layer, false);
            }
            else
            {
                go = t.gameObject;
                if (go.GetComponent<CanvasRenderer>() == null)
                    go.AddComponent<CanvasRenderer>();
                if (go.GetComponent<Image>() == null)
                    go.AddComponent<Image>();
            }

            go.transform.SetSiblingIndex(Mathf.Min(siblingIndex, layer.childCount - 1));
            CenterNativeSize(go.GetComponent<RectTransform>(), BodyPanelNativeSize);

            Image image = go.GetComponent<Image>();
            image.color = Color.white;
            image.preserveAspect = true;
            image.raycastTarget = false;
            if (image.sprite == null)
                image.enabled = false;
            return image;
        }

        static BodyAvatar EnsureAvatar(GameObject rootGo)
        {
            BodyAvatar avatar = rootGo.GetComponent<BodyAvatar>();
            if (avatar == null)
                avatar = Undo.AddComponent<BodyAvatar>(rootGo);

            var so = new SerializedObject(avatar);
            so.FindProperty("characterId").stringValue = "BodyPanel";
            SerializedProperty keep = so.FindProperty("keepOnClear");
            keep.arraySize = 1;
            keep.GetArrayElementAtIndex(0).stringValue = "RM";
            so.ApplyModifiedProperties();
            avatar.RebuildLayerCache();
            return avatar;
        }

        static ClothingCatalog EnsureCatalog()
        {
            if (!AssetDatabase.IsValidFolder("Assets/ScriptableObjects"))
                AssetDatabase.CreateFolder("Assets", "ScriptableObjects");
            if (!AssetDatabase.IsValidFolder("Assets/ScriptableObjects/DressUp"))
                AssetDatabase.CreateFolder("Assets/ScriptableObjects", "DressUp");

            ClothingCatalog catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(CatalogPath);
            if (catalog == null)
            {
                catalog = ScriptableObject.CreateInstance<ClothingCatalog>();
                AssetDatabase.CreateAsset(catalog, CatalogPath);
            }

            // 衣服可重扫；tags 是唯一对照表，已有则保留。
            catalog.items = new List<ClothingItem>();
            if (catalog.tags == null)
                catalog.tags = new List<WardrobeTagDef>();
            if (catalog.filePrefixAliases == null)
                catalog.filePrefixAliases = new List<FilePrefixAlias>();
            return catalog;
        }

        /// <summary>BodyPanel 上不进衣柜格的层（YJT 跟眼睛联动；RM 等人模/特效）。</summary>
        static readonly HashSet<string> SkipWardrobeLayers =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "HY", "SH", "QJ", "RM", "YJT"
            };

        /// <summary>
        /// 唯一对照表是 Catalog 资源。已有 tags 时只校验 BodyPanel 层是否进表，不再用写死数组覆盖。
        /// 仅当 tags 为空时写入一份种子（之后请在图鉴浏览器改资源）。
        /// </summary>
        static void ConfigureTags(ClothingCatalog catalog, Transform root)
        {
            if (catalog.tags != null && catalog.tags.Count > 0)
            {
                WarnUnmappedLayers(catalog, root);
                return;
            }

            catalog.tags = new List<WardrobeTagDef>();
            SeedTag(catalog, "头发", null);
            SeedTag(catalog, "呆毛", "头发", "DM");
            SeedTag(catalog, "边发", "头发", "BF");
            SeedTag(catalog, "刘海", "头发", "LH");
            SeedTag(catalog, "侧发", "头发", "CF");
            SeedTag(catalog, "后发", "头发", "HF");
            SeedTag(catalog, "辫子", "头发", "HFBZ");
            SeedTag(catalog, "碎发", "头发", "SF");
            SeedTag(catalog, "高光", "头发", "GG");

            SeedTag(catalog, "衣服", null, "YF");
            SeedTag(catalog, "裤子", null, "KZ");
            SeedTag(catalog, "鞋子", null, "XZ");
            SeedTag(catalog, "眼睛", null, "YJ");
            SeedTag(catalog, "眉毛", null, "MM");
            SeedTag(catalog, "外套", null, "WT");
            SeedTag(catalog, "袜子", null, "WZ");
            SeedTag(catalog, "嘴", null, "Z");
            SeedTag(catalog, "人模", null, "RM", "WS");
            SeedTag(catalog, "其它饰品", null);

            SeedTag(catalog, "前饰", "其它饰品", "TSQ");
            SeedTag(catalog, "后饰", "其它饰品", "TSH");
            SeedTag(catalog, "发带", "其它饰品", "DS");
            SeedTag(catalog, "发饰", "其它饰品", "HFBZZS");
            SeedTag(catalog, "面饰", "其它饰品", "MS");
            SeedTag(catalog, "衣饰", "其它饰品", "YS");
            SeedTag(catalog, "耳饰", "其它饰品", "ED");
            SeedTag(catalog, "尾巴", "其它饰品", "WB");
            SeedTag(catalog, "兽耳", "其它饰品", "SE", "J");
            SeedTag(catalog, "场景", "其它饰品", "CJ");
            SeedTag(catalog, "背饰", "其它饰品", "BS");
            SeedTag(catalog, "未分类", null, "QJ");

            WarnUnmappedLayers(catalog, root);
        }

        static void SeedTag(ClothingCatalog catalog, string tagName, string parent, params string[] layers)
        {
            catalog.tags.Add(new WardrobeTagDef
            {
                tagName = tagName,
                parentTag = parent,
                layers = layers != null && layers.Length > 0
                    ? new List<string>(layers)
                    : new List<string>()
            });
        }

        static void WarnUnmappedLayers(ClothingCatalog catalog, Transform root)
        {
            var usedLayers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (catalog.tags != null)
            {
                for (int i = 0; i < catalog.tags.Count; i++)
                {
                    WardrobeTagDef tag = catalog.tags[i];
                    if (tag?.layers == null)
                        continue;
                    for (int L = 0; L < tag.layers.Count; L++)
                        usedLayers.Add(tag.layers[L]);
                }
            }

            for (int i = 0; i < root.childCount; i++)
            {
                string layerName = root.GetChild(i).name;
                if (usedLayers.Contains(layerName) || SkipWardrobeLayers.Contains(layerName))
                    continue;
                Debug.LogWarning($"[BodyPanel] 图层 {layerName} 未归入 Catalog 任何 Tag（请改 Catalog_BodyPanel）");
            }
        }

        static int ImportAllItems(ClothingCatalog catalog, Transform root)
        {
            var layerNames = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < root.childCount; i++)
                layerNames.Add(root.GetChild(i).name);

            int added = 0;
            foreach (string folderName in Directory.GetDirectories(ToAbsolute(ArtRoot))
                         .Select(Path.GetFileName)
                         .Where(n => n != "_Wear")
                         .OrderBy(n => n, StringComparer.OrdinalIgnoreCase))
            {
                if (string.Equals(folderName, "YJT", StringComparison.OrdinalIgnoreCase))
                    continue;

                string layerName = FolderToLayer.TryGetValue(folderName, out string mapped)
                    ? mapped
                    : folderName;
                if (!layerNames.Contains(layerName))
                {
                    Debug.LogWarning($"[BodyPanel] 跳过文件夹 {folderName}：场景无图层 {layerName}");
                    continue;
                }

                added += ImportFolder(catalog, $"{ArtRoot}/{folderName}", folderName, layerName);
            }

            return added;
        }

        static int ImportFolder(ClothingCatalog catalog, string folderAsset, string folderName, string layerName)
        {
            string abs = ToAbsolute(folderAsset);
            if (!Directory.Exists(abs))
                return 0;

            var byIndex = new Dictionary<int, ItemParts>();
            foreach (string path in Directory.GetFiles(abs, "*.png"))
            {
                string name = Path.GetFileNameWithoutExtension(path);
                Match m = ItemFileRegex.Match(name);
                if (!m.Success)
                    continue;
                if (!string.Equals(m.Groups["prefix"].Value, folderName, StringComparison.OrdinalIgnoreCase))
                    continue;

                int num = int.Parse(m.Groups["num"].Value);
                if (!byIndex.TryGetValue(num, out ItemParts parts))
                {
                    parts = new ItemParts();
                    byIndex[num] = parts;
                }

                string part = m.Groups["part"].Success ? m.Groups["part"].Value.ToUpperInvariant() : "";
                string assetPath = $"{folderAsset}/{Path.GetFileName(path)}".Replace('\\', '/');
                int order = PartOrder(part);

                if (string.IsNullOrEmpty(part))
                    parts.PlainPath = assetPath;
                else if (part.StartsWith("B", StringComparison.Ordinal))
                    parts.OutlinePaths.Add(new PartPath { Order = order, Path = assetPath });
                else if (part.StartsWith("S", StringComparison.Ordinal))
                    parts.FillPaths.Add(new PartPath { Order = order, Path = assetPath });
            }

            int added = 0;
            foreach (int num in byIndex.Keys.OrderBy(n => n))
            {
                ItemParts parts = byIndex[num];
                parts.OutlinePaths.Sort((a, b) => a.Order.CompareTo(b.Order));
                parts.FillPaths.Sort((a, b) => a.Order.CompareTo(b.Order));

                var outlineSprites = new List<Sprite>();
                for (int i = 0; i < parts.OutlinePaths.Count; i++)
                {
                    Sprite s = LoadSprite(parts.OutlinePaths[i].Path);
                    if (s != null)
                        outlineSprites.Add(s);
                }

                var fillSprites = new List<Sprite>();
                if (!string.IsNullOrEmpty(parts.PlainPath))
                {
                    Sprite plain = LoadSprite(parts.PlainPath);
                    if (plain != null)
                        fillSprites.Add(plain);
                }
                else
                {
                    for (int i = 0; i < parts.FillPaths.Count; i++)
                    {
                        Sprite s = LoadSprite(parts.FillPaths[i].Path);
                        if (s != null)
                            fillSprites.Add(s);
                    }
                }

                if (fillSprites.Count == 0)
                {
                    Debug.LogWarning($"[BodyPanel] {folderName}{num} 没有填色图，跳过");
                    continue;
                }

                var item = new ClothingItem
                {
                    layerName = layerName,
                    itemId = $"{layerName}_{num}",
                    sprite = fillSprites[0],
                    outlineSprite = outlineSprites.Count > 0 ? outlineSprites[0] : null,
                    extraFillSprites = fillSprites.Skip(1).ToList(),
                    extraOutlineSprites = outlineSprites.Skip(1).ToList(),
                    presetColor = Color.white,
                    tintable = true
                };

                if (string.Equals(layerName, "YJ", StringComparison.OrdinalIgnoreCase))
                {
                    Sprite yjt = LoadSprite($"{ArtRoot}/YJT/YJT{num}.png");
                    if (yjt != null)
                    {
                        item.tintCompanionLayer = "YJT";
                        item.companionSprite = yjt;
                    }
                }

                catalog.items.Add(item);
                added++;
            }

            return added;
        }

        static int PartOrder(string part)
        {
            if (string.IsNullOrEmpty(part) || part.Length == 1)
                return 1;
            if (int.TryParse(part.Substring(1), out int n))
                return n <= 0 ? 1 : n;
            return 1;
        }

        static Sprite LoadSprite(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return null;
            Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(assetPath);
            if (sprite != null)
                return sprite;

            UnityEngine.Object[] all = AssetDatabase.LoadAllAssetsAtPath(assetPath);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i] is Sprite s)
                    return s;
            }

            return null;
        }

        static readonly string[] DefaultOutfitIds =
        {
            "YJ_2",
            "YF_0",
            "LH_3",
            "BF_5"
        };

        static void ApplyDefaultBody(BodyAvatar avatar, ClothingCatalog catalog)
        {
            ClothingItem body = catalog.Find("RM", "RM_1") ?? catalog.Find("RM_1");
            if (body != null)
                avatar.Equip(body);

            for (int i = 0; i < DefaultOutfitIds.Length; i++)
            {
                ClothingItem item = catalog.Find(DefaultOutfitIds[i]);
                if (item != null)
                    avatar.Equip(item);
            }
        }

        static void WireBinder(BodyAvatar avatar, ClothingCatalog catalog, GameObject rootGo)
        {
            ActiveAvatarBinder binder = UnityEngine.Object.FindAnyObjectByType<ActiveAvatarBinder>();
            if (binder != null)
            {
                var so = new SerializedObject(binder);
                SerializedProperty list = so.FindProperty("characters");
                int found = -1;
                for (int i = 0; i < list.arraySize; i++)
                {
                    SerializedProperty el = list.GetArrayElementAtIndex(i);
                    if (el.FindPropertyRelative("displayName").stringValue == "BodyPanel"
                        || el.FindPropertyRelative("bodyPanelRoot").objectReferenceValue == rootGo)
                    {
                        found = i;
                        break;
                    }
                }

                if (found < 0)
                {
                    found = list.arraySize;
                    list.arraySize++;
                }

                SerializedProperty slot = list.GetArrayElementAtIndex(found);
                slot.FindPropertyRelative("displayName").stringValue = "BodyPanel";
                slot.FindPropertyRelative("templateId").stringValue = "BodyPanel";
                slot.FindPropertyRelative("bodyPanelRoot").objectReferenceValue = rootGo;
                slot.FindPropertyRelative("avatar").objectReferenceValue = avatar;
                slot.FindPropertyRelative("catalog").objectReferenceValue = catalog;
                so.FindProperty("activeIndex").intValue = found;
                so.ApplyModifiedProperties();
            }

            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
                return;

            // 用字符串取组件，避免 Editor 程序集偶发解析不到运行时类型
            Component wardrobe = maleta.GetComponent("WardrobeController");
            if (wardrobe == null)
                return;

            var wso = new SerializedObject(wardrobe);
            wso.FindProperty("targetAvatar").objectReferenceValue = avatar;
            wso.FindProperty("catalog").objectReferenceValue = catalog;
            wso.ApplyModifiedProperties();

            EnsureTagNavigator(maleta, wardrobe);
        }

        static void EnsureTagNavigator(GameObject maleta, Component wardrobe)
        {
            WardrobeTagNavigator nav = maleta.GetComponent<WardrobeTagNavigator>();
            if (nav == null)
                nav = Undo.AddComponent<WardrobeTagNavigator>(maleta);

            Transform tag1 = FindDeep(maleta.transform, "TagA") ?? FindDeep(maleta.transform, "Tag1");
            Transform tag2 = FindDeep(maleta.transform, "TagB") ?? FindDeep(maleta.transform, "Tag2");
            var nso = new SerializedObject(nav);
            nso.FindProperty("tag1Root").objectReferenceValue = tag1;
            nso.FindProperty("tag2Root").objectReferenceValue = tag2;
            nso.FindProperty("wardrobe").objectReferenceValue = wardrobe;
            nso.ApplyModifiedProperties();

            var wsoNav = new SerializedObject(wardrobe);
            SerializedProperty navProp = wsoNav.FindProperty("tagNavigator");
            if (navProp != null)
            {
                navProp.objectReferenceValue = nav;
                wsoNav.ApplyModifiedProperties();
            }

            if (tag2 != null)
            {
                Undo.RecordObject(tag2.gameObject, "Hide Tag2");
                tag2.gameObject.SetActive(false);
            }
        }

        static Transform FindDeep(Transform root, string name)
        {
            if (root == null)
                return null;
            if (root.name == name)
                return root;
            for (int i = 0; i < root.childCount; i++)
            {
                Transform found = FindDeep(root.GetChild(i), name);
                if (found != null)
                    return found;
            }

            return null;
        }

        static string ToAbsolute(string assetPath)
        {
            string project = Directory.GetParent(Application.dataPath)!.FullName;
            return Path.Combine(project, assetPath.Replace('/', Path.DirectorySeparatorChar));
        }

        sealed class PartPath
        {
            public int Order;
            public string Path;
        }

        sealed class ItemParts
        {
            public string PlainPath;
            public readonly List<PartPath> OutlinePaths = new List<PartPath>();
            public readonly List<PartPath> FillPaths = new List<PartPath>();
        }
    }
}
