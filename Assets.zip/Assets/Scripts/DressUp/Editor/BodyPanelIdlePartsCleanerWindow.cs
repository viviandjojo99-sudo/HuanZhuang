using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Editor
{
    /// <summary>
    /// 打扫 BodyPanel 上闲置的 S2+/B2+ 空壳。对随机+曲线卡顿帮助极小，不要当成性能银弹。
    /// 菜单：Tools/换装/打扫 BodyPanel 空闲 S2B2
    /// </summary>
    public class BodyPanelIdlePartsCleanerWindow : EditorWindow
    {
        static readonly Regex FillName = new Regex(@"^S\d*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        static readonly Regex OutlineName = new Regex(@"^B\d*$", RegexOptions.IgnoreCase | RegexOptions.Compiled);

        Vector2 scroll;
        string report = "先点「扫描」，确认清单后再删。\n\n提醒：删空闲 S2/B2 对随机+曲线卡顿几乎无帮助；多切片衣服或刘海补丁运行时仍可能再建 S2。";
        readonly List<IdlePart> found = new List<IdlePart>();
        Transform bodyPanelRoot;

        struct IdlePart
        {
            public string Path;
            public string Layer;
            public string Part;
            public GameObject Go;
        }

        [MenuItem("Tools/换装/打扫 BodyPanel 空闲 S2B2", false, 12)]
        public static void Open()
        {
            var win = GetWindow<BodyPanelIdlePartsCleanerWindow>("空闲 S2/B2");
            win.minSize = new Vector2(560, 420);
            win.TryFindBodyPanel();
        }

        void OnGUI()
        {
            EditorGUILayout.HelpBox(
                "不建议无脑删全树 S2/B2。\n" +
                "本工具只删：图层下名称 S2+/B2+、Image.sprite 为空、且未启用的空壳。\n" +
                "跳过 LH（刘海第二填色可能用到）。保留 S/S1、B/B1。\n" +
                "对随机+曲线卡顿收益极小，最多算场景打扫。",
                MessageType.Warning);

            EditorGUI.BeginChangeCheck();
            bodyPanelRoot = (Transform)EditorGUILayout.ObjectField("BodyPanel 根", bodyPanelRoot, typeof(Transform), true);
            if (EditorGUI.EndChangeCheck() && bodyPanelRoot == null)
                TryFindBodyPanel();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("扫描空闲 S2+/B2+", GUILayout.Height(28)))
                Scan();
            using (new EditorGUI.DisabledScope(found.Count == 0))
            {
                if (GUILayout.Button($"删除清单 ({found.Count})", GUILayout.Height(28)))
                    DeleteFound();
            }
            EditorGUILayout.EndHorizontal();

            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.TextArea(report, GUILayout.ExpandHeight(true));
            EditorGUILayout.EndScrollView();
        }

        void TryFindBodyPanel()
        {
            if (bodyPanelRoot != null)
                return;

            Transform[] all = UnityEngine.Object.FindObjectsByType<Transform>(FindObjectsInactive.Include);
            for (int i = 0; i < all.Length; i++)
            {
                Transform t = all[i];
                if (t != null && string.Equals(t.name, "BodyPanel", StringComparison.OrdinalIgnoreCase))
                {
                    bodyPanelRoot = t;
                    return;
                }
            }
        }

        void Scan()
        {
            found.Clear();
            if (bodyPanelRoot == null)
                TryFindBodyPanel();
            if (bodyPanelRoot == null)
            {
                report = "找不到 BodyPanel。请把根物体拖到上方字段。";
                return;
            }

            var sb = new StringBuilder();
            sb.AppendLine($"扫描根：{GetPath(bodyPanelRoot)}");
            sb.AppendLine("规则：S2+/B2+ 且 sprite==null 且 !enabled；跳过 LH。");
            sb.AppendLine();

            for (int i = 0; i < bodyPanelRoot.childCount; i++)
            {
                Transform layer = bodyPanelRoot.GetChild(i);
                if (layer == null)
                    continue;
                if (string.Equals(layer.name, "LH", StringComparison.OrdinalIgnoreCase))
                    continue;
                if (layer.name.EndsWith("_back", StringComparison.OrdinalIgnoreCase))
                    continue;

                CollectIdleUnderLayer(layer, sb);
            }

            if (found.Count == 0)
            {
                sb.AppendLine("没有可删的空闲 S2+/B2+。");
            }
            else
            {
                sb.AppendLine($"共 {found.Count} 个可删空壳：");
                for (int i = 0; i < found.Count; i++)
                    sb.AppendLine($"  - [{found[i].Layer}] {found[i].Part}  ({found[i].Path})");
                sb.AppendLine();
                sb.AppendLine("确认无误后再点「删除清单」。删除会标记场景已改，请自行保存。");
            }

            report = sb.ToString();
        }

        void CollectIdleUnderLayer(Transform layer, StringBuilder sb)
        {
            for (int i = 0; i < layer.childCount; i++)
            {
                Transform child = layer.GetChild(i);
                if (child == null)
                    continue;

                if (!IsIdleExtraPart(child, out string kind))
                    continue;

                found.Add(new IdlePart
                {
                    Path = GetPath(child),
                    Layer = layer.name,
                    Part = child.name + " (" + kind + ")",
                    Go = child.gameObject
                });
            }
        }

        static bool IsIdleExtraPart(Transform part, out string kind)
        {
            kind = null;
            if (part == null)
                return false;

            string name = part.name;
            int index;
            if (FillName.IsMatch(name))
            {
                index = ParseIndex(name);
                if (index < 2)
                    return false;
                kind = "fill";
            }
            else if (OutlineName.IsMatch(name))
            {
                index = ParseIndex(name);
                if (index < 2)
                    return false;
                kind = "outline";
            }
            else
                return false;

            Image image = part.GetComponent<Image>();
            if (image == null)
                return false;
            if (image.sprite != null)
                return false;
            if (image.enabled)
                return false;
            return true;
        }

        static int ParseIndex(string name)
        {
            if (string.IsNullOrEmpty(name) || name.Length <= 1)
                return 1;
            if (int.TryParse(name.Substring(1), out int n))
                return n <= 0 ? 1 : n;
            return 1;
        }

        void DeleteFound()
        {
            if (found.Count == 0)
                return;

            if (!EditorUtility.DisplayDialog(
                    "删除空闲 S2/B2",
                    $"将删除 {found.Count} 个空壳（跳过 LH，保留 S1/B1）。\n这不会明显改善随机+曲线卡顿。\n确定？",
                    "删除",
                    "取消"))
                return;

            var deleted = new StringBuilder();
            deleted.AppendLine($"已删除 {found.Count} 个：");
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("打扫 BodyPanel 空闲 S2/B2");

            for (int i = 0; i < found.Count; i++)
            {
                IdlePart part = found[i];
                if (part.Go == null)
                    continue;
                deleted.AppendLine($"  - [{part.Layer}] {part.Part}");
                Undo.DestroyObjectImmediate(part.Go);
            }

            Undo.CollapseUndoOperations(group);
            if (bodyPanelRoot != null)
                EditorSceneManager.MarkSceneDirty(bodyPanelRoot.gameObject.scene);

            found.Clear();
            deleted.AppendLine();
            deleted.AppendLine("请保存场景。多切片衣服运行时仍可能再建 S2/B2。");
            report = deleted.ToString();
            Debug.Log("[BodyPanelIdleParts] " + report.Replace('\n', ' '));
        }

        static string GetPath(Transform t)
        {
            if (t == null)
                return "";
            var stack = new Stack<string>();
            while (t != null)
            {
                stack.Push(t.name);
                t = t.parent;
            }

            return string.Join("/", stack);
        }
    }
}
