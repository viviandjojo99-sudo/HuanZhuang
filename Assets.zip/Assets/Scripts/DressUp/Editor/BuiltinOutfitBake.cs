using System.Collections;
using System.Collections.Generic;
using System.IO;
using DressUp.Data;
using DressUp.Import;
using UnityEditor;
using UnityEngine;

namespace DressUp.EditorTools
{
    /// <summary>用和「手动导入 → 单图层」相同的规则，把 3071.psd 写成内置衣服。一层一件，不缩放到 888。</summary>
    public static class BuiltinOutfitBake
    {
        const string PsdPath = @"C:\Users\YXY\Desktop\3071.psd";
        const string CatalogPath = "Assets/ScriptableObjects/DressUp/Catalog_BodyPanel.asset";
        const string OutFolder = "Assets/Resources/DressUp/Builtin3071";
        const string Unsorted = "未分类";

        public static void BakeNow()
        {
            ClothingCatalog catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(CatalogPath);
            if (catalog == null)
            {
                Debug.LogError("[Builtin] 找不到衣柜表。");
                EditorApplication.Exit(1);
                return;
            }

            if (!File.Exists(PsdPath))
            {
                Debug.LogError("[Builtin] 找不到 PSD：" + PsdPath);
                EditorApplication.Exit(1);
                return;
            }

            PsdDocument doc = null;
            try
            {
                doc = PsdDocument.Open(PsdPath);
                List<PsdGarment> garments = PsdGroups.Collect(doc, true);
                var buckets = new Dictionary<string, List<PsdGarment>>();
                for (int i = 0; i < garments.Count; i++)
                {
                    string tag = MatchTag(catalog, garments[i]);
                    if (!buckets.TryGetValue(tag, out List<PsdGarment> bucket))
                    {
                        bucket = new List<PsdGarment>();
                        buckets.Add(tag, bucket);
                    }

                    bucket.Add(garmentAt(garments, i));
                }

                ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
                var items = new List<ClothingItem>();
                foreach (KeyValuePair<string, List<PsdGarment>> pair in buckets)
                {
                    string layer = pair.Key == Unsorted
                        ? "QJ"
                        : PsdClothingBuilder.LayerForTag(catalog, pair.Key, null);
                    IEnumerator routine = PsdClothingBuilder.FromGarments(
                        doc,
                        pair.Value,
                        layer,
                        layer + "_k",
                        wardrobe,
                        1,
                        items);
                    while (routine.MoveNext())
                    {
                    }
                }

                if (Directory.Exists(OutFolder))
                    Directory.Delete(OutFolder, true);
                int count = ImportedSave.PublishBuiltin(OutFolder);
                AssetDatabase.Refresh();
                Debug.Log("[Builtin] 已写入 " + count + " 件，画布 " + doc.Width + "×" + doc.Height);
                for (int i = 0; i < items.Count; i++)
                    Debug.Log("[Builtin] " + items[i].layerName + " " + items[i].itemId);
                EditorApplication.Exit(count > 0 ? 0 : 1);
            }
            catch (System.Exception exception)
            {
                Debug.LogError("[Builtin] " + exception);
                EditorApplication.Exit(1);
            }
            finally
            {
                doc?.Dispose();
            }
        }

        static PsdGarment garmentAt(List<PsdGarment> garments, int index)
        {
            return garments[index];
        }

        static string MatchTag(ClothingCatalog catalog, PsdGarment garment)
        {
            if (garment == null)
                return Unsorted;
            for (int i = 0; i < garment.GroupNames.Count; i++)
            {
                string name = garment.GroupNames[i];
                WardrobeTagDef tag = catalog.FindTag(name);
                if (tag?.layers != null && tag.layers.Count > 0)
                    return tag.tagName;
            }

            return Unsorted;
        }
    }
}
