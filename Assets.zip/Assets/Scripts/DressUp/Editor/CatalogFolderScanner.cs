using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using DressUp.Data;
using UnityEditor;
using UnityEngine;

namespace DressUp.Editor
{
    public class ScannedSprite
    {
        public string layerName;
        public int index;
        public Sprite sprite;
        public string assetPath;
    }

    public class ScannedLayerGroup
    {
        public string layerName;
        public List<ScannedSprite> sprites = new List<ScannedSprite>();
        public bool import = true;
    }

    public static class CatalogFolderScanner
    {
        static readonly Regex ExactIndexRegex = new Regex(@"^_?(?<num>\d+)$", RegexOptions.Compiled);

        public static List<string> CollectLayerNames(Transform bodyPanelRoot)
        {
            var names = new List<string>();
            if (bodyPanelRoot == null)
                return names;

            for (int i = 0; i < bodyPanelRoot.childCount; i++)
            {
                Transform child = bodyPanelRoot.GetChild(i);
                if (child.GetComponent<UnityEngine.UI.Image>() != null)
                    names.Add(child.name);
            }

            return names;
        }

        public static List<ScannedLayerGroup> Scan(Transform bodyPanelRoot, string folderAssetPath, ClothingCatalog catalog)
        {
            var groups = new Dictionary<string, ScannedLayerGroup>();
            List<string> layerNames = CollectConfiguredLayers(bodyPanelRoot, catalog);
            Dictionary<string, string> aliases = BuildAliasMap(catalog);
            List<string> matchKeys = BuildMatchKeys(layerNames, aliases);

            if (!AssetDatabase.IsValidFolder(folderAssetPath) || matchKeys.Count == 0)
                return new List<ScannedLayerGroup>();

            string[] guids = AssetDatabase.FindAssets("t:Sprite", new[] { folderAssetPath });
            for (int i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
                if (sprite == null)
                    continue;

                string fileName = Path.GetFileNameWithoutExtension(path);
                if (!TryResolveLayer(fileName, matchKeys, aliases, out string layerName, out int index))
                    continue;

                if (!groups.TryGetValue(layerName, out ScannedLayerGroup group))
                {
                    group = new ScannedLayerGroup { layerName = layerName };
                    groups[layerName] = group;
                }

                group.sprites.Add(new ScannedSprite
                {
                    layerName = layerName,
                    index = index,
                    sprite = sprite,
                    assetPath = path
                });
            }

            foreach (ScannedLayerGroup g in groups.Values)
                g.sprites = g.sprites.OrderBy(s => s.index).ToList();

            return groups.Values.OrderBy(g => g.layerName).ToList();
        }

        public static void WriteToCatalog(ClothingCatalog catalog, List<ScannedLayerGroup> groups, bool tintable, out int added, out int updated)
        {
            added = 0;
            updated = 0;
            if (catalog == null || groups == null)
                return;

            if (catalog.items == null)
                catalog.items = new List<ClothingItem>();

            Undo.RecordObject(catalog, "Import Clothing From Folder");

            for (int g = 0; g < groups.Count; g++)
            {
                ScannedLayerGroup group = groups[g];
                if (group == null || !group.import || string.IsNullOrEmpty(group.layerName))
                    continue;

                for (int i = 0; i < group.sprites.Count; i++)
                {
                    ScannedSprite scanned = group.sprites[i];
                    string itemId = $"{group.layerName}_{scanned.index}";
                    ClothingItem existing = catalog.Find(group.layerName, itemId) ?? catalog.Find(itemId);
                    ClothingItem item = existing ?? new ClothingItem();

                    item.layerName = group.layerName;
                    item.itemId = itemId;
                    item.sprite = scanned.sprite;
                    item.tintable = tintable;

                    if (existing == null)
                    {
                        item.presetColor = Color.white;
                        catalog.items.Add(item);
                        added++;
                    }
                    else
                    {
                        updated++;
                    }
                }
            }

            EditorUtility.SetDirty(catalog);
            AssetDatabase.SaveAssets();
        }

        static Dictionary<string, string> BuildAliasMap(ClothingCatalog catalog)
        {
            var map = new Dictionary<string, string>();
            if (catalog?.filePrefixAliases == null)
                return map;

            for (int i = 0; i < catalog.filePrefixAliases.Count; i++)
            {
                FilePrefixAlias a = catalog.filePrefixAliases[i];
                if (a == null || string.IsNullOrEmpty(a.filePrefix) || string.IsNullOrEmpty(a.layerName))
                    continue;
                map[a.filePrefix] = a.layerName;
            }

            return map;
        }

        static List<string> CollectConfiguredLayers(Transform bodyPanelRoot, ClothingCatalog catalog)
        {
            var set = new HashSet<string>();

            if (catalog?.tags != null)
            {
                for (int t = 0; t < catalog.tags.Count; t++)
                {
                    WardrobeTagDef tag = catalog.tags[t];
                    if (tag?.layers == null)
                        continue;
                    for (int L = 0; L < tag.layers.Count; L++)
                    {
                        if (!string.IsNullOrEmpty(tag.layers[L]))
                            set.Add(tag.layers[L]);
                    }
                }
            }

            // 别名目标图层也纳入匹配（即使还没写进 Tag）
            if (catalog?.filePrefixAliases != null)
            {
                for (int i = 0; i < catalog.filePrefixAliases.Count; i++)
                {
                    FilePrefixAlias a = catalog.filePrefixAliases[i];
                    if (a != null && !string.IsNullOrEmpty(a.layerName))
                        set.Add(a.layerName);
                }
            }

            if (set.Count == 0)
                return CollectLayerNames(bodyPanelRoot);

            List<string> panelLayers = CollectLayerNames(bodyPanelRoot);
            var result = new List<string>();
            for (int i = 0; i < panelLayers.Count; i++)
            {
                if (set.Contains(panelLayers[i]))
                    result.Add(panelLayers[i]);
            }

            foreach (string name in set)
            {
                if (!result.Contains(name))
                    result.Add(name);
            }

            return result;
        }

        static List<string> BuildMatchKeys(List<string> layerNames, Dictionary<string, string> aliases)
        {
            var keys = new HashSet<string>();
            for (int i = 0; i < layerNames.Count; i++)
                keys.Add(layerNames[i]);

            foreach (KeyValuePair<string, string> alias in aliases)
            {
                // 只有目标图层在匹配集里时，才启用该文件前缀
                if (keys.Contains(alias.Value))
                    keys.Add(alias.Key);
            }

            return keys.OrderByDescending(k => k.Length).ToList();
        }

        static bool TryResolveLayer(
            string fileName,
            List<string> matchKeys,
            Dictionary<string, string> aliases,
            out string layerName,
            out int index)
        {
            layerName = null;
            index = 0;

            for (int i = 0; i < matchKeys.Count; i++)
            {
                string key = matchKeys[i];
                if (!fileName.StartsWith(key))
                    continue;

                string rest = fileName.Substring(key.Length);
                Match match = ExactIndexRegex.Match(rest);
                if (!match.Success)
                    continue;

                index = int.Parse(match.Groups["num"].Value);
                layerName = aliases.TryGetValue(key, out string mapped) ? mapped : key;
                return true;
            }

            return false;
        }
    }
}
