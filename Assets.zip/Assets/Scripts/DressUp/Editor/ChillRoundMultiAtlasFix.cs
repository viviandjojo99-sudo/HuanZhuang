using TMPro;
using UnityEditor;
using UnityEngine;

namespace DressUp.Editor
{
    /// <summary>
    /// ChillRoundM 有中文，但 Dynamic 图集满且未开 Multi Atlas 时，新字会变口。
    /// 只打开 Multi Atlas，不换字体。
    /// </summary>
    public static class ChillRoundMultiAtlasFix
    {
        const string ChillPath = "Assets/Fonts/ChillRoundM SDF.asset";

        [InitializeOnLoadMethod]
        static void Boot()
        {
            EditorApplication.delayCall += Ensure;
        }

        public static void Menu() => Ensure(forceLog: true);

        static void Ensure() => Ensure(forceLog: false);

        static void Ensure(bool forceLog)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            TMP_FontAsset font = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(ChillPath);
            if (font == null)
                return;

            if (font.isMultiAtlasTexturesEnabled)
            {
                if (forceLog)
                    Debug.Log("[ChillRoundM] Multi Atlas 已开启。");
                return;
            }

            font.isMultiAtlasTexturesEnabled = true;
            EditorUtility.SetDirty(font);
            AssetDatabase.SaveAssets();
            Debug.Log("[ChillRoundM] 已开启 Multi Atlas：图集满时会自动扩，新中文不再变口。");
        }
    }
}
