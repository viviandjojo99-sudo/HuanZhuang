using System.Collections.Generic;
using DressUp.Data;
using UnityEditor;
using UnityEngine;

namespace DressUp.Editor
{
    /// <summary>
    /// 1) 填 Tag 名称 + 哪些图层属于它
    /// 2) 浏览每个 Tag 下的衣服
    /// 3) 按文件名一键导入（图片 → 图层）
    /// </summary>
    public class ClothingCatalogBrowserWindow : EditorWindow
    {
        ClothingCatalog catalog;
        Transform bodyPanelRoot;
        DefaultAsset artFolder;
        bool tintable = true;

        List<ScannedLayerGroup> scanGroups = new List<ScannedLayerGroup>();
        Vector2 tagsConfigScroll;
        Vector2 tagScroll;
        Vector2 itemScroll;
        Vector2 detailScroll;
        Vector2 scanScroll;

        string selectedTag;
        int selectedItemIndex = -1;
        int selectedTagDefIndex = -1;

        enum Tab
        {
            Tags,
            Browse,
            Import
        }

        Tab tab;

        [MenuItem("Tools/换装/图鉴浏览器", false, 0)]
        public static void Open()
        {
            var win = GetWindow<ClothingCatalogBrowserWindow>("图鉴浏览器");
            win.minSize = new Vector2(920, 540);
        }

        public static void OpenImport()
        {
            Open();
            GetWindow<ClothingCatalogBrowserWindow>().tab = Tab.Import;
        }

        void OnEnable()
        {
            if (catalog == null)
            {
                catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(
                    "Assets/ScriptableObjects/DressUp/Catalog_BodyPanel.asset");
            }

            if (bodyPanelRoot == null)
            {
                GameObject go = GameObject.Find("BodyPanel");
                if (go != null)
                    bodyPanelRoot = go.transform;
            }

            if (artFolder == null)
                artFolder = AssetDatabase.LoadAssetAtPath<DefaultAsset>("Assets/Art/maleta");

            if (catalog != null)
                catalog.EnsureDefaultAliasesIfEmpty();
        }

        void OnGUI()
        {
            DrawHeader();

            if (catalog == null)
            {
                EditorGUILayout.HelpBox("拖入该角色的 ClothingCatalog（每个 BodyPanel 一份）。", MessageType.Warning);
                return;
            }

            tab = (Tab)GUILayout.Toolbar((int)tab, new[] { "① 配置 Tag", "② 浏览衣服", "③ 一键导入" });
            EditorGUILayout.Space(6);

            switch (tab)
            {
                case Tab.Tags:
                    DrawTagsConfig();
                    break;
                case Tab.Browse:
                    DrawBrowse();
                    break;
                case Tab.Import:
                    DrawImport();
                    break;
            }

            if (GUI.changed)
                EditorUtility.SetDirty(catalog);
        }

        void DrawHeader()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            catalog = (ClothingCatalog)EditorGUILayout.ObjectField(catalog, typeof(ClothingCatalog), false, GUILayout.Width(260));
            bodyPanelRoot = (Transform)EditorGUILayout.ObjectField(bodyPanelRoot, typeof(Transform), true, GUILayout.Width(180));
            if (GUILayout.Button("找 BodyPanel", EditorStyles.toolbarButton, GUILayout.Width(90)))
            {
                GameObject go = GameObject.Find("BodyPanel");
                if (go != null)
                    bodyPanelRoot = go.transform;
            }
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
        }

        // ---------- ① Tag 配置 ----------
        void DrawTagsConfig()
        {
            EditorGUILayout.HelpBox(
                "只填两件事：Tag 叫什么、下面有哪些图层。\n" +
                "例：Tag=Dec，图层=DecLeft / DecRight / Neck / Mask\n" +
                "例：Tag=Hat，图层=Hat / BackHat\n" +
                "不同 BodyPanel 用不同 Catalog，各自配自己的 Tag。",
                MessageType.Info);

            if (catalog.tags == null)
                catalog.tags = new List<WardrobeTagDef>();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("+ 添加 Tag", GUILayout.Height(26)))
            {
                catalog.tags.Add(new WardrobeTagDef { tagName = "NewTag", layers = new List<string>() });
                selectedTagDefIndex = catalog.tags.Count - 1;
            }

            if (bodyPanelRoot != null && GUILayout.Button("从 BodyPanel 列出图层名", GUILayout.Height(26)))
                ShowLayerNameDialog();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(4);
            tagsConfigScroll = EditorGUILayout.BeginScrollView(tagsConfigScroll);

            for (int i = 0; i < catalog.tags.Count; i++)
            {
                WardrobeTagDef tag = catalog.tags[i];
                if (tag == null)
                    continue;

                EditorGUILayout.BeginVertical("box");
                EditorGUILayout.BeginHorizontal();
                bool selected = selectedTagDefIndex == i;
                if (GUILayout.Toggle(selected, "编辑", "Button", GUILayout.Width(48)))
                    selectedTagDefIndex = i;

                tag.tagName = EditorGUILayout.TextField("Tag 名称", tag.tagName);
                if (GUILayout.Button("删除", GUILayout.Width(48)))
                {
                    catalog.tags.RemoveAt(i);
                    if (selectedTagDefIndex >= catalog.tags.Count)
                        selectedTagDefIndex = catalog.tags.Count - 1;
                    i--;
                    EditorGUILayout.EndHorizontal();
                    EditorGUILayout.EndVertical();
                    continue;
                }
                EditorGUILayout.EndHorizontal();

                tag.parentTag = EditorGUILayout.TextField("上级 Tag（二级才填）", tag.parentTag ?? "");

                if (tag.layers == null)
                    tag.layers = new List<string>();

                EditorGUILayout.LabelField("属于此 Tag 的图层");
                for (int L = 0; L < tag.layers.Count; L++)
                {
                    EditorGUILayout.BeginHorizontal();
                    tag.layers[L] = EditorGUILayout.TextField(tag.layers[L]);
                    if (bodyPanelRoot != null && GUILayout.Button("选", GUILayout.Width(32)))
                    {
                        ShowLayerPicker(tag, L);
                    }
                    if (GUILayout.Button("-", GUILayout.Width(24)))
                    {
                        tag.layers.RemoveAt(L);
                        L--;
                    }
                    EditorGUILayout.EndHorizontal();
                }

                if (GUILayout.Button("+ 图层", GUILayout.Width(80)))
                    tag.layers.Add("");

                EditorGUILayout.EndVertical();
                EditorGUILayout.Space(4);
            }

            EditorGUILayout.EndScrollView();
        }

        void ShowLayerNameDialog()
        {
            List<string> names = CatalogFolderScanner.CollectLayerNames(bodyPanelRoot);
            EditorUtility.DisplayDialog(
                "BodyPanel 图层",
                names.Count == 0 ? "没有找到带 Image 的子物体。" : string.Join("\n", names),
                "OK");
        }

        void ShowLayerPicker(WardrobeTagDef tag, int layerIndex)
        {
            List<string> names = CatalogFolderScanner.CollectLayerNames(bodyPanelRoot);
            var menu = new GenericMenu();
            for (int i = 0; i < names.Count; i++)
            {
                string name = names[i];
                menu.AddItem(new GUIContent(name), tag.layers[layerIndex] == name, () =>
                {
                    tag.layers[layerIndex] = name;
                    EditorUtility.SetDirty(catalog);
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        void ShowAliasLayerPicker(int aliasIndex)
        {
            if (catalog?.filePrefixAliases == null || aliasIndex < 0 || aliasIndex >= catalog.filePrefixAliases.Count)
                return;

            List<string> names = CatalogFolderScanner.CollectLayerNames(bodyPanelRoot);
            var menu = new GenericMenu();
            for (int i = 0; i < names.Count; i++)
            {
                string name = names[i];
                menu.AddItem(new GUIContent(name), catalog.filePrefixAliases[aliasIndex].layerName == name, () =>
                {
                    catalog.filePrefixAliases[aliasIndex].layerName = name;
                    EditorUtility.SetDirty(catalog);
                    Repaint();
                });
            }
            menu.ShowAsContext();
        }

        // ---------- ② 浏览 ----------
        void DrawBrowse()
        {
            EditorGUILayout.HelpBox("按 Tag 查看衣服。每件只属于一个图层；同层互斥，异层可同穿。", MessageType.None);

            EditorGUILayout.BeginHorizontal();

            EditorGUILayout.BeginVertical(GUILayout.Width(150));
            EditorGUILayout.LabelField("Tag", EditorStyles.boldLabel);
            tagScroll = EditorGUILayout.BeginScrollView(tagScroll);
            List<string> tagNames = catalog.GetTagNames();
            if (tagNames.Count == 0)
                EditorGUILayout.LabelField("先去「配置 Tag」");

            for (int i = 0; i < tagNames.Count; i++)
            {
                string name = tagNames[i];
                int count = catalog.GetItemsForTag(name).Count;
                if (GUILayout.Toggle(selectedTag == name, $"{name} ({count})", "Button"))
                {
                    if (selectedTag != name)
                    {
                        selectedTag = name;
                        selectedItemIndex = -1;
                    }
                }
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(GUILayout.Width(position.width * 0.48f));
            if (!string.IsNullOrEmpty(selectedTag))
            {
                WardrobeTagDef def = catalog.FindTag(selectedTag);
                string layerHint = def?.layers != null ? string.Join(", ", def.layers) : "";
                EditorGUILayout.LabelField($"衣服 · 图层: {layerHint}", EditorStyles.boldLabel);
            }
            else
            {
                EditorGUILayout.LabelField("衣服", EditorStyles.boldLabel);
            }

            itemScroll = EditorGUILayout.BeginScrollView(itemScroll);
            if (!string.IsNullOrEmpty(selectedTag))
            {
                List<ClothingItem> items = catalog.GetItemsForTag(selectedTag);
                const int cols = 4;
                int rows = Mathf.CeilToInt(items.Count / (float)cols);
                for (int r = 0; r < rows; r++)
                {
                    EditorGUILayout.BeginHorizontal();
                    for (int c = 0; c < cols; c++)
                    {
                        int index = r * cols + c;
                        if (index >= items.Count)
                        {
                            GUILayout.FlexibleSpace();
                            continue;
                        }
                        DrawThumb(items[index], index);
                    }
                    EditorGUILayout.EndHorizontal();
                }
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical();
            EditorGUILayout.LabelField("详情", EditorStyles.boldLabel);
            detailScroll = EditorGUILayout.BeginScrollView(detailScroll);
            DrawDetail();
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();

            EditorGUILayout.EndHorizontal();
        }

        void DrawThumb(ClothingItem item, int index)
        {
            Rect rect = GUILayoutUtility.GetRect(88, 108, GUILayout.Width(88), GUILayout.Height(108));
            if (selectedItemIndex == index)
                EditorGUI.DrawRect(rect, new Color(0.25f, 0.45f, 0.75f, 0.35f));

            Rect preview = new Rect(rect.x + 4, rect.y + 4, 80, 80);
            if (item.sprite != null)
                DrawSprite(preview, item.sprite, item.ResolvePresetColor());
            else
                EditorGUI.DrawRect(preview, Color.black);

            GUI.Label(new Rect(rect.x, rect.y + 84, 88, 24), $"{item.layerName}\n{item.itemId}", EditorStyles.miniLabel);

            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                selectedItemIndex = index;
                Event.current.Use();
                Repaint();
            }
        }

        void DrawDetail()
        {
            if (string.IsNullOrEmpty(selectedTag) || selectedItemIndex < 0)
            {
                EditorGUILayout.LabelField("点缩略图查看");
                return;
            }

            List<ClothingItem> items = catalog.GetItemsForTag(selectedTag);
            if (selectedItemIndex >= items.Count)
                return;

            ClothingItem item = items[selectedItemIndex];
            EditorGUI.BeginChangeCheck();

            if (item.sprite != null)
            {
                Rect r = GUILayoutUtility.GetRect(120, 120);
                DrawSprite(r, item.sprite, item.ResolvePresetColor());
            }

            item.itemId = EditorGUILayout.TextField("物品 Id", item.itemId);
            item.layerName = EditorGUILayout.TextField("所属图层", item.layerName);
            item.sprite = (Sprite)EditorGUILayout.ObjectField("图片", item.sprite, typeof(Sprite), false);
            item.presetColor = EditorGUILayout.ColorField("预设颜色", item.ResolvePresetColor());
            item.tintable = EditorGUILayout.Toggle("可染色", item.tintable);

            if (GUILayout.Button("删除这件", GUILayout.Height(26)))
            {
                catalog.items.Remove(item);
                selectedItemIndex = -1;
                EditorUtility.SetDirty(catalog);
                AssetDatabase.SaveAssets();
                return;
            }

            if (EditorGUI.EndChangeCheck())
                EditorUtility.SetDirty(catalog);
        }

        // ---------- ③ 一键导入 ----------
        void DrawImport()
        {
            catalog.EnsureDefaultAliasesIfEmpty();

            EditorGUILayout.HelpBox(
                "先在「配置 Tag」里写好图层，再选美术文件夹。\n" +
                "文件名规则：图层名+数字，如 Mask1.png。\n" +
                "若文件前缀和图层名不同，在下方「文件前缀 → 图层」里改（已预填常见项，可继续加）。",
                MessageType.Info);

            if (catalog.tags == null || catalog.tags.Count == 0)
                EditorGUILayout.HelpBox("还没有配置任何 Tag，请先去「① 配置 Tag」。", MessageType.Warning);

            artFolder = (DefaultAsset)EditorGUILayout.ObjectField("美术文件夹", artFolder, typeof(DefaultAsset), false);
            tintable = EditorGUILayout.Toggle("导入后可染色", tintable);

            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField("文件前缀 → BodyPanel 图层（可增删）", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("文件前缀", GUILayout.Width(140));
            GUILayout.Label("图层名", GUILayout.Width(140));
            EditorGUILayout.EndHorizontal();

            if (catalog.filePrefixAliases == null)
                catalog.filePrefixAliases = new List<FilePrefixAlias>();

            for (int i = 0; i < catalog.filePrefixAliases.Count; i++)
            {
                FilePrefixAlias a = catalog.filePrefixAliases[i];
                if (a == null)
                {
                    catalog.filePrefixAliases[i] = a = new FilePrefixAlias();
                }

                EditorGUILayout.BeginHorizontal();
                a.filePrefix = EditorGUILayout.TextField(a.filePrefix, GUILayout.Width(140));
                a.layerName = EditorGUILayout.TextField(a.layerName, GUILayout.Width(140));
                if (bodyPanelRoot != null && GUILayout.Button("选图层", GUILayout.Width(60)))
                {
                    int capture = i;
                    ShowAliasLayerPicker(capture);
                }
                if (GUILayout.Button("-", GUILayout.Width(24)))
                {
                    catalog.filePrefixAliases.RemoveAt(i);
                    i--;
                    EditorUtility.SetDirty(catalog);
                }
                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("+ 增加映射", GUILayout.Width(100)))
            {
                catalog.filePrefixAliases.Add(new FilePrefixAlias());
                EditorUtility.SetDirty(catalog);
            }
            if (GUILayout.Button("恢复预设", GUILayout.Width(100)))
            {
                catalog.filePrefixAliases = ClothingCatalog.CreateDefaultAliases();
                EditorUtility.SetDirty(catalog);
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(8);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("扫描", GUILayout.Height(30)))
                RunScan();

            using (new EditorGUI.DisabledScope(scanGroups.Count == 0))
            {
                if (GUILayout.Button("一键写入图鉴", GUILayout.Height(30)))
                    WriteScan();
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(4);
            EditorGUILayout.LabelField($"将导入的图层 · {scanGroups.Count}", EditorStyles.boldLabel);
            scanScroll = EditorGUILayout.BeginScrollView(scanScroll);

            for (int i = 0; i < scanGroups.Count; i++)
            {
                ScannedLayerGroup g = scanGroups[i];
                EditorGUILayout.BeginHorizontal();
                g.import = EditorGUILayout.Toggle(g.import, GUILayout.Width(20));
                EditorGUILayout.LabelField(g.layerName, GUILayout.Width(110));
                EditorGUILayout.LabelField($"{g.sprites.Count} 张", GUILayout.Width(48));

                string whichTag = FindTagNameForLayer(g.layerName);
                EditorGUILayout.LabelField(string.IsNullOrEmpty(whichTag) ? "（未归属 Tag）" : $"→ Tag「{whichTag}」", GUILayout.Width(140));

                int show = Mathf.Min(5, g.sprites.Count);
                for (int s = 0; s < show; s++)
                {
                    Rect r = GUILayoutUtility.GetRect(32, 32, GUILayout.Width(32), GUILayout.Height(32));
                    if (g.sprites[s].sprite != null)
                        DrawSprite(r, g.sprites[s].sprite, Color.white);
                }
                EditorGUILayout.EndHorizontal();
            }

            EditorGUILayout.EndScrollView();
        }

        string FindTagNameForLayer(string layerName)
        {
            if (catalog?.tags == null)
                return null;
            for (int i = 0; i < catalog.tags.Count; i++)
            {
                WardrobeTagDef tag = catalog.tags[i];
                if (tag?.layers == null)
                    continue;
                for (int L = 0; L < tag.layers.Count; L++)
                {
                    if (tag.layers[L] == layerName)
                        return tag.tagName;
                }
            }
            return null;
        }

        void RunScan()
        {
            if (artFolder == null)
            {
                EditorUtility.DisplayDialog("扫描", "请指定美术文件夹。", "OK");
                return;
            }

            string path = AssetDatabase.GetAssetPath(artFolder);
            scanGroups = CatalogFolderScanner.Scan(bodyPanelRoot, path, catalog);
            if (scanGroups.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "没有匹配",
                    "请确认：① Tag 里已填写图层名；② 文件名为「图层名+数字」。",
                    "OK");
            }
            Repaint();
        }

        void WriteScan()
        {
            CatalogFolderScanner.WriteToCatalog(catalog, scanGroups, tintable, out int added, out int updated);
            selectedTag = null;
            selectedItemIndex = -1;
            tab = Tab.Browse;
            EditorUtility.DisplayDialog("完成", $"新增 {added}，更新 {updated}。", "OK");
            Repaint();
        }

        static void DrawSprite(Rect rect, Sprite sprite, Color tint)
        {
            if (sprite == null || sprite.texture == null)
                return;
            Texture2D tex = sprite.texture;
            Rect tr = sprite.textureRect;
            var uv = new Rect(tr.x / tex.width, tr.y / tex.height, tr.width / tex.width, tr.height / tex.height);
            Color previous = GUI.color;
            GUI.color = tint;
            GUI.DrawTextureWithTexCoords(rect, tex, uv);
            GUI.color = previous;
        }
    }

    [CustomEditor(typeof(ClothingCatalog))]
    public class ClothingCatalogInspector : UnityEditor.Editor
    {
        public override void OnInspectorGUI()
        {
            if (GUILayout.Button("打开图鉴浏览器", GUILayout.Height(30)))
                ClothingCatalogBrowserWindow.Open();
            EditorGUILayout.Space();
            DrawDefaultInspector();
        }
    }
}
