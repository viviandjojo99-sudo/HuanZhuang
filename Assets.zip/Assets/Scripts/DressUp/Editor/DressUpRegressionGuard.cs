using DressUp.Actions;
using DressUp.Avatar;
using DressUp.Wardrobe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Editor
{
    /// <summary>
    /// 进 Play / 菜单校验：防止「已实现功能莫名消失」的常见回退点。
    /// </summary>
    [InitializeOnLoad]
    public static class DressUpRegressionGuard
    {
        static DressUpRegressionGuard()
        {
            EditorApplication.playModeStateChanged += OnPlayMode;
        }

        static void OnPlayMode(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.ExitingEditMode)
                Validate(logOnly: true);
        }

        public static void ValidateMenu()
        {
            int issues = Validate(logOnly: false);
            if (issues == 0)
                EditorUtility.DisplayDialog("换装校验", "通过：关键绑定与 Plot/Maleta 配置正常。", "OK");
            else
                EditorUtility.DisplayDialog("换装校验", $"发现 {issues} 处问题，已尝试自动修复并写进 Console。", "OK");
        }

        static int Validate(bool logOnly)
        {
            int issues = 0;

            issues += CheckPlotPrefab(logOnly);
            issues += CheckMaletaScroll(logOnly);
            issues += CheckAvatarWiring(logOnly);

            if (issues > 0 && !logOnly)
                EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());

            if (issues == 0)
                Debug.Log("[DressUpGuard] 校验通过");
            return issues;
        }

        static int CheckPlotPrefab(bool logOnly)
        {
            int issues = 0;
            const string path = "Assets/Prefab/Plot.prefab";
            GameObject root = PrefabUtility.LoadPrefabContents(path);
            if (root == null)
            {
                Debug.LogError("[DressUpGuard] 找不到 Plot.prefab");
                return 1;
            }

            try
            {
                Button button = root.GetComponent<Button>();
                if (button == null)
                {
                    issues++;
                    Debug.LogError("[DressUpGuard] Plot 缺少 Button —— 点击换装会失效。");
                    if (!logOnly)
                    {
                        button = root.AddComponent<Button>();
                        button.transition = Selectable.Transition.None;
                        Image img = root.GetComponent<Image>();
                        if (img != null)
                            button.targetGraphic = img;
                    }
                }
                else if (button.transition != Selectable.Transition.None)
                {
                    issues++;
                    Debug.LogError("[DressUpGuard] Plot Button 应为 None。穿着暗色由 ClothingPlotView 写 Image，Color Tint 会盖掉。");
                    if (!logOnly)
                        button.transition = Selectable.Transition.None;
                }

                Transform pic = root.transform.Find("Pic");
                Image picImage = pic != null ? pic.GetComponent<Image>() : null;
                if (picImage != null && picImage.raycastTarget)
                {
                    issues++;
                    Debug.LogError("[DressUpGuard] Plot/Pic.raycastTarget=ON 会抢走点击。");
                    if (!logOnly)
                        picImage.raycastTarget = false;
                }

                if (!logOnly && issues > 0)
                    PrefabUtility.SaveAsPrefabAsset(root, path);
            }
            finally
            {
                PrefabUtility.UnloadPrefabContents(root);
            }

            return issues;
        }

        static int CheckMaletaScroll(bool logOnly)
        {
            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
                return 0;

            int issues = 0;
            ScrollRect scroll = maleta.GetComponentInChildren<ScrollRect>(true);
            if (scroll != null && scroll.horizontal)
            {
                issues++;
                Debug.LogError("[DressUpGuard] Maleta ScrollRect.horizontal 被打开了（应只竖滑）。");
                if (!logOnly)
                {
                    scroll.horizontal = false;
                    scroll.horizontalScrollbar = null;
                }
            }

            WardrobeController wardrobe = maleta.GetComponent<WardrobeController>();
            if (wardrobe != null)
            {
                SerializedObject so = new SerializedObject(wardrobe);
                Transform content = so.FindProperty("contentRoot").objectReferenceValue as Transform;
                if (content != null)
                {
                    ContentSizeFitter fitter = content.GetComponent<ContentSizeFitter>();
                    if (fitter != null && fitter.horizontalFit != ContentSizeFitter.FitMode.Unconstrained)
                    {
                        issues++;
                        Debug.LogError("[DressUpGuard] Maleta ContentSizeFitter 横向 Fit 会撑出横滑。");
                        if (!logOnly)
                            fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
                    }
                }
            }

            return issues;
        }

        static int CheckAvatarWiring(bool logOnly)
        {
            WardrobeController wardrobe = Object.FindAnyObjectByType<WardrobeController>();
            if (wardrobe == null)
                return 0;

            int issues = 0;
            BodyAvatar expected = wardrobe.TargetAvatar;
            if (expected == null)
            {
                Debug.LogWarning("[DressUpGuard] WardrobeController.TargetAvatar 为空。");
                return 0;
            }

            issues += FixIfMismatch(Object.FindAnyObjectByType<AvatarClearButton>()?.TargetAvatar, expected,
                "AvatarClearButton", logOnly, a =>
                {
                    var btn = Object.FindAnyObjectByType<AvatarClearButton>();
                    if (btn != null) btn.SetTargetAvatar(expected);
                });

            issues += FixIfMismatch(Object.FindAnyObjectByType<AvatarExportButton>()?.TargetAvatar, expected,
                "AvatarExportButton", logOnly, a =>
                {
                    var btn = Object.FindAnyObjectByType<AvatarExportButton>();
                    if (btn != null) btn.SetTargetAvatar(expected);
                });

            issues += FixIfMismatch(Object.FindAnyObjectByType<AvatarSaveButton>()?.TargetAvatar, expected,
                "AvatarSaveButton", logOnly, a =>
                {
                    var btn = Object.FindAnyObjectByType<AvatarSaveButton>();
                    if (btn != null) btn.SetTargetAvatar(expected);
                });

            return issues;
        }

        static int FixIfMismatch(BodyAvatar actual, BodyAvatar expected, string label, bool logOnly, System.Action<BodyAvatar> fix)
        {
            if (actual == null || actual == expected)
                return 0;

            Debug.LogError(
                $"[DressUpGuard] {label} 指向「{actual.CharacterId}」，衣柜是「{expected.CharacterId}」——功能会像消失一样。");
            if (!logOnly)
                fix(expected);
            return 1;
        }
    }
}
