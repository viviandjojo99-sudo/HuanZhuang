using DressUp.Actions;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Tinting;
using DressUp.Data;
using DressUp.Motion;
using DressUp.Wardrobe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Editor
{
    public static class DressUpSceneSetup
    {
        const string CatalogFolder = "Assets/ScriptableObjects/DressUp";

        public static void SetupBodyPanelCatalog()
        {
            BodyPanelCatalogSetup.RunFromMenu();
        }

        public static void SetupTagNavigator()
        {
            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
            {
                EditorUtility.DisplayDialog("二级 Tag", "场景中找不到 Maleta。", "OK");
                return;
            }

            WardrobeController wardrobe = maleta.GetComponent<WardrobeController>();
            if (wardrobe == null)
            {
                EditorUtility.DisplayDialog("二级 Tag", "Maleta 上没有 WardrobeController。", "OK");
                return;
            }

            WardrobeTagNavigator nav = maleta.GetComponent<WardrobeTagNavigator>();
            if (nav == null)
                nav = Undo.AddComponent<WardrobeTagNavigator>(maleta);

            Transform tag1 = FindDeep(maleta.transform, "TagA") ?? FindDeep(maleta.transform, "Tag1");
            Transform tag2 = FindDeep(maleta.transform, "TagB") ?? FindDeep(maleta.transform, "Tag2");
            var nso = new SerializedObject(nav);
            nso.FindProperty("tag1Root").objectReferenceValue = tag1;
            nso.FindProperty("tag2Root").objectReferenceValue = tag2;
            nso.FindProperty("wardrobe").objectReferenceValue = wardrobe;
            nso.ApplyModifiedProperties();

            var wso = new SerializedObject(wardrobe);
            SerializedProperty navProp = wso.FindProperty("tagNavigator");
            if (navProp != null)
            {
                navProp.objectReferenceValue = nav;
                wso.ApplyModifiedProperties();
            }

            if (tag2 != null)
            {
                Undo.RecordObject(tag2.gameObject, "Hide TagB");
                tag2.gameObject.SetActive(false);
            }

            if (tag1 != null && tag1.GetComponent<DressUp.Motion.UiTagColumnStaggerMotion>() == null)
                Undo.AddComponent<DressUp.Motion.UiTagColumnStaggerMotion>(tag1.gameObject);
            if (tag2 != null && tag2.GetComponent<DressUp.Motion.UiTagColumnStaggerMotion>() == null)
                Undo.AddComponent<DressUp.Motion.UiTagColumnStaggerMotion>(tag2.gameObject);

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            EditorUtility.DisplayDialog(
                "二级 Tag",
                "已挂 WardrobeTagNavigator。\n点 Hair → TagA 错峰缩回，TagB 弹出呆毛/边发/刘海/侧发/后发/后发辫子。\nTagB 第一格为返回。",
                "OK");
        }

        public static void BindSampleScene()
        {
            EnsureCatalogFolder();

            ClothingCatalog catalogBody = EnsureCatalog("Catalog_BodyPanel");
            ClothingCatalog catalogBody3 = EnsureCatalog("Catalog_BodyPanel3");
            ClothingCatalog catalogStrawberry = EnsureCatalog("Catalog_BodyPanelStrawberry");

            BodyAvatar avatar1 = EnsureAvatar("BodyPanel", "BodyPanel", new[] { "Body" });
            BodyAvatar avatar3 = EnsureAvatar("BodyPanel3", "BodyPanel3", new[] { "Body", "Eye" });
            BodyAvatar avatarS = EnsureAvatar("BodyPanelStrawberry", "BodyPanelStrawberry", new[] { "Body", "Eye" });

            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
            {
                EditorUtility.DisplayDialog("绑定失败", "场景中找不到 Maleta。", "OK");
                return;
            }

            WardrobeController wardrobe = maleta.GetComponent<WardrobeController>();
            if (wardrobe == null)
                wardrobe = Undo.AddComponent<WardrobeController>(maleta);

            // 衣服列表 Content：优先选子节点含 Plot 的那个
            Transform clothesContent = FindClothesContent(maleta.transform);
            Transform tagRoot = FindDeep(maleta.transform, "Tag");

            SerializedObject soWardrobe = new SerializedObject(wardrobe);
            // 默认指向当前激活角色；多角色由 ActiveAvatarBinder 运行时切换
            BodyAvatar defaultAvatar = avatar1 != null && avatar1.gameObject.activeInHierarchy
                ? avatar1
                : (avatar3 != null ? avatar3 : avatarS);
            ClothingCatalog defaultCatalog = defaultAvatar == avatar1 ? catalogBody
                : defaultAvatar == avatarS ? catalogStrawberry
                : catalogBody3;

            soWardrobe.FindProperty("targetAvatar").objectReferenceValue = defaultAvatar;
            soWardrobe.FindProperty("catalog").objectReferenceValue = defaultCatalog;
            soWardrobe.FindProperty("contentRoot").objectReferenceValue = null; // 运行时自动找

            GameObject plotPrefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefab/Plot.prefab");
            soWardrobe.FindProperty("plotPrefab").objectReferenceValue = plotPrefab;
            soWardrobe.FindProperty("insertEmptySlotFirst").boolValue = true;
            soWardrobe.FindProperty("zoomThumbnails").boolValue = true;
            soWardrobe.ApplyModifiedProperties();

            if (tagRoot != null)
            {
                for (int i = 0; i < tagRoot.childCount; i++)
                {
                    Transform child = tagRoot.GetChild(i);
                    WardrobeTag tag = child.GetComponent<WardrobeTag>();
                    if (tag == null)
                        tag = Undo.AddComponent<WardrobeTag>(child.gameObject);
                }
            }

            Canvas canvas = Object.FindAnyObjectByType<Canvas>();
            if (canvas == null)
            {
                EditorUtility.DisplayDialog("绑定失败", "场景中找不到 Canvas。", "OK");
                return;
            }

            GameObject binderGo = GameObject.Find("DressUpBinder");
            if (binderGo == null)
            {
                binderGo = new GameObject("DressUpBinder");
                Undo.RegisterCreatedObjectUndo(binderGo, "Create DressUpBinder");
                binderGo.transform.SetParent(canvas.transform, false);
            }

            ActiveAvatarBinder binder = binderGo.GetComponent<ActiveAvatarBinder>();
            if (binder == null)
                binder = Undo.AddComponent<ActiveAvatarBinder>(binderGo);

            LayerColorController color = EnsureColorUi(canvas.transform);
            AvatarExportButton exportBtn = EnsureActionButton(canvas.transform, "ButtonOutput", "导出", typeof(AvatarExportButton)) as AvatarExportButton;
            AvatarClearButton clearBtn = EnsureActionButton(canvas.transform, "ButtonClear", "清空", typeof(AvatarClearButton)) as AvatarClearButton;
            AvatarSaveButton saveBtn = EnsureActionButton(canvas.transform, "ButtonSave", "保存", typeof(AvatarSaveButton)) as AvatarSaveButton;

            // 所有按钮与衣柜必须指向同一角色，禁止再写死 BodyPanel3
            if (exportBtn != null)
            {
                SerializedObject so = new SerializedObject(exportBtn);
                so.FindProperty("targetAvatar").objectReferenceValue = defaultAvatar;
                so.ApplyModifiedProperties();
            }

            if (clearBtn != null)
            {
                SerializedObject so = new SerializedObject(clearBtn);
                so.FindProperty("targetAvatar").objectReferenceValue = defaultAvatar;
                so.ApplyModifiedProperties();
            }

            if (saveBtn != null)
            {
                SerializedObject so = new SerializedObject(saveBtn);
                so.FindProperty("targetAvatar").objectReferenceValue = defaultAvatar;
                so.FindProperty("catalog").objectReferenceValue = defaultCatalog;
                so.ApplyModifiedProperties();
            }

            SerializedObject soBinder = new SerializedObject(binder);
            SerializedProperty list = soBinder.FindProperty("characters");
            list.arraySize = 3;
            SetBinding(list.GetArrayElementAtIndex(0), "BodyPanel", avatar1, catalogBody);
            SetBinding(list.GetArrayElementAtIndex(1), "BodyPanel3", avatar3, catalogBody3);
            SetBinding(list.GetArrayElementAtIndex(2), "BodyPanelStrawberry", avatarS, catalogStrawberry);
            // 必须跟衣柜 defaultAvatar 一致，禁止再默认锁死 BodyPanel3
            int active = 0;
            if (defaultAvatar == avatar3)
                active = 1;
            else if (defaultAvatar == avatarS)
                active = 2;
            soBinder.FindProperty("activeIndex").intValue = active;
            soBinder.FindProperty("wardrobe").objectReferenceValue = wardrobe;
            soBinder.FindProperty("colorController").objectReferenceValue = color;
            soBinder.FindProperty("exportButton").objectReferenceValue = exportBtn;
            soBinder.FindProperty("clearButton").objectReferenceValue = clearBtn;
            soBinder.FindProperty("saveButton").objectReferenceValue = saveBtn;
            soBinder.ApplyModifiedProperties();

            EnsureDressUpAudio();
            EnsureWardrobePanelMotion();
            EnsureWearPopOnAvatars();

            if (wardrobe != null && color != null)
            {
                SerializedObject soW = new SerializedObject(wardrobe);
                soW.FindProperty("colorController").objectReferenceValue = color;
                soW.ApplyModifiedProperties();
            }

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            EditorUtility.DisplayDialog(
                "绑定完成",
                "已给三个 BodyPanel 挂 BodyAvatar，Maleta 挂衣柜，并创建 DressUpBinder / 功能按钮 / 染色条 / 音效 / 开合动效。\n\n" +
                "请在 Inspector 里：\n" +
                "1) 给每个 Tag 填类别\n" +
                "2) 打开图鉴浏览器，在导入页填充 Catalog\n" +
                "3) 调整按钮与 Scrollbar 位置",
                "OK");
        }

        public static void EnsureWardrobePanelMotion()
        {
            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
            {
                Debug.LogWarning("[DressUp] 找不到 Maleta");
                return;
            }

            RectTransform maletaRt = maleta.transform as RectTransform;
            UiSlideMotion maletaSlide = maleta.GetComponent<UiSlideMotion>();
            if (maletaSlide == null)
                maletaSlide = Undo.AddComponent<UiSlideMotion>(maleta);

            // Button 在 Canvas 下，不在 Maleta 里
            GameObject buttonGo = GameObject.Find("Button");
            RectTransform actionRt = buttonGo != null ? buttonGo.transform as RectTransform : null;
            CanvasGroup actionGroup = null;
            UiSlideMotion actionSlide = null;
            UiFadeMotion actionFade = null;
            if (buttonGo != null)
            {
                actionGroup = buttonGo.GetComponent<CanvasGroup>();
                if (actionGroup == null)
                    actionGroup = Undo.AddComponent<CanvasGroup>(buttonGo);

                actionFade = buttonGo.GetComponent<UiFadeMotion>();
                if (actionFade == null)
                    actionFade = Undo.AddComponent<UiFadeMotion>(buttonGo);

                actionSlide = buttonGo.GetComponent<UiSlideMotion>();
                if (actionSlide == null)
                    actionSlide = Undo.AddComponent<UiSlideMotion>(buttonGo);

                EnsurePressMotion(buttonGo.transform.Find("ButtonOutput")?.gameObject);
                EnsurePressMotion(buttonGo.transform.Find("ButtonClear")?.gameObject);
                EnsurePressMotion(buttonGo.transform.Find("ButtonRandom")?.gameObject);
                EnsurePressMotion(buttonGo.transform.Find("ButtonSave")?.gameObject);
            }

            GameObject clothGo = GameObject.Find("ButtonCloth");
            Button clothBtn = clothGo != null ? clothGo.GetComponent<Button>() : null;
            EnsurePressMotion(clothGo);

            AvatarSaveButton saveBtn = Object.FindAnyObjectByType<AvatarSaveButton>();
            LayerColorController color = Object.FindAnyObjectByType<LayerColorController>();
            if (color != null)
            {
                if (color.GetComponent<CanvasGroup>() == null)
                    Undo.AddComponent<CanvasGroup>(color.gameObject);
                if (color.GetComponent<UiFadeMotion>() == null)
                    Undo.AddComponent<UiFadeMotion>(color.gameObject);
            }

            WardrobePanelController panel = maleta.GetComponent<WardrobePanelController>();
            if (panel == null)
                panel = Object.FindAnyObjectByType<WardrobePanelController>();
            if (panel == null)
            {
                GameObject host = GameObject.Find("DressUpBinder");
                if (host == null)
                    host = maleta;
                panel = host.GetComponent<WardrobePanelController>();
                if (panel == null)
                    panel = Undo.AddComponent<WardrobePanelController>(host);
            }

            SerializedObject so = new SerializedObject(panel);
            so.FindProperty("maletaRoot").objectReferenceValue = maletaRt;
            so.FindProperty("maletaSlide").objectReferenceValue = maletaSlide;
            so.FindProperty("maletaClosedAnchoredX").floatValue = -420f;
            so.FindProperty("actionButtonsRoot").objectReferenceValue = actionRt;
            so.FindProperty("actionButtonsGroup").objectReferenceValue = actionGroup;
            so.FindProperty("actionButtonsSlide").objectReferenceValue = actionSlide;
            so.FindProperty("actionButtonsFade").objectReferenceValue = actionFade;
            so.FindProperty("actionButtonsSlideDistance").floatValue = 220f;
            so.FindProperty("colorController").objectReferenceValue = color;
            so.FindProperty("openButton").objectReferenceValue = clothBtn;
            so.FindProperty("confirmSaveButton").objectReferenceValue = saveBtn;
            so.FindProperty("startClosed").boolValue = true;
            so.ApplyModifiedProperties();

            // 防止 Tools 重绑时把 Maleta 横滑勾回来
            ScrollRect maletaScroll = maleta.GetComponentInChildren<ScrollRect>(true);
            if (maletaScroll != null)
            {
                maletaScroll.horizontal = false;
                maletaScroll.horizontalScrollbar = null;
            }

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            Debug.Log("[DressUp] 已绑定衣柜开合：Maleta 左滑 / Button 右滑 / Save 关柜淡出 BAR");
        }

        public static void EnsureWearPopOnAvatars()
        {
            string[] names = { "BodyPanel", "BodyPanel3", "BodyPanelStrawberry" };
            for (int i = 0; i < names.Length; i++)
            {
                GameObject go = GameObject.Find(names[i]);
                if (go == null)
                    continue;
                if (go.GetComponent<BodyAvatar>() == null)
                    continue;
                if (go.GetComponent<BodyAvatarWearPop>() == null)
                    Undo.AddComponent<BodyAvatarWearPop>(go);
            }

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            Debug.Log("[DressUp] 已给 BodyPanel 绑定 WearPop");
        }

        static void EnsurePressMotion(GameObject go)
        {
            if (go == null)
                return;
            if (go.GetComponent<UiButtonPressMotion>() == null)
                Undo.AddComponent<UiButtonPressMotion>(go);
            Button button = go.GetComponent<Button>();
            if (button != null)
            {
                Undo.RecordObject(button, "Disable Button Transition");
                button.transition = Selectable.Transition.None;
            }
        }

        public static void EnsureDressUpAudio()
        {
            DressUpAudio audio = Object.FindAnyObjectByType<DressUpAudio>();
            if (audio == null)
            {
                GameObject go = new GameObject("DressUpAudio");
                Undo.RegisterCreatedObjectUndo(go, "Create DressUpAudio");
                audio = Undo.AddComponent<DressUpAudio>(go);
            }

            SerializedObject so = new SerializedObject(audio);
            so.FindProperty("selectClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/select.ogg");
            so.FindProperty("popupClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Popup.ogg");
            so.FindProperty("errorClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Error.ogg");
            so.FindProperty("error2Clip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Error2.ogg");
            so.FindProperty("confirmClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Save.ogg");
            so.FindProperty("backClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/undo.ogg");
            so.FindProperty("deleteClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Error.ogg");
            so.FindProperty("bgmClip").objectReferenceValue = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/Resources/DressUp/Lofi1.ogg");
            so.ApplyModifiedProperties();

            EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
            Debug.Log("[DressUp] 已绑定音效：select / Popup / Error / Error2 / Save / undo / Lofi1");
        }

        static void SetBinding(SerializedProperty element, string rootName, BodyAvatar avatar, ClothingCatalog catalog)
        {
            GameObject root = GameObject.Find(rootName);
            element.FindPropertyRelative("displayName").stringValue = rootName;
            element.FindPropertyRelative("bodyPanelRoot").objectReferenceValue = root;
            element.FindPropertyRelative("avatar").objectReferenceValue = avatar;
            element.FindPropertyRelative("catalog").objectReferenceValue = catalog;
        }

        static BodyAvatar EnsureAvatar(string objectName, string characterId, string[] keep)
        {
            GameObject go = GameObject.Find(objectName);
            if (go == null)
                return null;

            BodyAvatar avatar = go.GetComponent<BodyAvatar>();
            if (avatar == null)
                avatar = Undo.AddComponent<BodyAvatar>(go);

            SerializedObject so = new SerializedObject(avatar);
            so.FindProperty("characterId").stringValue = characterId;
            SerializedProperty keepProp = so.FindProperty("keepOnClear");
            keepProp.arraySize = keep.Length;
            for (int i = 0; i < keep.Length; i++)
                keepProp.GetArrayElementAtIndex(i).stringValue = keep[i];
            so.ApplyModifiedProperties();
            return avatar;
        }

        static ClothingCatalog EnsureCatalog(string assetName)
        {
            EnsureCatalogFolder();
            string path = $"{CatalogFolder}/{assetName}.asset";
            ClothingCatalog catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(path);
            if (catalog != null)
                return catalog;

            catalog = ScriptableObject.CreateInstance<ClothingCatalog>();
            AssetDatabase.CreateAsset(catalog, path);
            AssetDatabase.SaveAssets();
            return catalog;
        }

        static void EnsureCatalogFolder()
        {
            if (!AssetDatabase.IsValidFolder("Assets/ScriptableObjects"))
                AssetDatabase.CreateFolder("Assets", "ScriptableObjects");
            if (!AssetDatabase.IsValidFolder(CatalogFolder))
                AssetDatabase.CreateFolder("Assets/ScriptableObjects", "DressUp");
        }

        static Transform FindClothesContent(Transform maleta)
        {
            // 优先：Scroll View 下名为 Content 且有多个 Plot 子物体
            Transform[] all = maleta.GetComponentsInChildren<Transform>(true);
            Transform best = null;
            int bestScore = -1;
            for (int i = 0; i < all.Length; i++)
            {
                Transform t = all[i];
                if (t.name != "Content")
                    continue;

                int plotCount = 0;
                for (int c = 0; c < t.childCount; c++)
                {
                    if (t.GetChild(c).name.StartsWith("Plot"))
                        plotCount++;
                }

                if (plotCount > bestScore)
                {
                    bestScore = plotCount;
                    best = t;
                }
            }

            return best;
        }

        static Transform FindDeep(Transform root, string name)
        {
            if (root.name == name)
                return root;
            for (int i = 0; i < root.childCount; i++)
            {
                Transform found = FindDeep(root.GetChild(i), name);
                if (found != null)
                    return found;
            }

            return null;
        }

        static LayerColorController EnsureColorUi(Transform canvas)
        {
            GameObject root = GameObject.Find("DressUpColor");
            if (root == null)
            {
                root = new GameObject("DressUpColor", typeof(RectTransform));
                Undo.RegisterCreatedObjectUndo(root, "Create DressUpColor");
                root.transform.SetParent(canvas, false);
                RectTransform rt = root.GetComponent<RectTransform>();
                rt.anchorMin = new Vector2(1f, 0.5f);
                rt.anchorMax = new Vector2(1f, 0.5f);
                rt.pivot = new Vector2(1f, 0.5f);
                rt.anchoredPosition = new Vector2(-40f, 0f);
                rt.sizeDelta = new Vector2(40f, 360f);
            }

            LayerColorController controller = root.GetComponent<LayerColorController>();
            if (controller == null)
                controller = Undo.AddComponent<LayerColorController>(root);

            Scrollbar hue = EnsureScrollbar(root.transform, "HueBar", 0);
            Scrollbar sat = EnsureScrollbar(root.transform, "SatBar", 1);
            Scrollbar val = EnsureScrollbar(root.transform, "ValBar", 2);

            SerializedObject so = new SerializedObject(controller);
            so.FindProperty("hueScrollbar").objectReferenceValue = hue;
            so.FindProperty("saturationScrollbar").objectReferenceValue = sat;
            so.FindProperty("valueScrollbar").objectReferenceValue = val;
            so.ApplyModifiedProperties();
            return controller;
        }

        static Scrollbar EnsureScrollbar(Transform parent, string name, int index)
        {
            Transform existing = parent.Find(name);
            if (existing != null)
                return existing.GetComponent<Scrollbar>();

            GameObject barGo = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Scrollbar));
            Undo.RegisterCreatedObjectUndo(barGo, "Create Scrollbar");
            barGo.transform.SetParent(parent, false);

            RectTransform rt = barGo.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 1f);
            float x = index * 14f;
            rt.offsetMin = new Vector2(x, 0f);
            rt.offsetMax = new Vector2(x + 12f - 40f, 0f);
            // 简化：竖条
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 0.5f);
            rt.anchoredPosition = new Vector2(index * 14f, 0f);
            rt.sizeDelta = new Vector2(12f, 0f);

            Image bg = barGo.GetComponent<Image>();
            bg.color = new Color(0.2f, 0.2f, 0.2f, 0.6f);

            GameObject sliding = new GameObject("Sliding Area", typeof(RectTransform));
            sliding.transform.SetParent(barGo.transform, false);
            RectTransform slidingRt = sliding.GetComponent<RectTransform>();
            slidingRt.anchorMin = Vector2.zero;
            slidingRt.anchorMax = Vector2.one;
            slidingRt.offsetMin = slidingRt.offsetMax = Vector2.zero;

            GameObject handle = new GameObject("Handle", typeof(RectTransform), typeof(Image));
            handle.transform.SetParent(sliding.transform, false);
            RectTransform handleRt = handle.GetComponent<RectTransform>();
            handleRt.anchorMin = Vector2.zero;
            handleRt.anchorMax = Vector2.one;
            handleRt.offsetMin = handleRt.offsetMax = Vector2.zero;
            handle.GetComponent<Image>().color = Color.white;

            Scrollbar bar = barGo.GetComponent<Scrollbar>();
            bar.handleRect = handleRt;
            bar.targetGraphic = handle.GetComponent<Image>();
            bar.direction = Scrollbar.Direction.BottomToTop;
            bar.value = 0.5f;
            return bar;
        }

        static Component EnsureActionButton(Transform canvas, string name, string label, System.Type componentType)
        {
            GameObject go = GameObject.Find(name);
            if (go == null)
            {
                go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
                Undo.RegisterCreatedObjectUndo(go, "Create " + name);
                go.transform.SetParent(canvas, false);

                RectTransform rt = go.GetComponent<RectTransform>();
                rt.anchorMin = rt.anchorMax = new Vector2(1f, 0f);
                rt.pivot = new Vector2(1f, 0f);
                rt.sizeDelta = new Vector2(120f, 120f);
                float x = name.Contains("Save") ? -20f : name.Contains("Clear") ? -160f : -300f;
                rt.anchoredPosition = new Vector2(x, 40f);

                Image img = go.GetComponent<Image>();
                img.color = Color.white;

                Sprite icon = null;
                if (name.Contains("Save"))
                    icon = LoadSprite("Assets/Art/Btn_Save.png");
                else if (name.Contains("Clear"))
                    icon = LoadSprite("Assets/Art/Btn_Clear.png");
                if (icon != null)
                    img.sprite = icon;

                GameObject textGo = new GameObject("Label", typeof(RectTransform), typeof(Text));
                textGo.transform.SetParent(go.transform, false);
                RectTransform textRt = textGo.GetComponent<RectTransform>();
                textRt.anchorMin = Vector2.zero;
                textRt.anchorMax = Vector2.one;
                textRt.offsetMin = textRt.offsetMax = Vector2.zero;
                Text text = textGo.GetComponent<Text>();
                text.text = label;
                text.alignment = TextAnchor.MiddleCenter;
                text.color = Color.black;
                text.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            }

            Component existing = go.GetComponent(componentType);
            if (existing == null)
                existing = Undo.AddComponent(go, componentType);
            return existing;
        }

        static Sprite LoadSprite(string path)
        {
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }
    }
}
