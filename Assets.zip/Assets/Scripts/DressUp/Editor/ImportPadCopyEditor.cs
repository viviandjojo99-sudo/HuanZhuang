using DressUp.Import;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace DressUp.Editor
{
    [InitializeOnLoad]
    static class ImportPadCopyBinder
    {
        static ImportPadCopyBinder()
        {
            EditorApplication.delayCall += Ensure;
        }

        static void Ensure()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
                return;

            InputPadMenu pad = UnityEngine.Object.FindAnyObjectByType<InputPadMenu>(FindObjectsInactive.Include);
            if (pad == null || pad.GetComponent<ImportPadCopy>() != null)
                return;

            Undo.AddComponent<ImportPadCopy>(pad.gameObject);
            EditorSceneManager.MarkSceneDirty(pad.gameObject.scene);
        }
    }

    [CustomEditor(typeof(ImportPadCopy))]
    public class ImportPadCopyEditor : UnityEditor.Editor
    {
        static readonly (string title, string property)[] Blocks =
        {
            ("选择导入方式", "modes"),
            ("自动导入", "autoImport"),
            ("手动导入", "manualImport"),
            ("分类导入", "pictureCategory"),
        };

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            EditorGUILayout.HelpBox(
                "每一段是导入面板的一种情况。改完点「显示到画面」，ChooseText 和 CautionText 会换成这段字，位置不变。运行后会按当前步骤使用这里保存的字。",
                MessageType.Info);

            for (int i = 0; i < Blocks.Length; i++)
            {
                (string title, string property) = Blocks[i];
                SerializedProperty block = serializedObject.FindProperty(property);
                if (block == null)
                    continue;

                EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
                EditorGUILayout.PropertyField(block.FindPropertyRelative("choose"), new GUIContent("ChooseText"));
                EditorGUILayout.PropertyField(block.FindPropertyRelative("caution"), new GUIContent("CautionText"));
                if (GUILayout.Button("显示到画面"))
                {
                    serializedObject.ApplyModifiedProperties();
                    ShowOnPad(
                        (ImportPadCopy)target,
                        block.FindPropertyRelative("choose").stringValue,
                        block.FindPropertyRelative("caution").stringValue);
                }

                EditorGUILayout.Space(10f);
            }

            serializedObject.ApplyModifiedProperties();
        }

        static void ShowOnPad(ImportPadCopy copy, string choose, string caution)
        {
            if (copy == null)
                return;

            TMP_Text chooseText = FindText(copy.transform, "ChooseText");
            TMP_Text cautionText = FindText(copy.transform, "CautionText");
            if (chooseText == null || cautionText == null)
            {
                EditorUtility.DisplayDialog("导入文案", "InputPad 下找不到 ChooseText 或 CautionText。", "OK");
                return;
            }

            Undo.RecordObject(chooseText, "显示 ChooseText");
            Undo.RecordObject(cautionText, "显示 CautionText");
            chooseText.text = choose ?? "";
            cautionText.text = caution ?? "";
            EditorUtility.SetDirty(chooseText);
            EditorUtility.SetDirty(cautionText);
        }

        static TMP_Text FindText(Transform root, string name)
        {
            Transform child = root.Find(name);
            return child != null ? child.GetComponent<TMP_Text>() : null;
        }
    }
}
