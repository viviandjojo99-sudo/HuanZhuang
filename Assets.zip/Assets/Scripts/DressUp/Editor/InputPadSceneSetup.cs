using DressUp.Data;
using DressUp.Import;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.EditorTools
{
    /// <summary>
    /// 整理场景里已经放好的 InputPad，不再自动新建。
    /// </summary>
    public static class InputPadSceneSetup
    {
        [InitializeOnLoadMethod]
        static void PlaceWhenEditorLoads()
        {
            EditorApplication.delayCall += () =>
            {
                RetryFill(0);
                AlignOpenSceneLabels();
            };
        }

        static void AlignOpenSceneLabels()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            for (int i = 0; i < EditorSceneManager.sceneCount; i++)
            {
                var scene = EditorSceneManager.GetSceneAt(i);
                if (!scene.isLoaded)
                    continue;
                bool changed = false;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    Transform pad = FindNamed(root.transform, "InputPad");
                    if (pad == null)
                        continue;
                    changed |= AlignPage(FindNamed(pad, "PageRoot"));
                    changed |= AlignPage(FindNamed(pad, "PageHair"));
                    changed |= AlignPage(FindNamed(pad, "PageOther"));
                }

                if (changed)
                    EditorSceneManager.MarkSceneDirty(scene);
            }
        }

        static bool AlignPage(Transform page)
        {
            if (page == null)
                return false;
            bool changed = false;
            TMP_Text[] texts = page.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                TMP_Text text = texts[i];
                if (text == null || text.gameObject.name != "Text (TMP)" || IsBackLabel(text))
                    continue;
                RectTransform rect = text.rectTransform;
                Vector2 position = rect.anchoredPosition;
                Vector2 size = rect.sizeDelta;
                bool move = Mathf.Abs(position.y - 3.75f) > 0.02f;
                bool resize = Mathf.Abs(size.y - (-10f)) > 0.05f;
                if (!move && !resize)
                    continue;
                Undo.RecordObject(rect, "统一分类文字位置");
                if (move)
                {
                    position.y = 3.75f;
                    rect.anchoredPosition = position;
                }

                if (resize)
                {
                    size.y = -10f;
                    rect.sizeDelta = size;
                }

                changed = true;
            }

            return changed;
        }

        static bool IsBackLabel(TMP_Text text)
        {
            if (text.text != null && text.text.Contains("返回"))
                return true;
            ImportCategoryButton mark = text.GetComponentInParent<ImportCategoryButton>();
            return mark != null && mark.category == InputPadMenu.BackCategory;
        }

        static void RetryFill(int attempt)
        {
            if (FillTagsIfNeeded())
                return;
            if (attempt >= 20)
                return;
            EditorApplication.delayCall += () => RetryFill(attempt + 1);
        }

        public static void FillTagsFromMenu()
        {
            if (FillTagsIfNeeded(force: true))
                EditorUtility.DisplayDialog("导入键盘", "已按 InputPad 的格子铺上衣柜 Tag。点头发进入二级。", "OK");
        }

        static bool FillTagsIfNeeded(bool force = false)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return false;

            Transform pad = null;
            for (int i = 0; i < EditorSceneManager.sceneCount; i++)
            {
                var scene = EditorSceneManager.GetSceneAt(i);
                if (!scene.isLoaded)
                    continue;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    Transform found = FindNamed(root.transform, "InputPad");
                    if (found != null)
                    {
                        pad = found;
                        break;
                    }
                }
                if (pad != null)
                    break;
            }

            if (pad == null)
                return false;
            if (!force && FindNamed(pad, "PageRoot") != null)
            {
                SaveOnce(pad.gameObject.scene);
                return true;
            }

            GameObject buttonPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(
                "Assets/Prefab/FenLeiButton.prefab");
            if (buttonPrefab == null)
            {
                Debug.LogWarning("[InputPad] 找不到 FenLeiButton。");
                return false;
            }

            GridLayoutGroup sourceGrid = pad.GetComponent<GridLayoutGroup>();
            RectOffset padding = sourceGrid != null
                ? new RectOffset(sourceGrid.padding.left, sourceGrid.padding.right, sourceGrid.padding.top, sourceGrid.padding.bottom)
                : new RectOffset(50, 50, 50, 50);
            Vector2 cell = sourceGrid != null ? sourceGrid.cellSize : new Vector2(120f, 120f);
            Vector2 spacing = sourceGrid != null ? sourceGrid.spacing : new Vector2(20f, 20f);
            TextAnchor alignment = sourceGrid != null ? sourceGrid.childAlignment : TextAnchor.UpperLeft;
            GridLayoutGroup.Corner corner = sourceGrid != null ? sourceGrid.startCorner : GridLayoutGroup.Corner.UpperLeft;
            GridLayoutGroup.Axis axis = sourceGrid != null ? sourceGrid.startAxis : GridLayoutGroup.Axis.Horizontal;
            GridLayoutGroup.Constraint constraint = sourceGrid != null ? sourceGrid.constraint : GridLayoutGroup.Constraint.Flexible;
            int constraintCount = sourceGrid != null ? sourceGrid.constraintCount : 2;

            for (int i = pad.childCount - 1; i >= 0; i--)
                Undo.DestroyObjectImmediate(pad.GetChild(i).gameObject);
            if (sourceGrid != null)
                Undo.DestroyObjectImmediate(sourceGrid);

            GameObject rootPage = CreatePage(pad, "PageRoot", padding, cell, spacing, alignment, corner, axis, constraint, constraintCount);
            GameObject hairPage = CreatePage(pad, "PageHair", padding, cell, spacing, alignment, corner, axis, constraint, constraintCount);
            GameObject otherPage = CreatePage(pad, "PageOther", padding, cell, spacing, alignment, corner, axis, constraint, constraintCount);

            // 分组页从 Catalog 生成，不再维护第二份写死列表。PageTag 手摆，不在此覆盖。
            ClothingCatalog catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(
                "Assets/ScriptableObjects/DressUp/Catalog_BodyPanel.asset");
            if (catalog?.tags == null || catalog.tags.Count == 0)
            {
                Debug.LogWarning("[InputPad] Catalog_BodyPanel 无 tags，无法铺分组页。");
                return false;
            }

            AddTag(buttonPrefab, hairPage.transform, InputPadMenu.BackCategory, "返回", IconPath("返回"));
            AddTag(buttonPrefab, otherPage.transform, InputPadMenu.BackCategory, "返回", IconPath("返回"));

            for (int i = 0; i < catalog.tags.Count; i++)
            {
                WardrobeTagDef tag = catalog.tags[i];
                if (tag == null || string.IsNullOrEmpty(tag.tagName))
                    continue;
                if (tag.tagName == "未分类")
                    continue;

                string icon = IconPath(tag.tagName);
                if (string.IsNullOrEmpty(tag.parentTag))
                {
                    AddTag(buttonPrefab, rootPage.transform, tag.tagName, tag.tagName, icon);
                    continue;
                }

                if (tag.parentTag == "头发")
                    AddTag(buttonPrefab, hairPage.transform, tag.tagName, tag.tagName, icon);
                else if (tag.parentTag == "其它饰品")
                    AddTag(buttonPrefab, otherPage.transform, tag.tagName, tag.tagName, icon);
            }

            // 导入特例：角（衣柜并兽耳）、纹身（衣柜并人模）
            AddTag(buttonPrefab, otherPage.transform, "角", "角", IconPath("角"));
            AddTag(buttonPrefab, rootPage.transform, "纹身", "纹身", IconPath("纹身"));

            hairPage.SetActive(false);
            otherPage.SetActive(false);

            InputPadMenu menu = pad.GetComponent<InputPadMenu>();
            if (menu == null)
                menu = Undo.AddComponent<InputPadMenu>(pad.gameObject);
            var so = new SerializedObject(menu);
            so.FindProperty("rootPage").objectReferenceValue = rootPage;
            SerializedProperty pages = so.FindProperty("subPages");
            pages.arraySize = 2;
            pages.GetArrayElementAtIndex(0).FindPropertyRelative("parentCategory").stringValue = "头发";
            pages.GetArrayElementAtIndex(0).FindPropertyRelative("page").objectReferenceValue = hairPage;
            pages.GetArrayElementAtIndex(1).FindPropertyRelative("parentCategory").stringValue = "其它饰品";
            pages.GetArrayElementAtIndex(1).FindPropertyRelative("page").objectReferenceValue = otherPage;
            so.ApplyModifiedPropertiesWithoutUndo();

            EditorSceneManager.MarkSceneDirty(pad.gameObject.scene);
            Selection.activeGameObject = pad.gameObject;
            SaveOnce(pad.gameObject.scene);
            Debug.Log("[InputPad] 已按你的格子铺上衣柜 Tag。点头发进入二级。");
            return true;
        }

        static void SaveOnce(UnityEngine.SceneManagement.Scene scene)
        {
            if (EditorPrefs.GetBool("DressUp.InputPadTagsWritten"))
                return;
            if (!scene.IsValid())
                return;
            EditorSceneManager.SaveScene(scene);
            EditorPrefs.SetBool("DressUp.InputPadTagsWritten", true);
        }

        static GameObject CreatePage(
            Transform pad,
            string name,
            RectOffset padding,
            Vector2 cell,
            Vector2 spacing,
            TextAnchor alignment,
            GridLayoutGroup.Corner corner,
            GridLayoutGroup.Axis axis,
            GridLayoutGroup.Constraint constraint,
            int constraintCount)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(GridLayoutGroup));
            Undo.RegisterCreatedObjectUndo(go, "铺导入 Tag");
            go.transform.SetParent(pad, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            rt.pivot = new Vector2(0.5f, 0.5f);

            GridLayoutGroup grid = go.GetComponent<GridLayoutGroup>();
            grid.padding = padding;
            grid.cellSize = cell;
            grid.spacing = spacing;
            grid.childAlignment = alignment;
            grid.startCorner = corner;
            grid.startAxis = axis;
            grid.constraint = constraint;
            grid.constraintCount = constraintCount;
            return go;
        }

        static void AddTag(GameObject prefab, Transform page, string category, string label, string iconPath)
        {
            var btn = (GameObject)PrefabUtility.InstantiatePrefab(prefab, page);
            Undo.RegisterCreatedObjectUndo(btn, "铺导入 Tag");
            btn.name = label;

            var mark = btn.GetComponent<ImportCategoryButton>();
            if (mark == null)
                mark = btn.AddComponent<ImportCategoryButton>();
            mark.category = category;

            TMP_Text caption = btn.GetComponentInChildren<TMP_Text>(true);
            if (caption != null)
            {
                caption.text = label;
                caption.raycastTarget = false;
                if (label.Length > 2)
                {
                    caption.enableAutoSizing = true;
                    caption.fontSizeMin = 16f;
                    caption.fontSizeMax = 28f;
                }
            }

            if (!string.IsNullOrEmpty(iconPath))
            {
                Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(iconPath);
                if (sprite != null)
                {
                    Transform icon = btn.transform.Find("Icon");
                    Image image = icon != null ? icon.GetComponent<Image>() : null;
                    if (image != null)
                        image.sprite = sprite;
                }
            }
        }

        /// <summary>按 Tag 名猜 maleta 图标；找不到则空（保留预制默认图）。</summary>
        static string IconPath(string tagName)
        {
            if (tagName == "返回")
                return "Assets/Art/maleta/Tag_Return.png";
            if (tagName == "角")
                return "Assets/Art/maleta/Tag_J.png";
            if (tagName == "纹身")
                return "Assets/Art/maleta/Tag_Body.png";

            string[] candidates =
            {
                "Assets/Art/maleta/Tag_" + tagName + ".png",
                HintIcon(tagName)
            };
            for (int i = 0; i < candidates.Length; i++)
            {
                if (string.IsNullOrEmpty(candidates[i]))
                    continue;
                if (AssetDatabase.LoadAssetAtPath<Sprite>(candidates[i]) != null)
                    return candidates[i];
            }

            return null;
        }

        static string HintIcon(string tagName)
        {
            switch (tagName)
            {
                case "头发": return "Assets/Art/maleta/Tag_Hair.png";
                case "呆毛": return "Assets/Art/maleta/Tag_HairDM.png";
                case "碎发": return "Assets/Art/maleta/Tag_HairSF.png";
                case "边发": return "Assets/Art/maleta/Tag_HairTF.png";
                case "刘海": return "Assets/Art/maleta/Tag_HairLH.png";
                case "侧发": return "Assets/Art/maleta/Tag_HairCF.png";
                case "后发": return "Assets/Art/maleta/Tag_HairHF.png";
                case "辫子": return "Assets/Art/maleta/Tag_HairBZ.png";
                case "高光": return "Assets/Art/maleta/Tag_GG.png";
                case "发饰": return "Assets/Art/maleta/Tag_HairDec.png";
                case "衣服": case "裤子": case "外套": return "Assets/Art/maleta/Tag_Top.png";
                case "鞋子": case "袜子": return "Assets/Art/maleta/Tag_Shoes.png";
                case "眼睛": case "嘴": return "Assets/Art/maleta/Tag_YJ.png";
                case "眉毛": return "Assets/Art/maleta/Tag_MM.png";
                case "人模": case "纹身": return "Assets/Art/maleta/Tag_Body.png";
                case "其它饰品": case "场景": return "Assets/Art/maleta/Tag_Dec.png";
                case "前饰": case "后饰": return "Assets/Art/maleta/Tag_Hat.png";
                case "发带": return "Assets/Art/maleta/Tag_Ds.png";
                case "面饰": return "Assets/Art/maleta/Tag_MS.png";
                case "衣饰": return "Assets/Art/maleta/Tag_YS.png";
                case "耳饰": return "Assets/Art/maleta/Tag_ED.png";
                case "尾巴": return "Assets/Art/maleta/Tag_WB.png";
                case "兽耳": return "Assets/Art/maleta/Tag_SE.png";
                case "背饰": return "Assets/Art/maleta/Tag_Back.png";
                default: return null;
            }
        }

        static Transform FindNamed(Transform root, string name)
        {
            if (root.name == name)
                return root;
            for (int i = 0; i < root.childCount; i++)
            {
                Transform found = FindNamed(root.GetChild(i), name);
                if (found != null)
                    return found;
            }
            return null;
        }
    }
}
