using UnityEditor;
using UnityEngine;

namespace DressUp.EditorTools
{
    /// <summary>密码锁 UI 由 PasscodePrompt 运行时生成；此菜单仅提示配置位置。</summary>
    public static class PasscodeSceneSetup
    {
        public static void Explain()
        {
            EditorUtility.DisplayDialog(
                "密码锁",
                "右上角 KEY → 数字键盘，用于切换角色模板。\n" +
                "兑换码表目前是空的。\n" +
                "网页导出：Tools → 换装 → 导出网页\n" +
                "配置：Assets/Resources/DressUp/PasscodeConfig",
                "OK");
        }
    }
}
