using System.Collections.Generic;
using System.IO;
using DressUp.Motion;
using UnityEditor;
using UnityEngine;

namespace DressUp.Editor
{
    /// <summary>把 Art/SY/HuanZhaung* 收成 Resources/DressUp/StarSparkle（倒序播放）。</summary>
    public static class StarSparkleClipBuilder
    {
        const string ArtFolder = "Assets/Art/SY";
        const string ClipPath = "Assets/Resources/DressUp/StarSparkle.asset";
        const float Fps = 15f;

        static bool building;

        [InitializeOnLoadMethod]
        static void Schedule()
        {
            EditorApplication.delayCall += BuildIfNeeded;
        }

        public static void BuildMenu() => Build(force: true);

        static void BuildIfNeeded()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                EditorApplication.delayCall += BuildIfNeeded;
                return;
            }

            Build(force: false);
        }

        public static void Build(bool force)
        {
            if (building)
                return;
            if (!Directory.Exists(ArtFolder.Replace("Assets/", Application.dataPath + "/")))
                return;

            building = true;
            try
            {
                if (!force && AssetDatabase.LoadAssetAtPath<FrameClip>(ClipPath) != null)
                {
                    // 已有资源也刷新帧，避免换图后还指旧的
                }

                EnsureResourcesFolder();

                string[] guids = AssetDatabase.FindAssets("HuanZhaung t:Texture2D", new[] { ArtFolder });
                var numbered = new List<(int num, Sprite sprite)>();
                for (int i = 0; i < guids.Length; i++)
                {
                    string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                    string name = Path.GetFileNameWithoutExtension(path);
                    if (!name.StartsWith("HuanZhaung", System.StringComparison.OrdinalIgnoreCase))
                        continue;

                    string digits = name.Substring("HuanZhaung".Length);
                    if (!int.TryParse(digits, out int num))
                        continue;

                    EnsureSpriteSingle(path);
                    Sprite sprite = LoadLargestSprite(path);
                    if (sprite != null)
                        numbered.Add((num, sprite));
                }

                if (numbered.Count == 0)
                {
                    Debug.LogWarning("[StarSparkle] Art/SY 下没有 HuanZhaung* 图。");
                    return;
                }

                numbered.Sort((a, b) => b.num.CompareTo(a.num));
                var frames = new Sprite[numbered.Count];
                for (int i = 0; i < numbered.Count; i++)
                    frames[i] = numbered[i].sprite;

                FrameClip clip = AssetDatabase.LoadAssetAtPath<FrameClip>(ClipPath);
                if (clip == null)
                {
                    clip = ScriptableObject.CreateInstance<FrameClip>();
                    AssetDatabase.CreateAsset(clip, ClipPath);
                }

                clip.AssignFrames(frames, Fps, false);
                EditorUtility.SetDirty(clip);
                AssetDatabase.SaveAssets();
                Debug.Log($"[StarSparkle] 已写入 {ClipPath}，共 {frames.Length} 帧（倒序）。");
            }
            finally
            {
                building = false;
            }
        }

        static void EnsureResourcesFolder()
        {
            if (!AssetDatabase.IsValidFolder("Assets/Resources"))
                AssetDatabase.CreateFolder("Assets", "Resources");
            if (!AssetDatabase.IsValidFolder("Assets/Resources/DressUp"))
                AssetDatabase.CreateFolder("Assets/Resources", "DressUp");
        }

        static void EnsureSpriteSingle(string path)
        {
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null)
                return;

            bool changed = false;
            if (importer.textureType != TextureImporterType.Sprite)
            {
                importer.textureType = TextureImporterType.Sprite;
                changed = true;
            }

            if (importer.spriteImportMode != SpriteImportMode.Single)
            {
                importer.spriteImportMode = SpriteImportMode.Single;
                changed = true;
            }

            if (importer.mipmapEnabled)
            {
                importer.mipmapEnabled = false;
                changed = true;
            }

            if (!importer.alphaIsTransparency)
            {
                importer.alphaIsTransparency = true;
                changed = true;
            }

            if (changed)
                importer.SaveAndReimport();
        }

        static Sprite LoadLargestSprite(string path)
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(path);
            Sprite best = null;
            float bestArea = -1f;
            for (int i = 0; i < assets.Length; i++)
            {
                Sprite sprite = assets[i] as Sprite;
                if (sprite == null)
                    continue;
                float area = sprite.rect.width * sprite.rect.height;
                if (area > bestArea)
                {
                    best = sprite;
                    bestArea = area;
                }
            }

            return best;
        }
    }
}
