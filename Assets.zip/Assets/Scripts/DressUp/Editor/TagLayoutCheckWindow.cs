using System;
using System.Collections.Generic;
using System.Text;
using DressUp.Data;
using DressUp.Import;
using DressUp.Wardrobe;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Editor
{
    /// <summary>
    /// Catalog 为唯一对照表；对照场景 Page* / Maleta，并列出仅剩的三个特例。
    /// 菜单：Tools/换装/检查 Tag 布局
    /// </summary>
    public class TagLayoutCheckWindow : EditorWindow
    {
        ClothingCatalog catalog;
        Vector2 scroll;
        string report = "";
        int tab;

        static readonly string[] PageNames = { "PageRoot", "PageHair", "PageOther", "PageTag" };

        [MenuItem("Tools/换装/检查 Tag 布局", false, 1)]
        public static void Open()
        {
            var win = GetWindow<TagLayoutCheckWindow>("Tag 布局检查");
            win.minSize = new Vector2(720, 480);
            win.Refresh();
        }

        void OnEnable()
        {
            if (catalog == null)
            {
                catalog = AssetDatabase.LoadAssetAtPath<ClothingCatalog>(
                    "Assets/ScriptableObjects/DressUp/Catalog_BodyPanel.asset");
            }
        }

        void OnGUI()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            if (GUILayout.Button("刷新", EditorStyles.toolbarButton, GUILayout.Width(60)))
                Refresh();
            catalog = (ClothingCatalog)EditorGUILayout.ObjectField(
                catalog, typeof(ClothingCatalog), false, GUILayout.Width(280));
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            tab = GUILayout.Toolbar(tab, new[] { "对照总表", "仅剩特例", "怎么改" });
            scroll = EditorGUILayout.BeginScrollView(scroll);
            if (tab == 0)
                DrawReport();
            else if (tab == 1)
                DrawSpecials();
            else
                DrawHowToEdit();
            EditorGUILayout.EndScrollView();
        }

        void DrawReport()
        {
            if (string.IsNullOrEmpty(report))
                EditorGUILayout.HelpBox("点上方「刷新」。打开 SampleScene 可对照场景。", MessageType.Info);
            else
                EditorGUILayout.TextArea(report, GUILayout.ExpandHeight(true));
        }

        void DrawSpecials()
        {
            EditorGUILayout.LabelField(
                "对照表只认 Catalog_BodyPanel。下面三条不进表或特殊挂靠，其余没有隐藏映射。",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(6);

            Section("1. 角");
            Bullet("PageTag / 分组导入可有「角」键；图鉴不单独建 Tag");
            Bullet("FindTag(\"角\") → 兽耳；LayerForTag / PrimaryLayer → J（与 SE 同在兽耳下）");

            Section("1b. 纹身");
            Bullet("PageRoot 可有「纹身」键；图鉴不单独建 Tag");
            Bullet("FindTag(\"纹身\") → 人模；LayerForTag / PrimaryLayer → WS（与 RM 同在人模下）");

            Section("2. 未分类");
            Bullet("导入落不进 Catalog 叶子时的桶；可在 Maleta / 图鉴出现");
            Bullet("不要求出现在 PageTag");

            Section("3. YJT");
            Bullet("不是衣柜 Tag；眼睛衣服的 tintCompanionLayer");
            Bullet("跟眼睛一起换装/改色，BodyPanel 上有 YJT 层");

            Section("UI 返回（不算 Tag）");
            Bullet("PageHair / PageOther / TagB·C 的 category=__back__");
        }

        void DrawHowToEdit()
        {
            EditorGUILayout.HelpBox(
                "改归属/名字：改 Catalog 资源 + 场景键，不要再维护第二份写死表。",
                MessageType.Info);
            EditorGUILayout.LabelField("1. 唯一对照表", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "   Catalog_BodyPanel.asset → Tools/换装/图鉴浏览器 → Tags（tagName / parentTag / layers）",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.LabelField("2. 分组导入键 PageRoot / Hair / Other", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "   物体名 = ImportCategoryButton.category；一级多头发/其它饰品，二级多返回",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.LabelField("3. PageTag = PSD 分组名 = ProcessBar 图标", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "   子物体名 = Tag；Icon 子图 = 进度条图标（约 28 个叶子）",
                EditorStyles.wordWrappedLabel);
            EditorGUILayout.LabelField("4. Maleta WardrobeTag.category", EditorStyles.boldLabel);
            EditorGUILayout.LabelField(
                "   应与图鉴 tagName 一致（头发/其它饰品进二级栏）",
                EditorStyles.wordWrappedLabel);
        }

        static void Section(string title)
        {
            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
        }

        static void Bullet(string line)
        {
            EditorGUILayout.LabelField("• " + line, EditorStyles.wordWrappedLabel);
        }

        void Refresh()
        {
            var sb = new StringBuilder(12288);
            sb.AppendLine("刷新时间: " + DateTime.Now.ToString("HH:mm:ss"));
            sb.AppendLine("图鉴(唯一对照表): " + (catalog != null ? AssetDatabase.GetAssetPath(catalog) : "(未指定)"));
            sb.AppendLine();

            var catalogMap = ReadCatalog(catalog);
            AppendCatalog(sb, catalogMap);
            sb.AppendLine();

            var scenePages = ReadScenePages();
            AppendScenePages(sb, scenePages);
            sb.AppendLine();

            var maleta = ReadMaletaTags();
            AppendMaleta(sb, maleta);
            sb.AppendLine();

            AppendCrossTable(sb, catalogMap, scenePages, maleta);
            sb.AppendLine();
            AppendDiffs(sb, catalogMap, scenePages, maleta);
            report = sb.ToString();
            Repaint();
        }

        static Dictionary<string, CatalogRow> ReadCatalog(ClothingCatalog cat)
        {
            var map = new Dictionary<string, CatalogRow>(StringComparer.Ordinal);
            if (cat?.tags == null)
                return map;
            for (int i = 0; i < cat.tags.Count; i++)
            {
                WardrobeTagDef t = cat.tags[i];
                if (t == null || string.IsNullOrEmpty(t.tagName))
                    continue;
                string layers = t.layers != null && t.layers.Count > 0
                    ? string.Join(",", t.layers)
                    : "(无层)";
                string parent = string.IsNullOrEmpty(t.parentTag) ? "(一级)" : t.parentTag;
                map[t.tagName] = new CatalogRow
                {
                    Name = t.tagName,
                    Parent = parent,
                    Layers = layers
                };
            }
            return map;
        }

        static void AppendCatalog(StringBuilder sb, Dictionary<string, CatalogRow> map)
        {
            sb.AppendLine("======== 图鉴 Catalog ========");
            if (map.Count == 0)
            {
                sb.AppendLine("(空)");
                return;
            }

            var roots = new List<CatalogRow>();
            var children = new Dictionary<string, List<CatalogRow>>(StringComparer.Ordinal);
            foreach (var kv in map)
            {
                CatalogRow row = kv.Value;
                if (row.Parent == "(一级)")
                    roots.Add(row);
                else
                {
                    if (!children.TryGetValue(row.Parent, out List<CatalogRow> list))
                    {
                        list = new List<CatalogRow>();
                        children[row.Parent] = list;
                    }
                    list.Add(row);
                }
            }

            roots.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
            foreach (CatalogRow root in roots)
            {
                sb.AppendLine($"【{root.Name}】 layers={root.Layers}");
                if (!children.TryGetValue(root.Name, out List<CatalogRow> kids))
                    continue;
                kids.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
                foreach (CatalogRow kid in kids)
                    sb.AppendLine($"  └ {kid.Name}  layers={kid.Layers}");
            }
        }

        static Dictionary<string, List<SceneKey>> ReadScenePages()
        {
            var result = new Dictionary<string, List<SceneKey>>(StringComparer.Ordinal);
            foreach (string page in PageNames)
                result[page] = new List<SceneKey>();

            InputPadMenu pad = UnityEngine.Object.FindAnyObjectByType<InputPadMenu>(FindObjectsInactive.Include);
            if (pad == null)
                return result;

            Transform root = pad.transform;
            foreach (string pageName in PageNames)
            {
                Transform page = root.Find(pageName);
                if (page == null)
                    continue;
                for (int i = 0; i < page.childCount; i++)
                {
                    Transform child = page.GetChild(i);
                    ImportCategoryButton mark = child.GetComponent<ImportCategoryButton>();
                    string category = mark != null ? mark.category : "(无 ImportCategoryButton)";
                    string icon = "(无)";
                    Transform iconTf = child.Find("Icon");
                    Image image = iconTf != null ? iconTf.GetComponent<Image>() : null;
                    if (image != null && image.sprite != null)
                        icon = image.sprite.name;
                    result[pageName].Add(new SceneKey
                    {
                        GoName = child.gameObject.name,
                        Category = category,
                        Icon = icon,
                        HasButton = child.GetComponent<Button>() != null,
                        Sibling = i
                    });
                }
            }

            return result;
        }

        static void AppendScenePages(StringBuilder sb, Dictionary<string, List<SceneKey>> pages)
        {
            sb.AppendLine("======== 场景 InputPad 四页 ========");
            InputPadMenu pad = UnityEngine.Object.FindAnyObjectByType<InputPadMenu>(FindObjectsInactive.Include);
            if (pad == null)
            {
                sb.AppendLine("未找到 InputPadMenu。打开 SampleScene 再刷新。");
                sb.AppendLine("活动场景: " + EditorSceneManager.GetActiveScene().path);
                return;
            }

            sb.AppendLine("Pad: " + GetPath(pad.transform));
            foreach (string pageName in PageNames)
            {
                List<SceneKey> keys = pages[pageName];
                sb.AppendLine($"--- {pageName} ({keys.Count}) ---");
                foreach (SceneKey key in keys)
                {
                    string flag = "";
                    if (key.GoName == "返回" && key.Category == InputPadMenu.BackCategory)
                    { }
                    else if (key.Category == "(无 ImportCategoryButton)")
                        flag += " !!缺组件";
                    else if (key.GoName != key.Category && key.Category != InputPadMenu.BackCategory)
                        flag += " !!名≠category";
                    if (!key.HasButton && key.GoName != "返回")
                        flag += " !!缺Button";
                    sb.AppendLine(
                        $"  [{key.Sibling:00}] GO={key.GoName}  category={key.Category}  icon={key.Icon}{flag}");
                }
            }
        }

        static List<MaletaKey> ReadMaletaTags()
        {
            var list = new List<MaletaKey>();
            WardrobeTag[] tags = UnityEngine.Object.FindObjectsByType<WardrobeTag>(
                FindObjectsInactive.Include, FindObjectsSortMode.None);
            for (int i = 0; i < tags.Length; i++)
            {
                WardrobeTag t = tags[i];
                if (t == null)
                    continue;
                list.Add(new MaletaKey
                {
                    GoName = t.gameObject.name,
                    Category = t.Category ?? "",
                    Path = GetPath(t.transform)
                });
            }

            list.Sort((a, b) => string.CompareOrdinal(a.Path, b.Path));
            return list;
        }

        static void AppendMaleta(StringBuilder sb, List<MaletaKey> maleta)
        {
            sb.AppendLine("======== Maleta WardrobeTag ========");
            if (maleta.Count == 0)
            {
                sb.AppendLine("(场景中未找到 WardrobeTag)");
                return;
            }

            for (int i = 0; i < maleta.Count; i++)
            {
                MaletaKey m = maleta[i];
                sb.AppendLine($"  GO={m.GoName}  category={m.Category}  path={m.Path}");
            }
        }

        static void AppendCrossTable(
            StringBuilder sb,
            Dictionary<string, CatalogRow> catalogMap,
            Dictionary<string, List<SceneKey>> pages,
            List<MaletaKey> maleta)
        {
            sb.AppendLine("======== 对照一行表 Catalog | layers | PageTag | 分组页 | Maleta ========");

            var pageTag = new HashSet<string>(StringComparer.Ordinal);
            foreach (SceneKey k in pages["PageTag"])
            {
                if (k.GoName != "返回")
                    pageTag.Add(k.GoName);
            }

            var groupPage = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (string page in new[] { "PageRoot", "PageHair", "PageOther" })
            {
                foreach (SceneKey k in pages[page])
                {
                    if (k.GoName == "返回" || k.Category == InputPadMenu.BackCategory)
                        continue;
                    string id = k.Category.StartsWith("(") ? k.GoName : k.Category;
                    groupPage[id] = page;
                    groupPage[k.GoName] = page;
                }
            }

            var maletaCats = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < maleta.Count; i++)
            {
                if (!string.IsNullOrEmpty(maleta[i].Category)
                    && maleta[i].Category != WardrobeTagNavigator.BackCategory)
                    maletaCats.Add(maleta[i].Category);
            }

            var names = new List<string>(catalogMap.Keys);
            names.Sort(StringComparer.Ordinal);
            foreach (string name in names)
            {
                CatalogRow row = catalogMap[name];
                string pt = pageTag.Contains(name) ? "Y" : "-";
                string gp = groupPage.TryGetValue(name, out string p) ? p : "-";
                string mt = maletaCats.Contains(name) ? "Y" : "-";
                if (name == "头发" || name == "其它饰品")
                    pt = "(一级)";
                if (name == "未分类")
                    pt = "(桶)";
                sb.AppendLine(
                    $"  {name,-8} layers={row.Layers,-12} parent={row.Parent,-8} PageTag={pt,-6} 分组={gp,-10} Maleta={mt}");
            }

            if (pageTag.Contains("角"))
            {
                string gp = groupPage.TryGetValue("角", out string p) ? p : "-";
                string mt = maletaCats.Contains("角") ? "Y" : "(并兽耳)";
                sb.AppendLine(
                    $"  {"角",-8} layers={"J",-12} parent={"(特例)",-8} PageTag={"Y",-6} 分组={gp,-10} Maleta={mt}");
            }

            if (groupPage.ContainsKey("纹身") || pageTag.Contains("纹身"))
            {
                string gp = groupPage.TryGetValue("纹身", out string p) ? p : "-";
                string mt = maletaCats.Contains("纹身") ? "Y" : "(并人模)";
                string pt = pageTag.Contains("纹身") ? "Y" : "-";
                sb.AppendLine(
                    $"  {"纹身",-8} layers={"WS",-12} parent={"(特例)",-8} PageTag={pt,-6} 分组={gp,-10} Maleta={mt}");
            }
        }

        static void AppendDiffs(
            StringBuilder sb,
            Dictionary<string, CatalogRow> catalogMap,
            Dictionary<string, List<SceneKey>> pages,
            List<MaletaKey> maleta)
        {
            sb.AppendLine("======== 对照问题 ========");
            int problems = 0;

            string ExpectedGroupPage(string tagName, string parent)
            {
                if (tagName == "头发" || tagName == "其它饰品" || parent == "(一级)")
                    return "PageRoot";
                if (parent == "头发")
                    return "PageHair";
                if (parent == "其它饰品")
                    return "PageOther";
                return "?";
            }

            var pageTagNames = new HashSet<string>(StringComparer.Ordinal);
            foreach (SceneKey key in pages["PageTag"])
            {
                if (key.GoName != "返回")
                    pageTagNames.Add(key.GoName);
            }

            var maletaCats = new HashSet<string>(StringComparer.Ordinal);
            for (int i = 0; i < maleta.Count; i++)
            {
                if (!string.IsNullOrEmpty(maleta[i].Category)
                    && maleta[i].Category != WardrobeTagNavigator.BackCategory
                    && maleta[i].Category != "返回")
                    maletaCats.Add(maleta[i].Category);
            }

            foreach (var kv in catalogMap)
            {
                CatalogRow row = kv.Value;
                if (row.Name == "未分类")
                    continue;

                bool isDrillRoot = row.Name == "头发" || row.Name == "其它饰品";
                bool isLeafChild = row.Parent == "头发" || row.Parent == "其它饰品";
                bool isRootLeaf = row.Parent == "(一级)" && !isDrillRoot;
                string expectPage = ExpectedGroupPage(row.Name, row.Parent);

                if (isLeafChild || isRootLeaf || isDrillRoot)
                {
                    string actualPage = FindPageOf(pages, row.Name);
                    if (string.IsNullOrEmpty(actualPage))
                    {
                        sb.AppendLine($"· 图鉴「{row.Name}」在分组页 {expectPage} 找不到");
                        problems++;
                    }
                    else if (actualPage != expectPage)
                    {
                        sb.AppendLine($"· 「{row.Name}」期望 {expectPage}，场景在 {actualPage}");
                        problems++;
                    }
                }

                bool wantOnPageTag = isRootLeaf || isLeafChild;
                if (isDrillRoot)
                    wantOnPageTag = false;
                if (wantOnPageTag && !pageTagNames.Contains(row.Name))
                {
                    sb.AppendLine($"· PageTag 缺「{row.Name}」");
                    problems++;
                }

                // Maleta：叶子与一级应有 WardrobeTag（未分类可选）
                if (!maletaCats.Contains(row.Name) && row.Name != "未分类")
                {
                    sb.AppendLine($"· Maleta 缺 WardrobeTag category「{row.Name}」");
                    problems++;
                }
            }

            foreach (string name in pageTagNames)
            {
                if (catalogMap.ContainsKey(name) || name == "角")
                    continue;
                sb.AppendLine($"· PageTag「{name}」不在图鉴");
                problems++;
            }

            foreach (var kv in pages)
            {
                foreach (SceneKey key in kv.Value)
                {
                    if (key.GoName == "返回" && key.Category == InputPadMenu.BackCategory)
                        continue;
                    if (key.Category == "(无 ImportCategoryButton)")
                    {
                        sb.AppendLine($"· {kv.Key}/{key.GoName} 缺 ImportCategoryButton（应在场景挂好）");
                        problems++;
                    }
                    else if (key.GoName != key.Category && key.Category != InputPadMenu.BackCategory)
                    {
                        sb.AppendLine($"· {kv.Key}: GO「{key.GoName}」≠ category「{key.Category}」");
                        problems++;
                    }
                }
            }

            if (problems == 0)
                sb.AppendLine("未发现对照问题（或场景未打开）。");
            else
                sb.AppendLine($"合计提示: {problems}");
        }

        static string FindPageOf(Dictionary<string, List<SceneKey>> pages, string name)
        {
            foreach (string page in new[] { "PageRoot", "PageHair", "PageOther" })
            {
                foreach (SceneKey key in pages[page])
                {
                    if (key.GoName == name || key.Category == name)
                        return page;
                }
            }
            return null;
        }

        static string GetPath(Transform t)
        {
            if (t == null)
                return "";
            var stack = new Stack<string>();
            while (t != null)
            {
                stack.Push(t.name);
                t = t.parent;
            }
            return string.Join("/", stack);
        }

        class CatalogRow
        {
            public string Name;
            public string Parent;
            public string Layers;
        }

        class SceneKey
        {
            public string GoName;
            public string Category;
            public string Icon;
            public bool HasButton;
            public int Sibling;
        }

        class MaletaKey
        {
            public string GoName;
            public string Category;
            public string Path;
        }
    }
}
