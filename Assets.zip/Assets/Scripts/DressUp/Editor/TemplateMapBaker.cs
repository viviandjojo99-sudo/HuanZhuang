using System;
using System.IO;
using System.Text;
using DressUp.Import;
using UnityEditor;
using UnityEngine;

namespace DressUp.Editor
{
    /// <summary>
    /// 从一份已经分好组的 PSD 写出模板图层表。只在菜单里手动执行。
    /// </summary>
    public static class TemplateMapBaker
    {
        const string Folder = "Assets/Resources/DressUp/Templates";

        [MenuItem("Tools/换装/生成模板图层表")]
        public static void BakeFromMenu()
        {
            string path = EditorUtility.OpenFilePanel("选择已分组的模板 PSD", "", "psd");
            if (string.IsNullOrEmpty(path))
                return;

            string name = Path.GetFileNameWithoutExtension(path);
            foreach (char bad in Path.GetInvalidFileNameChars())
                name = name.Replace(bad.ToString(), "");
            name = name.Trim();
            if (name.Length == 0)
            {
                EditorUtility.DisplayDialog("模板图层表", "文件名不能当作模板名。", "OK");
                return;
            }

            try
            {
                int rows = Bake(path, name);
                AssetDatabase.Refresh();
                EditorUtility.DisplayDialog("模板图层表", "已写入 " + Folder + "/" + name + ".txt，共 " + rows + " 层。", "OK");
            }
            catch (Exception exception)
            {
                EditorUtility.DisplayDialog("模板图层表", exception.Message, "OK");
            }
        }

        public static int Bake(string psdPath, string name)
        {
            string folder = Path.GetDirectoryName(Application.dataPath);
            string dir = Path.Combine(folder, Folder.Replace('/', Path.DirectorySeparatorChar));
            Directory.CreateDirectory(dir);
            using (PsdDocument doc = PsdDocument.Open(psdPath))
            {
                TemplateSheet sheet = TemplateSheet.Build(name, doc);
                if (sheet.Rows.Count == 0)
                    throw new InvalidDataException("这份 PSD 没有分好组的编号图层。");
                string text = sheet.ToText();
                File.WriteAllText(Path.Combine(dir, name + ".txt"), text, new UTF8Encoding(true));
                return sheet.Rows.Count;
            }
        }
    }
}
