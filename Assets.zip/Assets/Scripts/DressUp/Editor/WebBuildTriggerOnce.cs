using System.IO;
using UnityEditor;
using UnityEngine;

namespace DressUp.EditorTools
{
    /// <summary>存在 request-web-build.flag 时自动打包 WebGL。</summary>
    [InitializeOnLoad]
    static class WebBuildTriggerOnce
    {
        const string FlagPath = "Builds/request-web-build.flag";
        static bool started;

        static WebBuildTriggerOnce()
        {
            EditorApplication.delayCall += Run;
        }

        static void Run()
        {
            if (EditorApplication.isCompiling || EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorApplication.delayCall += Run;
                return;
            }

            string flag = Path.GetFullPath(FlagPath);
            if (!File.Exists(flag) || started)
                return;

            started = true;
            try { File.Delete(flag); } catch { /* ignore */ }

            Debug.Log("[WebBuild] 自动开始 WebGL 打包…");
            WebPlayerBuild.BuildSilent(false);
        }
    }
}
