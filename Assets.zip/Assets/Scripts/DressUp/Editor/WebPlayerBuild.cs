using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace DressUp.EditorTools
{
    public static class WebPlayerBuild
    {
        const string OutputDir = "Builds/Web";
        const string RequestFlag = "Builds/request-web-build.flag";

        [InitializeOnLoadMethod]
        static void WatchBuildRequest()
        {
            EditorApplication.update -= PollBuildRequest;
            EditorApplication.update += PollBuildRequest;
        }

        static double nextPollTime;

        static void PollBuildRequest()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
                return;

            double now = EditorApplication.timeSinceStartup;
            if (now < nextPollTime)
                return;
            nextPollTime = now + 1.5;

            string flagPath = Path.GetFullPath(RequestFlag);
            if (!File.Exists(flagPath))
                return;

            try
            {
                File.Delete(flagPath);
            }
            catch
            {
                return;
            }

            Debug.Log("[WebBuild] 检测到导出请求，开始 WebGL 打包…");
            BuildInternal(reveal: false);
        }

        [MenuItem("Tools/换装/导出网页", false, 1)]
        public static void BuildFromMenu()
        {
            BuildResult result = BuildInternal(reveal: true);
            if (result != BuildResult.Succeeded)
                EditorUtility.DisplayDialog("WebGL 导出失败", $"结果：{result}\n详见 Console。", "OK");
        }

        /// <summary>供外部触发：不弹失败对话框。</summary>
        public static BuildResult BuildSilent(bool reveal = true) => BuildInternal(reveal);

        /// <summary>命令行：-executeMethod DressUp.EditorTools.WebPlayerBuild.Build</summary>
        public static void Build()
        {
            BuildResult result = BuildInternal(reveal: false);
            EditorApplication.Exit(result == BuildResult.Succeeded ? 0 : 1);
        }

        static bool building;

        static BuildResult BuildInternal(bool reveal)
        {
            if (building)
            {
                Debug.Log("[WebBuild] 已经在打包，跳过重复请求。");
                return BuildResult.Unknown;
            }

            building = true;
            try
            {
                return BuildInternalNow(reveal);
            }
            finally
            {
                building = false;
            }
        }

        static BuildResult BuildInternalNow(bool reveal)
        {
            PlayerSettings.companyName = "JOJO";
            PlayerSettings.productName = "赛博衣柜";
            PlayerSettings.defaultWebScreenWidth = 1080;
            PlayerSettings.defaultWebScreenHeight = 1920;
            PlayerSettings.WebGL.decompressionFallback = true;
            PlayerSettings.WebGL.template = "PROJECT:Mobile";

            string[] scenes = EditorBuildSettings.scenes
                .Where(scene => scene.enabled)
                .Select(scene => scene.path)
                .ToArray();

            if (scenes.Length == 0)
            {
                Debug.LogError("[WebBuild] Build Settings 里没有启用的场景。");
                return BuildResult.Failed;
            }

            // 预览服务/资源管理器占用时 Directory.Delete 会失败；改输出到新目录再替换
            string stamp = System.DateTime.Now.ToString("yyyyMMdd-HHmmss");
            string tempOut = OutputDir + "-tmp-" + stamp;
            if (Directory.Exists(tempOut))
                Directory.Delete(tempOut, true);

            EditorUserBuildSettings.webGLBuildSubtarget = WebGLTextureSubtarget.DXT;
            EditorUserBuildSettings.overrideMaxTextureSize = 0;

            BuildResult result = BuildPlayer(scenes, tempOut);
            if (result == BuildResult.Succeeded && !BuildMobileData(scenes, tempOut))
                Debug.LogWarning("[WebBuild] 电脑版已打好。手机版资源没接上，手机打开会继续用电脑版贴图。");

            if (result == BuildResult.Succeeded)
            {
                try
                {
                    if (Directory.Exists(OutputDir))
                        Directory.Delete(OutputDir, true);
                    Directory.Move(tempOut, OutputDir);
                }
                catch (IOException)
                {
                    // 旧目录仍被占用：保留临时产物，避免白打
                    Debug.LogWarning($"[WebBuild] 无法覆盖 {OutputDir}（可能被预览服务占用）。本次输出在：{Path.GetFullPath(tempOut)}");
                    if (reveal)
                        EditorUtility.RevealInFinder(Path.Combine(Path.GetFullPath(tempOut), "index.html"));
                    return BuildResult.Succeeded;
                }
            }
            else if (Directory.Exists(tempOut))
            {
                try { Directory.Delete(tempOut, true); } catch { /* ignore */ }
            }

            if (result == BuildResult.Succeeded)
            {
                string full = Path.GetFullPath(OutputDir);
                WriteNetlifyHeaders(full);
                WriteNetlifyZip(full);
                Debug.Log($"[WebBuild] 成功 → {full}（打开 index.html）");
                if (reveal)
                    EditorUtility.RevealInFinder(Path.Combine(full, "index.html"));
            }
            else
            {
                Debug.LogError($"[WebBuild] 失败：{result}");
            }

            return result;
        }

        /// <summary>BuildReport 会在下一次 BuildPlayer 时被销毁，只能取结果值。</summary>
        static BuildResult BuildPlayer(string[] scenes, string outDir) =>
            BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = outDir,
                target = BuildTarget.WebGL,
                options = BuildOptions.None
            }).summary.result;

        /// <summary>成功接上手机资源返回 true。失败只记日志，不把已经打好的电脑版作废。</summary>
        static bool BuildMobileData(string[] scenes, string mainOut)
        {
            string mobileOut = mainOut + "-astc";
            if (Directory.Exists(mobileOut))
                Directory.Delete(mobileOut, true);

            WebGLTextureSubtarget previous = EditorUserBuildSettings.webGLBuildSubtarget;
            EditorUserBuildSettings.webGLBuildSubtarget = WebGLTextureSubtarget.ASTC;

            BuildResult result;
            var originals = ApplyMobileTextureSettings();
            try
            {
                result = BuildPlayer(scenes, mobileOut);
            }
            catch (Exception exception)
            {
                Debug.LogError("[WebBuild] 手机版 (ASTC) 打包中断：" + exception.Message);
                try { if (Directory.Exists(mobileOut)) Directory.Delete(mobileOut, true); } catch { /* ignore */ }
                return false;
            }
            finally
            {
                RestoreTextureSettings(originals);
                EditorUserBuildSettings.webGLBuildSubtarget = previous;
            }

            try
            {
                if (result != BuildResult.Succeeded)
                {
                    Debug.LogError($"[WebBuild] 手机版 (ASTC) 打包失败：{result}");
                    return false;
                }

                string src = FindDataFile(mobileOut);
                string desktop = FindDataFile(mainOut);
                if (src == null || desktop == null)
                {
                    Debug.LogError("[WebBuild] 手机版没有生成 data 文件，没法接到网页包里。");
                    return false;
                }

                string astcName = Path.GetFileName(desktop).Replace(".data.unityweb", "-astc.data.unityweb");
                string dst = Path.Combine(mainOut, "Build", astcName);
                File.Copy(src, dst, true);
                Debug.Log($"[WebBuild] 手机版资源 → {dst}");
                return true;
            }
            catch (Exception exception)
            {
                Debug.LogError("[WebBuild] 手机版资源没拷过去：" + exception.Message);
                return false;
            }
            finally
            {
                try { if (Directory.Exists(mobileOut)) Directory.Delete(mobileOut, true); } catch { /* ignore */ }
            }
        }

        static string FindDataFile(string buildRoot)
        {
            string dir = Path.Combine(buildRoot, "Build");
            if (!Directory.Exists(dir))
                return null;

            string[] files = Directory.GetFiles(dir, "*.data.unityweb");
            for (int i = 0; i < files.Length; i++)
            {
                if (Path.GetFileName(files[i]).IndexOf("-astc.data.unityweb", StringComparison.OrdinalIgnoreCase) >= 0)
                    continue;
                return files[i];
            }

            return null;
        }

        const int MobileMaxTextureSize = 1024;

        /// <summary>临时把 Assets 下所有贴图的 WebGL 设置改为 ASTC 6x6 + 1024 上限，返回原设置供还原（会写 .meta）。</summary>
        static List<KeyValuePair<string, TextureImporterPlatformSettings>> ApplyMobileTextureSettings()
        {
            var originals = new List<KeyValuePair<string, TextureImporterPlatformSettings>>();
            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (string guid in AssetDatabase.FindAssets("t:Texture2D", new[] { "Assets" }))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if (!(AssetImporter.GetAtPath(path) is TextureImporter importer))
                        continue;

                    var original = new TextureImporterPlatformSettings();
                    importer.GetPlatformTextureSettings("WebGL").CopyTo(original);
                    originals.Add(new KeyValuePair<string, TextureImporterPlatformSettings>(path, original));

                    TextureImporterPlatformSettings web = importer.GetPlatformTextureSettings("WebGL");
                    web.overridden = true;
                    web.format = TextureImporterFormat.ASTC_6x6;
                    web.maxTextureSize = Mathf.Min(MobileMaxTextureSize, importer.maxTextureSize);
                    importer.SetPlatformTextureSettings(web);
                    importer.SaveAndReimport();
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }

            return originals;
        }

        static void RestoreTextureSettings(List<KeyValuePair<string, TextureImporterPlatformSettings>> originals)
        {
            AssetDatabase.StartAssetEditing();
            try
            {
                foreach (var entry in originals)
                {
                    if (!(AssetImporter.GetAtPath(entry.Key) is TextureImporter importer))
                        continue;

                    importer.SetPlatformTextureSettings(entry.Value);
                    importer.SaveAndReimport();
                }
            }
            finally
            {
                AssetDatabase.StopAssetEditing();
            }
        }

        /// <summary>
        /// 没有 Content-Encoding: br 时手机要用 JS 解压整个包，内存不够会崩溃重载（表现为屏闪、反复刷新）。
        /// 输出目录每次都会被整体替换，所以必须在打包后重新写入。
        /// </summary>
        static void WriteNetlifyHeaders(string siteDir)
        {
            const string headers =
                "/Build/*.data.unityweb\n" +
                "  Content-Type: application/octet-stream\n" +
                "  Content-Encoding: br\n" +
                "\n" +
                "/Build/*.framework.js.unityweb\n" +
                "  Content-Type: application/javascript\n" +
                "  Content-Encoding: br\n" +
                "\n" +
                "/Build/*.wasm.unityweb\n" +
                "  Content-Type: application/wasm\n" +
                "  Content-Encoding: br\n" +
                "\n" +
                "/Build/*.loader.js\n" +
                "  Content-Type: application/javascript\n";

            File.WriteAllText(Path.Combine(siteDir, "_headers"), headers, new System.Text.UTF8Encoding(false));
        }

        /// <summary>上传端只接受根目录里的一个文件夹。网站文件放在这个文件夹里，路径用 '/' 分隔。</summary>
        static void WriteNetlifyZip(string siteDir)
        {
            string zipPath = Path.GetFullPath(OutputDir + "-netlify.zip");
            try
            {
                if (File.Exists(zipPath))
                    File.Delete(zipPath);

                using (var zipStream = File.Create(zipPath))
                using (var archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
                {
                    const string root = "Web/";
                    archive.CreateEntry(root);
                    foreach (string file in Directory.GetFiles(siteDir, "*", SearchOption.AllDirectories))
                    {
                        string entryName = root + file.Substring(siteDir.Length + 1).Replace('\\', '/');
                        ZipArchiveEntry entry = archive.CreateEntry(entryName, System.IO.Compression.CompressionLevel.Optimal);
                        using (var input = File.OpenRead(file))
                        using (var output = entry.Open())
                            input.CopyTo(output);
                    }
                }

                Debug.Log($"[WebBuild] Netlify 上传包 → {zipPath}");
            }
            catch (IOException e)
            {
                Debug.LogWarning($"[WebBuild] 生成 Netlify 压缩包失败：{e.Message}");
            }
        }
    }
}
