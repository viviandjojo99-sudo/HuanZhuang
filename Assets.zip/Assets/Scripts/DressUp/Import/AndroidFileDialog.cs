using UnityEngine;

namespace DressUp.Import
{
    public static class AndroidFileDialog
    {
        public static void Open(string gameObjectName, string methodName, bool allowPng)
        {
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (AndroidJavaClass player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                {
                    AndroidJavaObject activity = player.GetStatic<AndroidJavaObject>("currentActivity");
                    if (activity == null)
                    {
                        player.CallStatic("UnitySendMessage", gameObjectName, methodName, "error:打不开文件选择");
                        return;
                    }

                    activity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
                    {
                        try
                        {
                            using (AndroidJavaClass picker = new AndroidJavaClass("com.jojo.dressup.DressUpPickActivity"))
                                picker.CallStatic("open", activity, gameObjectName, methodName, allowPng);
                        }
                        catch (System.Exception exception)
                        {
                            using (AndroidJavaClass again = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                                again.CallStatic("UnitySendMessage", gameObjectName, methodName, "error:打不开文件选择");
                            Debug.LogError("[AndroidFileDialog] " + exception);
                        }
                    }));
                }
            }
            catch (System.Exception exception)
            {
                Debug.LogError("[AndroidFileDialog] " + exception);
            }
#else
            Debug.LogWarning("[AndroidFileDialog] 只在安卓播放器里打开文件。");
#endif
        }
    }
}
