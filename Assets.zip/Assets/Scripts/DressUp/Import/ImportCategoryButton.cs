using UnityEngine;

namespace DressUp.Import
{
    /// <summary>导入面板上的一个分类键。摆位置时改这个物体即可，分类名留在 category。</summary>
    public class ImportCategoryButton : MonoBehaviour
    {
        [Tooltip("衣柜 Tag 名，例如 呆毛、衣服、眼睛")]
        public string category;
    }
}
