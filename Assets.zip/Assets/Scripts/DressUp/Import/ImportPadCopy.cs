using System;
using UnityEngine;

namespace DressUp.Import
{
    /// <summary>
    /// 导入面板在不同步骤下，ChooseText 和 CautionText 各自显示的字。
    /// </summary>
    public class ImportPadCopy : MonoBehaviour
    {
        [Serializable]
        public class Situation
        {
            [TextArea(2, 4)] public string choose;
            [TextArea(2, 4)] public string caution;
        }

        public Situation modes = new Situation();
        public Situation autoImport = new Situation();
        public Situation manualImport = new Situation();
        public Situation pictureCategory = new Situation();
    }
}
