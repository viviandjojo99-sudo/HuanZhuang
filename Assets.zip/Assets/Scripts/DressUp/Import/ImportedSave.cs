using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Wardrobe;
using UnityEngine;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

namespace DressUp.Import
{
    /// <summary>
    /// 把导入的衣服写进本机浏览器存储。关掉页面再打开还能读回来。
    /// </summary>
    public static class ImportedSave
    {
        const string FolderName = "DressUpImports";
        const string ManifestName = "manifest.json";

        static bool loaded;
        static bool suppress;
        static bool imagesDirty;
        static bool outfitDirty;
        static bool flush;
        static bool pumping;
        static int epoch;
        static int fileSerial;
        static ImportManifest pendingOutfit;
        static readonly Dictionary<string, SavedItem> book = new Dictionary<string, SavedItem>();
        static readonly HashSet<string> stickyResident = new HashSet<string>();
        static HashSet<string> deletedIds;

        /// <summary>预热后保留在内存，LoadPage 换 Tag 时不卸，避免随机再解压。</summary>
        public static void MarkStickyResident(string itemId)
        {
            if (!string.IsNullOrEmpty(itemId))
                stickyResident.Add(itemId);
        }

        public static void ClearStickyResidents()
        {
            stickyResident.Clear();
        }

        public static void FlushSoon()
        {
            if (!loaded || suppress)
                return;
            if (!outfitDirty && !imagesDirty)
                return;
            flush = true;
            Kick();
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void LoadWhenSceneReady()
        {
            EnsureLoaded();
        }

        public static void EnsureLoaded()
        {
            if (loaded)
                return;
            loaded = true;
            RequestPersistent();
            try
            {
                string path = ManifestPath();
                if (!File.Exists(path))
                    return;

                ImportManifest manifest;
                try
                {
                    manifest = JsonUtility.FromJson<ImportManifest>(File.ReadAllText(path));
                }
                catch (Exception exception)
                {
                    Debug.LogWarning("[DressUp] 读本地导入失败：" + exception.Message);
                    return;
                }

                if (manifest?.items == null)
                    return;

                ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
                for (int i = 0; i < manifest.items.Count; i++)
                {
                    SavedItem stored = manifest.items[i];
                    if (stored == null || IsDeleted(stored.itemId))
                        continue;
                    ClothingItem item = RestoreItem(stored);
                    if (item != null)
                        wardrobe.AddOrReplace(item);
                }

                if (manifest.hasOutfit)
                    pendingOutfit = manifest;
                BumpFileSerial();
            }
            finally
            {
                SeedBuiltin();
            }
        }

        public static bool TryApplyOutfit(BodyAvatar avatar, ClothingCatalog catalog)
        {
            if (pendingOutfit == null || avatar == null)
                return false;

            ImportManifest manifest = pendingOutfit;
            pendingOutfit = null;
            suppress = true;
            try
            {
                avatar.ApplyOutfit(manifest.outfit, catalog);
            }
            finally
            {
                suppress = false;
            }

            return true;
        }

        public static void SetSuppress(bool value) => suppress = value;

        /// <summary>若传入的是 Tag 名，换成 Catalog 主图层代号；否则原样（已是 DM/YF 等）。</summary>
        public static string LayerNow(string layerName)
        {
            if (string.IsNullOrEmpty(layerName))
                return layerName;
            ActiveAvatarBinder binder = UnityEngine.Object.FindAnyObjectByType<ActiveAvatarBinder>();
            ClothingCatalog catalog = binder != null ? binder.ActiveCatalog : null;
            if (catalog == null)
                return layerName;
            string mapped = catalog.PrimaryLayerForTag(layerName);
            return string.IsNullOrEmpty(mapped) ? layerName : mapped;
        }

        public static bool IsDeleted(string itemId)
        {
            LoadDeleted();
            return !string.IsNullOrEmpty(itemId) && deletedIds.Contains(itemId);
        }

        public static void DeleteOne(ClothingItem item)
        {
            if (item == null || string.IsNullOrEmpty(item.itemId))
                return;

            EnsureLoaded();
            epoch++;
            imagesDirty = false;
            outfitDirty = false;
            RememberDeleted(item.itemId);
            book.Remove(item.itemId);
            ImportedWardrobe.Instance?.Remove(item.itemId);
            try
            {
                RewriteManifest();
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 删除部件失败：" + exception.Message);
            }
        }

        public static void NoteOutfitChanged()
        {
            if (!loaded || suppress)
                return;
            outfitDirty = true;
            Kick();
        }

        public static void Erase()
        {
            epoch++;
            suppress = true;
            imagesDirty = false;
            outfitDirty = false;
            flush = false;
            pendingOutfit = null;
            loaded = true;
            book.Clear();
            ClearStickyResidents();
            try
            {
                if (ImportedWardrobe.Instance != null)
                    ImportedWardrobe.Instance.ClearAll();
                DeleteFolder(FolderPath());
                DeleteFolder(Path.Combine(Application.persistentDataPath, "DressUpSaves"));
                SyncFiles();
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 清空衣柜失败：" + exception.Message);
            }
            finally
            {
                suppress = false;
                PlayerPrefs.SetInt(BuiltinHiddenKey, 1);
                PlayerPrefs.Save();
            }
        }

        static void DeleteFolder(string dir)
        {
            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir))
                return;
            Directory.Delete(dir, true);
        }

        public static void RequestFullWrite()
        {
            EnsureLoaded();
            imagesDirty = true;
            outfitDirty = true;
            Kick();
        }

        static void Kick()
        {
            if (pumping)
                return;
            pumping = true;
            ImportedWardrobe.Ensure().Run(Pump());
        }

        static IEnumerator Pump()
        {
            while (imagesDirty || outfitDirty)
            {
                float deadline = Time.unscaledTime + (imagesDirty ? 0.05f : 0.6f);
                while (Time.unscaledTime < deadline)
                {
                    if (imagesDirty || flush)
                        break;
                    yield return null;
                }

                flush = false;

                if (!imagesDirty && !outfitDirty)
                    break;

                bool withImages = imagesDirty;
                imagesDirty = false;
                outfitDirty = false;
                yield return WriteNow(withImages);
            }

            pumping = false;
        }

        static IEnumerator WriteNow(bool withImages)
        {
            int token = epoch;
            if (suppress)
                yield break;

            ImportedWardrobe wardrobe = ImportedWardrobe.Instance;
            if (wardrobe == null || wardrobe.ImportedCount == 0)
                yield break;

            string dir;
            try
            {
                dir = FolderPath();
                Directory.CreateDirectory(dir);
            }
            catch (Exception exception)
            {
                Fail(withImages, exception.Message);
                yield break;
            }

            if (!withImages)
            {
                WriteOutfitOnly(dir);
                yield break;
            }

            var manifest = new ImportManifest();
            var keep = new HashSet<string>();
            var buffer = new List<ClothingItem>();
            wardrobe.CopyItems(buffer);
            Exception error = null;
            for (int i = 0; i < buffer.Count; i++)
            {
                ClothingItem item = buffer[i];
                if (item == null || string.IsNullOrEmpty(item.itemId))
                    continue;

                try
                {
                    SavedItem saved;
                    if (book.TryGetValue(item.itemId, out SavedItem stored) && stored != null)
                    {
                        saved = stored;
                        saved.layerName = item.layerName;
                        saved.itemId = item.itemId;
                        saved.tintCompanionLayer = item.tintCompanionLayer;
                        saved.tintable = item.tintable;
                        saved.cr = item.presetColor.r;
                        saved.cg = item.presetColor.g;
                        saved.cb = item.presetColor.b;
                        saved.ca = item.presetColor.a;
                        KeepFile(saved.sprite, keep);
                        KeepFile(saved.outlineSprite, keep);
                        KeepFile(saved.companionSprite, keep);
                        KeepFiles(saved.extraFillSprites, keep);
                        KeepFiles(saved.extraOutlineSprites, keep);
                    }
                    else
                    {
                        saved = new SavedItem
                        {
                            layerName = item.layerName,
                            itemId = item.itemId,
                            tintCompanionLayer = item.tintCompanionLayer,
                            tintable = item.tintable,
                            cr = item.presetColor.r,
                            cg = item.presetColor.g,
                            cb = item.presetColor.b,
                            ca = item.presetColor.a
                        };
                        string stem = Safe(item.itemId);
                        saved.sprite = WriteSprite(item.sprite, dir, stem + "_f", keep);
                        saved.outlineSprite = WriteSprite(item.outlineSprite, dir, stem + "_o", keep);
                        saved.companionSprite = WriteSprite(item.companionSprite, dir, stem + "_c", keep);
                        saved.extraFillSprites = WriteSpriteList(item.extraFillSprites, dir, stem + "_ef", keep);
                        saved.extraOutlineSprites = WriteSpriteList(item.extraOutlineSprites, dir, stem + "_eo", keep);
                    }

                    if (!HasFill(saved))
                        continue;
                    manifest.items.Add(saved);
                }
                catch (Exception exception)
                {
                    error = exception;
                    break;
                }

                yield return null;
            }

            if (error != null)
            {
                Fail(true, error.Message);
                yield break;
            }

            if (token != epoch || suppress)
                yield break;

            manifest.hasOutfit = true;
            manifest.outfit = CaptureOutfit();
            try
            {
                File.WriteAllText(Path.Combine(dir, ManifestName), JsonUtility.ToJson(manifest));
                DeleteStale(dir, keep);
                SyncFiles();
            }
            catch (Exception exception)
            {
                Fail(true, exception.Message);
            }
        }

        static void WriteOutfitOnly(string dir)
        {
            string path = Path.Combine(dir, ManifestName);
            if (!File.Exists(path))
                return;

            try
            {
                ImportManifest manifest = JsonUtility.FromJson<ImportManifest>(File.ReadAllText(path));
                if (manifest == null)
                    return;
                manifest.hasOutfit = true;
                manifest.outfit = CaptureOutfit();
                File.WriteAllText(path, JsonUtility.ToJson(manifest));
                SyncFiles();
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 穿搭没能写入本地：" + exception.Message);
            }
        }

        static void Fail(bool notify, string reason)
        {
            Debug.LogWarning("[DressUp] 本地保存失败：" + reason);
            if (!notify)
                return;
            PlayerImportButton button = UnityEngine.Object.FindAnyObjectByType<PlayerImportButton>();
            button?.NotifyStorage("本地空间不够，关掉页面后要重新导入。");
        }

        static OutfitSnapshot CaptureOutfit()
        {
            ActiveAvatarBinder binder = UnityEngine.Object.FindAnyObjectByType<ActiveAvatarBinder>();
            BodyAvatar avatar = binder != null ? binder.ActiveAvatar : UnityEngine.Object.FindAnyObjectByType<BodyAvatar>();
            return avatar != null ? avatar.CaptureOutfit() : new OutfitSnapshot();
        }

        static SavedSprite WriteSprite(Sprite sprite, string dir, string stem, HashSet<string> keep)
        {
            if (sprite == null || sprite.texture == null)
                return null;

            byte[] png = null;
            if (!ImportedSpriteFrames.TryGetPng(sprite, out png))
            {
                Texture2D tex = sprite.texture as Texture2D;
                if (tex == null || !tex.isReadable)
                    return null;
                try
                {
                    png = ImageConversion.EncodeToPNG(tex);
                    ImportedSpriteFrames.KeepPng(sprite, png);
                    ImportedSpriteFrames.ReleaseCpuCopy(tex);
                }
                catch (Exception)
                {
                    return null;
                }
            }

            if (png == null || png.Length == 0)
                return null;

            string file = stem + ".png";
            File.WriteAllBytes(Path.Combine(dir, file), png);
            keep.Add(file);
            var saved = new SavedSprite { file = file };
            if (ImportedSpriteFrames.TryGet(sprite, out Vector2 anchored, out Vector2 size))
            {
                saved.framed = 1;
                saved.ax = anchored.x;
                saved.ay = anchored.y;
                saved.w = size.x;
                saved.h = size.y;
            }

            return saved;
        }

        static List<SavedSprite> WriteSpriteList(List<Sprite> sprites, string dir, string stem, HashSet<string> keep)
        {
            var list = new List<SavedSprite>();
            if (sprites == null)
                return list;
            for (int i = 0; i < sprites.Count; i++)
            {
                SavedSprite saved = WriteSprite(sprites[i], dir, stem + i.ToString(), keep);
                if (saved != null)
                    list.Add(saved);
            }

            return list;
        }

        static ClothingItem RestoreItem(SavedItem saved)
        {
            if (saved == null || string.IsNullOrEmpty(saved.itemId) || !HasFill(saved))
                return null;

            saved.layerName = LayerNow(saved.layerName);
            if (!string.IsNullOrEmpty(saved.tintCompanionLayer))
                saved.tintCompanionLayer = LayerNow(saved.tintCompanionLayer);
            book[saved.itemId] = saved;
            return new ClothingItem
            {
                layerName = saved.layerName,
                itemId = saved.itemId,
                tintCompanionLayer = saved.tintCompanionLayer,
                presetColor = new Color(saved.cr, saved.cg, saved.cb, saved.ca <= 0f ? 1f : saved.ca),
                tintable = saved.tintable
            };
        }

        static List<Sprite> ReadSpriteList(List<SavedSprite> saved, string dir, ImportedWardrobe wardrobe)
        {
            var list = new List<Sprite>();
            if (saved == null)
                return list;
            for (int i = 0; i < saved.Count; i++)
            {
                Sprite sprite = ReadSprite(saved[i], dir, wardrobe);
                if (sprite != null)
                    list.Add(sprite);
            }

            return list;
        }

        static Sprite ReadSprite(SavedSprite saved, string dir, ImportedWardrobe wardrobe)
        {
            if (saved == null || string.IsNullOrEmpty(saved.file))
                return null;

            byte[] bytes = ReadSpriteBytes(saved.file, dir);
            if (bytes == null)
                return null;

            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            if (!ImageConversion.LoadImage(texture, bytes))
            {
                UnityEngine.Object.Destroy(texture);
                return null;
            }

            texture.hideFlags = HideFlags.HideAndDontSave;
            wardrobe.Own(texture);
            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
            sprite.hideFlags = HideFlags.HideAndDontSave;
            if (saved.framed != 0)
                ImportedSpriteFrames.Remember(sprite, new Vector2(saved.ax, saved.ay), new Vector2(saved.w, saved.h));
            ImportedSpriteFrames.ReleaseCpuCopy(texture);
            return sprite;
        }

        public sealed class Picture
        {
            internal SavedSprite Data;
        }

        /// <summary>把这一张图写入文件并立刻丢掉贴图。衣柜点开对应 Tag 时再读回来。</summary>
        public static Picture Take(Sprite sprite)
        {
            if (sprite == null || sprite.texture == null)
                return null;

            byte[] png = null;
            if (!ImportedSpriteFrames.TryGetPng(sprite, out png))
            {
                if (!sprite.texture.isReadable)
                    return null;
                try
                {
                    png = ImageConversion.EncodeToPNG(sprite.texture);
                }
                catch (Exception)
                {
                    return null;
                }
            }

            if (png == null || png.Length == 0)
            {
                DropSprite(sprite);
                return null;
            }

            string file = "p" + fileSerial.ToString() + ".png";
            fileSerial++;
            try
            {
                Directory.CreateDirectory(FolderPath());
                File.WriteAllBytes(Path.Combine(FolderPath(), file), png);
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 图层没能写入本地：" + exception.Message);
                DropSprite(sprite);
                return null;
            }

            var saved = new SavedSprite { file = file };
            if (ImportedSpriteFrames.TryGet(sprite, out Vector2 anchored, out Vector2 size))
            {
                saved.framed = 1;
                saved.ax = anchored.x;
                saved.ay = anchored.y;
                saved.w = size.x;
                saved.h = size.y;
            }

            DropSprite(sprite);
            return new Picture { Data = saved };
        }

        public static void Attach(ClothingItem item, Picture fill, Picture outline, List<Picture> extraFills, List<Picture> extraOutlines, Picture companion)
        {
            if (item == null || string.IsNullOrEmpty(item.itemId))
                return;

            var saved = new SavedItem
            {
                layerName = item.layerName,
                itemId = item.itemId,
                tintCompanionLayer = item.tintCompanionLayer,
                tintable = item.tintable,
                cr = item.presetColor.r,
                cg = item.presetColor.g,
                cb = item.presetColor.b,
                ca = item.presetColor.a,
                sprite = fill != null ? fill.Data : null,
                outlineSprite = outline != null ? outline.Data : null,
                companionSprite = companion != null ? companion.Data : null,
                extraFillSprites = CopyPictures(extraFills),
                extraOutlineSprites = CopyPictures(extraOutlines)
            };
            book[item.itemId] = saved;
            item.sprite = null;
            item.outlineSprite = null;
            item.companionSprite = null;
            item.extraFillSprites = new List<Sprite>();
            item.extraOutlineSprites = new List<Sprite>();
        }

        public static void AttachCompanion(ClothingItem item, Picture picture)
        {
            if (item == null || picture == null || string.IsNullOrEmpty(item.itemId))
                return;
            if (!book.TryGetValue(item.itemId, out SavedItem saved) || saved == null)
                return;
            saved.companionSprite = picture.Data;
            saved.tintCompanionLayer = item.tintCompanionLayer;
            item.companionSprite = null;
        }

        public static bool HasPicture(ClothingItem item)
        {
            if (item == null)
                return false;
            // 快路径：多数内置件已有 sprite，避免每次 CollectFillSprites 分配列表。
            if (item.sprite != null)
                return true;
            if (item.extraFillSprites != null)
            {
                for (int i = 0; i < item.extraFillSprites.Count; i++)
                {
                    if (item.extraFillSprites[i] != null)
                        return true;
                }
            }

            return book.TryGetValue(item.itemId, out SavedItem saved) && HasFill(saved);
        }

        public static void EnsureResident(ClothingItem item)
        {
            if (item == null || string.IsNullOrEmpty(item.itemId))
                return;
            if (!book.TryGetValue(item.itemId, out SavedItem saved) || saved == null)
                return;

            ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
            string dir = FolderPath();
            if (item.sprite == null)
                item.sprite = ReadSprite(saved.sprite, dir, wardrobe);
            if (item.outlineSprite == null)
                item.outlineSprite = ReadSprite(saved.outlineSprite, dir, wardrobe);
            if (item.companionSprite == null)
                item.companionSprite = ReadSprite(saved.companionSprite, dir, wardrobe);
            if (item.extraFillSprites == null || item.extraFillSprites.Count == 0)
                item.extraFillSprites = ReadSpriteList(saved.extraFillSprites, dir, wardrobe);
            if (item.extraOutlineSprites == null || item.extraOutlineSprites.Count == 0)
                item.extraOutlineSprites = ReadSpriteList(saved.extraOutlineSprites, dir, wardrobe);
        }

        public static void LoadPage(ClothingCatalog catalog, string category, BodyAvatar avatar)
        {
            ImportedWardrobe wardrobe = ImportedWardrobe.Instance;
            if (wardrobe == null)
                return;

            var page = new HashSet<string>();
            if (catalog != null && !string.IsNullOrEmpty(category))
            {
                List<ClothingItem> shown = ImportedWardrobe.MergeTag(catalog, category);
                for (int i = 0; i < shown.Count; i++)
                {
                    ClothingItem item = shown[i];
                    if (item != null && !string.IsNullOrEmpty(item.itemId))
                        page.Add(item.itemId);
                }
            }

            var all = new List<ClothingItem>();
            wardrobe.CopyItems(all);
            for (int i = 0; i < all.Count; i++)
            {
                ClothingItem item = all[i];
                if (item == null || string.IsNullOrEmpty(item.itemId) || !book.ContainsKey(item.itemId))
                    continue;

                bool worn = avatar != null && avatar.IsWearing(item);
                if (worn)
                    EnsureResident(item);
                else if (page.Contains(item.itemId))
                    EnsurePreview(item);
                else
                    ReleaseResident(item);
            }
        }

        static void EnsurePreview(ClothingItem item)
        {
            if (item == null || item.sprite != null || string.IsNullOrEmpty(item.itemId))
                return;
            if (!book.TryGetValue(item.itemId, out SavedItem saved) || saved == null)
                return;

            item.sprite = ReadSprite(saved.sprite, FolderPath(), ImportedWardrobe.Ensure());
        }

        static void ReleaseResident(ClothingItem item)
        {
            if (item == null)
                return;
            if (item.CollectFillSprites().Count == 0)
                return;
            ImportedWardrobe wardrobe = ImportedWardrobe.Instance;
            wardrobe?.ReleaseSprites(item);
            item.sprite = null;
            item.outlineSprite = null;
            item.companionSprite = null;
            item.extraFillSprites = new List<Sprite>();
            item.extraOutlineSprites = new List<Sprite>();
        }

        static List<SavedSprite> CopyPictures(List<Picture> pictures)
        {
            var list = new List<SavedSprite>();
            if (pictures == null)
                return list;
            for (int i = 0; i < pictures.Count; i++)
            {
                if (pictures[i] != null && pictures[i].Data != null)
                    list.Add(pictures[i].Data);
            }

            return list;
        }

        static bool HasFill(SavedItem saved)
        {
            if (saved == null)
                return false;
            if (saved.sprite != null && !string.IsNullOrEmpty(saved.sprite.file))
                return true;
            if (saved.extraFillSprites == null)
                return false;
            for (int i = 0; i < saved.extraFillSprites.Count; i++)
            {
                SavedSprite sprite = saved.extraFillSprites[i];
                if (sprite != null && !string.IsNullOrEmpty(sprite.file))
                    return true;
            }

            return false;
        }

        static void KeepFile(SavedSprite sprite, HashSet<string> keep)
        {
            if (sprite != null && !string.IsNullOrEmpty(sprite.file))
                keep.Add(sprite.file);
        }

        static void KeepFiles(List<SavedSprite> sprites, HashSet<string> keep)
        {
            if (sprites == null)
                return;
            for (int i = 0; i < sprites.Count; i++)
                KeepFile(sprites[i], keep);
        }

        static void DropSprite(Sprite sprite)
        {
            if (sprite == null)
                return;
            Texture texture = sprite.texture;
            ImportedSpriteFrames.Forget(sprite);
            UnityEngine.Object.DestroyImmediate(sprite);
            if (texture != null)
                UnityEngine.Object.DestroyImmediate(texture);
        }

        static void BumpFileSerial()
        {
            foreach (KeyValuePair<string, SavedItem> pair in book)
                NoteSerial(pair.Value);
        }

        static void NoteSerial(SavedItem saved)
        {
            if (saved == null)
                return;
            NoteSerial(saved.sprite);
            NoteSerial(saved.outlineSprite);
            NoteSerial(saved.companionSprite);
            if (saved.extraFillSprites != null)
            {
                for (int i = 0; i < saved.extraFillSprites.Count; i++)
                    NoteSerial(saved.extraFillSprites[i]);
            }

            if (saved.extraOutlineSprites != null)
            {
                for (int i = 0; i < saved.extraOutlineSprites.Count; i++)
                    NoteSerial(saved.extraOutlineSprites[i]);
            }
        }

        static void NoteSerial(SavedSprite sprite)
        {
            if (sprite == null || string.IsNullOrEmpty(sprite.file))
                return;
            string name = Path.GetFileNameWithoutExtension(sprite.file);
            if (name.Length < 2 || name[0] != 'p')
                return;
            if (int.TryParse(name.Substring(1), out int number) && number >= fileSerial)
                fileSerial = number + 1;
        }

        const string BuiltinResource = "DressUp/Builtin3071/";
        const string BuiltinPrefix = "builtin-";
        const string BuiltinHiddenKey = "DressUp.Builtin3071Hidden";

        public static bool BuiltinHidden => PlayerPrefs.GetInt(BuiltinHiddenKey, 0) != 0;

        public static void RestoreBuiltin()
        {
            PlayerPrefs.DeleteKey(BuiltinHiddenKey);
            PlayerPrefs.Save();
            SeedBuiltin();
        }

        public static int CountPlayerItems()
        {
            EnsureLoaded();
            int count = 0;
            foreach (KeyValuePair<string, SavedItem> pair in book)
            {
                if (IsPlayerSaved(pair.Value))
                    count++;
            }

            return count;
        }

        /// <summary>把当前导入的模板（图片和清单）复制到另一个文件夹。不含内置衣柜。</summary>
        public static bool WritePlayerSnapshot(string folder, OutfitSnapshot outfit)
        {
            EnsureLoaded();
            Directory.CreateDirectory(folder);
            var manifest = new ImportManifest
            {
                hasOutfit = outfit != null,
                outfit = outfit ?? new OutfitSnapshot()
            };
            string live = FolderPath();
            foreach (KeyValuePair<string, SavedItem> pair in book)
            {
                SavedItem saved = pair.Value;
                if (!IsPlayerSaved(saved))
                    continue;
                CopySpriteFile(saved.sprite, live, folder);
                CopySpriteFile(saved.outlineSprite, live, folder);
                CopySpriteFile(saved.companionSprite, live, folder);
                CopySpriteList(saved.extraFillSprites, live, folder);
                CopySpriteList(saved.extraOutlineSprites, live, folder);
                manifest.items.Add(saved);
            }

            if (manifest.items.Count == 0)
            {
                DeleteFolder(folder);
                return false;
            }

            File.WriteAllText(Path.Combine(folder, ManifestName), JsonUtility.ToJson(manifest));
            return true;
        }

        public static OutfitSnapshot ReadSnapshotOutfit(string folder)
        {
            string path = Path.Combine(folder, ManifestName);
            if (!File.Exists(path))
                return null;

            ImportManifest manifest;
            try
            {
                manifest = JsonUtility.FromJson<ImportManifest>(File.ReadAllText(path));
            }
            catch (Exception)
            {
                return null;
            }

            if (manifest == null || !manifest.hasOutfit)
                return null;
            return manifest.outfit;
        }

        /// <summary>工作衣柜换成这一份已存模板。内置衣柜从衣柜里拿掉，文件还在历史格子里。</summary>
        public static void UseSnapshot(string folder)
        {
            epoch++;
            suppress = true;
            imagesDirty = false;
            outfitDirty = false;
            flush = false;
            pendingOutfit = null;
            ClearStickyResidents();
            try
            {
                if (ImportedWardrobe.Instance != null)
                    ImportedWardrobe.Instance.ClearAll();
                book.Clear();
                DeleteFolder(FolderPath());
                CopyFolderExcept(folder, FolderPath(), "preview.png");
                loaded = true;
                PlayerPrefs.SetInt(BuiltinHiddenKey, 1);
                PlayerPrefs.Save();

                string path = ManifestPath();
                if (!File.Exists(path))
                    return;

                ImportManifest manifest = JsonUtility.FromJson<ImportManifest>(File.ReadAllText(path));
                if (manifest?.items == null)
                    return;

                ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
                for (int i = 0; i < manifest.items.Count; i++)
                {
                    SavedItem stored = manifest.items[i];
                    if (stored == null)
                        continue;
                    ForgetDeleted(stored.itemId);
                    ClothingItem item = RestoreItem(stored);
                    if (item != null)
                        wardrobe.AddOrReplace(item);
                }
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 打开衣柜失败：" + exception.Message);
            }
            finally
            {
                suppress = false;
                WardrobeWarmup.Ensure().ScheduleIdleWarmup();
            }
        }

        /// <summary>工作衣柜换回内置的初始衣柜。</summary>
        public static void UseBuiltin()
        {
            epoch++;
            suppress = true;
            imagesDirty = false;
            outfitDirty = false;
            flush = false;
            pendingOutfit = null;
            try
            {
                if (ImportedWardrobe.Instance != null)
                    ImportedWardrobe.Instance.ClearAll();
                book.Clear();
                DeleteFolder(FolderPath());
                loaded = true;
                PlayerPrefs.DeleteKey(BuiltinHiddenKey);
                PlayerPrefs.Save();
                SeedBuiltin();
            }
            finally
            {
                suppress = false;
            }
        }

        static bool IsPlayerSaved(SavedItem saved)
        {
            if (!HasFill(saved))
                return false;
            if (saved.sprite != null && saved.sprite.file != null && saved.sprite.file.StartsWith(BuiltinPrefix, StringComparison.Ordinal))
                return false;
            return true;
        }

        static void CopySpriteFile(SavedSprite sprite, string fromDir, string toDir)
        {
            if (sprite == null || string.IsNullOrEmpty(sprite.file) || sprite.file.StartsWith(BuiltinPrefix, StringComparison.Ordinal))
                return;
            string source = Path.Combine(fromDir, sprite.file);
            if (!File.Exists(source))
                return;
            File.Copy(source, Path.Combine(toDir, sprite.file), true);
        }

        static void CopySpriteList(List<SavedSprite> sprites, string fromDir, string toDir)
        {
            if (sprites == null)
                return;
            for (int i = 0; i < sprites.Count; i++)
                CopySpriteFile(sprites[i], fromDir, toDir);
        }

        static void CopyFolderExcept(string fromDir, string toDir, string skipFile)
        {
            if (!Directory.Exists(fromDir))
                return;
            Directory.CreateDirectory(toDir);
            string[] files = Directory.GetFiles(fromDir);
            for (int i = 0; i < files.Length; i++)
            {
                string name = Path.GetFileName(files[i]);
                if (string.Equals(name, skipFile, StringComparison.OrdinalIgnoreCase))
                    continue;
                File.Copy(files[i], Path.Combine(toDir, name), true);
            }
        }

        static void SeedBuiltin()
        {
            if (BuiltinHidden)
                return;

            TextAsset asset = Resources.Load<TextAsset>(BuiltinResource + "manifest");
            if (asset == null || string.IsNullOrEmpty(asset.text))
                return;

            ImportManifest manifest;
            try
            {
                manifest = JsonUtility.FromJson<ImportManifest>(asset.text);
            }
            catch (Exception exception)
            {
                Debug.LogWarning("[DressUp] 读内置衣服失败：" + exception.Message);
                return;
            }

            if (manifest?.items == null)
                return;

            ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
            for (int i = 0; i < manifest.items.Count; i++)
            {
                SavedItem saved = manifest.items[i];
                if (saved == null || string.IsNullOrEmpty(saved.itemId) || book.ContainsKey(saved.itemId) || IsDeleted(saved.itemId))
                    continue;
                ClothingItem item = RestoreItem(saved);
                if (item != null)
                    wardrobe.AddOrReplace(item);
            }
        }

        static byte[] ReadSpriteBytes(string file, string dir)
        {
            if (string.IsNullOrEmpty(file))
                return null;

            if (file.StartsWith(BuiltinPrefix, StringComparison.Ordinal))
            {
                TextAsset packed = Resources.Load<TextAsset>(BuiltinResource + file);
                return packed != null && packed.bytes != null && packed.bytes.Length > 0 ? packed.bytes : null;
            }

            string path = Path.Combine(dir, file);
            if (!File.Exists(path))
                return null;
            try
            {
                return File.ReadAllBytes(path);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>把刚才导入进内存的衣服写成内置资源。文件名改成 builtin-，运行时从 Resources 读。</summary>
        public static int PublishBuiltin(string folder)
        {
            Directory.CreateDirectory(folder);
            var manifest = new ImportManifest();
            foreach (KeyValuePair<string, SavedItem> pair in book)
            {
                SavedItem saved = pair.Value;
                if (saved == null || !HasFill(saved))
                    continue;
                RetargetBuiltin(saved.sprite, folder);
                RetargetBuiltin(saved.outlineSprite, folder);
                RetargetBuiltin(saved.companionSprite, folder);
                RetargetBuiltinList(saved.extraFillSprites, folder);
                RetargetBuiltinList(saved.extraOutlineSprites, folder);
                manifest.items.Add(saved);
            }

            File.WriteAllText(Path.Combine(folder, "manifest.json"), JsonUtility.ToJson(manifest));
            return manifest.items.Count;
        }

        static void RetargetBuiltinList(List<SavedSprite> sprites, string folder)
        {
            if (sprites == null)
                return;
            for (int i = 0; i < sprites.Count; i++)
                RetargetBuiltin(sprites[i], folder);
        }

        static void RetargetBuiltin(SavedSprite sprite, string folder)
        {
            if (sprite == null || string.IsNullOrEmpty(sprite.file))
                return;
            if (sprite.file.StartsWith(BuiltinPrefix, StringComparison.Ordinal))
                return;

            string source = Path.Combine(FolderPath(), sprite.file);
            if (!File.Exists(source))
                return;

            string stem = Path.GetFileNameWithoutExtension(sprite.file);
            string key = BuiltinPrefix + stem;
            File.Copy(source, Path.Combine(folder, key + ".bytes"), true);
            sprite.file = key;
        }

        static void RewriteManifest()
        {
            string dir = FolderPath();
            Directory.CreateDirectory(dir);
            var manifest = new ImportManifest();
            var keep = new HashSet<string>();
            foreach (KeyValuePair<string, SavedItem> pair in book)
            {
                SavedItem saved = pair.Value;
                if (!HasFill(saved))
                    continue;
                manifest.items.Add(saved);
                KeepFile(saved.sprite, keep);
                KeepFile(saved.outlineSprite, keep);
                KeepFile(saved.companionSprite, keep);
                KeepFiles(saved.extraFillSprites, keep);
                KeepFiles(saved.extraOutlineSprites, keep);
            }

            manifest.hasOutfit = true;
            manifest.outfit = CaptureOutfit();
            File.WriteAllText(Path.Combine(dir, ManifestName), JsonUtility.ToJson(manifest));
            DeleteStale(dir, keep);
            SyncFiles();
        }

        static string DeletedPath() => Path.Combine(Application.persistentDataPath, "DressUpDeleted.txt");

        static void LoadDeleted()
        {
            if (deletedIds != null)
                return;

            deletedIds = new HashSet<string>(StringComparer.Ordinal);
            string path = DeletedPath();
            if (!File.Exists(path))
                return;

            string[] lines = File.ReadAllLines(path);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (line.Length > 0)
                    deletedIds.Add(line);
            }
        }

        static void RememberDeleted(string itemId)
        {
            LoadDeleted();
            if (string.IsNullOrEmpty(itemId) || !deletedIds.Add(itemId))
                return;

            WriteDeleted();
        }

        static void ForgetDeleted(string itemId)
        {
            LoadDeleted();
            if (string.IsNullOrEmpty(itemId) || !deletedIds.Remove(itemId))
                return;

            WriteDeleted();
        }

        static void WriteDeleted()
        {
            var lines = new string[deletedIds.Count];
            deletedIds.CopyTo(lines);
            File.WriteAllLines(DeletedPath(), lines);
        }

        static void DeleteStale(string dir, HashSet<string> keep)
        {
            string[] files = Directory.GetFiles(dir, "*.png");
            for (int i = 0; i < files.Length; i++)
            {
                string name = Path.GetFileName(files[i]);
                if (!keep.Contains(name))
                    File.Delete(files[i]);
            }
        }

        static string FolderPath() => Path.Combine(Application.persistentDataPath, FolderName);

        static string ManifestPath() => Path.Combine(FolderPath(), ManifestName);

        static string Safe(string value)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                value = value.Replace(c, '_');
            return value;
        }

        static void RequestPersistent()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            DressUpRequestStorage();
#endif
        }

        static void SyncFiles()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            DressUpSyncFiles();
#endif
        }

#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        static extern void DressUpSyncFiles();

        [DllImport("__Internal")]
        static extern void DressUpRequestStorage();
#endif

        [Serializable]
        class ImportManifest
        {
            public int version = 1;
            public bool hasOutfit;
            public OutfitSnapshot outfit = new OutfitSnapshot();
            public List<SavedItem> items = new List<SavedItem>();
        }

        [Serializable]
        class SavedItem
        {
            public string layerName;
            public string itemId;
            public string tintCompanionLayer;
            public bool tintable = true;
            public float cr = 1f;
            public float cg = 1f;
            public float cb = 1f;
            public float ca = 1f;
            public SavedSprite sprite;
            public SavedSprite outlineSprite;
            public SavedSprite companionSprite;
            public List<SavedSprite> extraFillSprites = new List<SavedSprite>();
            public List<SavedSprite> extraOutlineSprites = new List<SavedSprite>();
        }

        [Serializable]
        internal class SavedSprite
        {
            public string file;
            public int framed;
            public float ax;
            public float ay;
            public float w;
            public float h;
        }
    }
}
