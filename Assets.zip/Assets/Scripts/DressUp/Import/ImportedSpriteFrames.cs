using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Import
{
    /// <summary>
    /// 裁切后的导入图在 888 画布上的位置。没登记的图仍按整张画布居中。
    /// </summary>
    public static class ImportedSpriteFrames
    {
        struct Frame
        {
            public Vector2 Anchored;
            public Vector2 Size;
        }

        static readonly Dictionary<Sprite, Frame> frames = new Dictionary<Sprite, Frame>();

        public static void Remember(Sprite sprite, Vector2 anchored, Vector2 size)
        {
            if (sprite == null)
                return;
            frames[sprite] = new Frame { Anchored = anchored, Size = size };
        }

        public static bool TryGet(Sprite sprite, out Vector2 anchored, out Vector2 size)
        {
            anchored = Vector2.zero;
            size = Vector2.zero;
            if (sprite == null)
                return false;
            if (!frames.TryGetValue(sprite, out Frame frame))
                return false;
            anchored = frame.Anchored;
            size = frame.Size;
            return true;
        }

        public static void Forget(Sprite sprite)
        {
            if (sprite == null)
                return;
            frames.Remove(sprite);
            pngs.Remove(sprite);
        }

        static readonly Dictionary<Sprite, byte[]> pngs = new Dictionary<Sprite, byte[]>();

        public static void KeepPng(Sprite sprite, byte[] png)
        {
            if (sprite == null || png == null || png.Length == 0)
                return;
            pngs[sprite] = png;
        }

        public static bool TryGetPng(Sprite sprite, out byte[] png)
        {
            png = null;
            if (sprite == null)
                return false;
            return pngs.TryGetValue(sprite, out png) && png != null && png.Length > 0;
        }

        /// <summary>贴图上传后丢掉 CPU 那份。888 一层大约 3MB，不丢的话手机导着导着就会卡住。PNG 另存着供本地保存。</summary>
        public static void ReleaseCpuCopy(Texture2D texture)
        {
#if !UNITY_EDITOR
            if (texture == null || !texture.isReadable)
                return;
            texture.Apply(false, true);
#endif
        }
    }
}
