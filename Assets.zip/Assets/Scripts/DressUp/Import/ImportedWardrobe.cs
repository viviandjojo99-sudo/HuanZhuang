using System;
using System.Collections;
using System.Collections.Generic;
using DressUp.Data;
using UnityEngine;

namespace DressUp.Import
{
    /// <summary>
    /// 玩家导入的衣服。不写进 Catalog 资源，避免运行时改脏衣柜表。
    /// 同一 itemId 用导入的那件，新 id 追加。
    /// </summary>
    public class ImportedWardrobe : MonoBehaviour
    {
        public static ImportedWardrobe Instance { get; private set; }

        readonly Dictionary<string, ClothingItem> byId = new Dictionary<string, ClothingItem>();
        readonly List<ClothingItem> items = new List<ClothingItem>();
        readonly HashSet<Texture> owned = new HashSet<Texture>();

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }

            Instance = this;
        }

        void OnDestroy()
        {
            if (Instance == this)
                Instance = null;
        }

        public static ImportedWardrobe Ensure()
        {
            if (Instance != null)
                return Instance;
            var go = new GameObject(nameof(ImportedWardrobe));
            return go.AddComponent<ImportedWardrobe>();
        }

        public void Own(Texture texture)
        {
            if (texture != null)
                owned.Add(texture);
        }

        public void AddOrReplace(ClothingItem item)
        {
            if (item == null || string.IsNullOrEmpty(item.itemId))
                return;

            if (byId.TryGetValue(item.itemId, out ClothingItem previous))
            {
                int index = items.IndexOf(previous);
                if (index >= 0)
                    items[index] = item;
                else
                    items.Add(item);
                Release(previous);
            }
            else
            {
                items.Add(item);
            }

            byId[item.itemId] = item;
        }

        public int ImportedCount => items.Count;

        public void CopyItems(List<ClothingItem> buffer)
        {
            buffer.Clear();
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i] != null)
                    buffer.Add(items[i]);
            }
        }

        public void ClearAll()
        {
            for (int i = items.Count - 1; i >= 0; i--)
                Release(items[i]);
            items.Clear();
            byId.Clear();
        }

        public Coroutine Run(IEnumerator routine) => StartCoroutine(routine);

        void OnApplicationFocus(bool focus)
        {
            if (!focus)
                ImportedSave.FlushSoon();
        }

        public void Remove(string itemId)
        {
            if (string.IsNullOrEmpty(itemId) || !byId.TryGetValue(itemId, out ClothingItem item) || item == null)
                return;

            byId.Remove(itemId);
            items.Remove(item);
            Release(item);
        }

        public void RemoveWhereIdStartsWith(string prefix)
        {
            for (int i = items.Count - 1; i >= 0; i--)
            {
                ClothingItem item = items[i];
                if (item == null || item.itemId == null || !item.itemId.StartsWith(prefix))
                    continue;
                items.RemoveAt(i);
                byId.Remove(item.itemId);
                Release(item);
            }
        }

        public static ClothingItem Find(string layerName, string itemId)
        {
            if (Instance == null || string.IsNullOrEmpty(itemId))
                return null;
            if (!Instance.byId.TryGetValue(itemId, out ClothingItem item) || item == null)
                return null;
            if (!string.IsNullOrEmpty(layerName)
                && !string.Equals(item.layerName, layerName, System.StringComparison.OrdinalIgnoreCase))
                return null;
            return item;
        }

        public int NextSerial(string prefix)
        {
            int next = 1;
            if (string.IsNullOrEmpty(prefix))
                return next;

            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (item == null || item.itemId == null || !item.itemId.StartsWith(prefix))
                    continue;
                string tail = item.itemId.Substring(prefix.Length);
                if (int.TryParse(tail, out int number) && number >= next)
                    next = number + 1;
            }

            return next;
        }

        public static List<ClothingItem> MergeTag(ClothingCatalog catalog, string tagName)
        {
            var list = catalog != null ? catalog.GetItemsForTag(tagName) : new List<ClothingItem>();
            if (Instance == null || catalog == null)
            {
                DropDeleted(list);
                return list;
            }

            var seen = new HashSet<string>();
            for (int i = 0; i < list.Count; i++)
            {
                ClothingItem item = list[i];
                if (item == null || string.IsNullOrEmpty(item.itemId))
                    continue;
                seen.Add(item.itemId);
                if (Instance.byId.TryGetValue(item.itemId, out ClothingItem imported) && imported != null)
                    list[i] = imported;
            }

            for (int i = 0; i < Instance.items.Count; i++)
            {
                ClothingItem item = Instance.items[i];
                if (item == null || string.IsNullOrEmpty(item.itemId) || seen.Contains(item.itemId))
                    continue;
                if (!catalog.LayerBelongsToTag(item.layerName, tagName))
                    continue;
                list.Add(item);
                seen.Add(item.itemId);
            }

            DropDeleted(list);
            return list;
        }

        public static List<ClothingItem> MergeAll(ClothingCatalog catalog)
        {
            var list = new List<ClothingItem>();
            if (catalog?.items != null)
                list.AddRange(catalog.items);
            if (Instance == null)
            {
                DropDeleted(list);
                return list;
            }

            var seen = new HashSet<string>();
            for (int i = 0; i < list.Count; i++)
            {
                ClothingItem item = list[i];
                if (item == null || string.IsNullOrEmpty(item.itemId))
                    continue;
                seen.Add(item.itemId);
                if (Instance.byId.TryGetValue(item.itemId, out ClothingItem imported) && imported != null)
                    list[i] = imported;
            }

            for (int i = 0; i < Instance.items.Count; i++)
            {
                ClothingItem item = Instance.items[i];
                if (item == null || string.IsNullOrEmpty(item.itemId) || seen.Contains(item.itemId))
                    continue;
                list.Add(item);
            }

            DropDeleted(list);
            return list;
        }

        static void DropDeleted(List<ClothingItem> list)
        {
            for (int i = list.Count - 1; i >= 0; i--)
            {
                ClothingItem item = list[i];
                if (item == null || ImportedSave.IsDeleted(item.itemId))
                    list.RemoveAt(i);
            }
        }

        public void ReleaseSprites(ClothingItem item) => Release(item);

        void Release(ClothingItem item)
        {
            if (item == null)
                return;
            ReleaseSprite(item.sprite);
            ReleaseSprite(item.outlineSprite);
            ReleaseSprite(item.companionSprite);
            if (item.extraFillSprites != null)
            {
                for (int i = 0; i < item.extraFillSprites.Count; i++)
                    ReleaseSprite(item.extraFillSprites[i]);
            }

            if (item.extraOutlineSprites != null)
            {
                for (int i = 0; i < item.extraOutlineSprites.Count; i++)
                    ReleaseSprite(item.extraOutlineSprites[i]);
            }
        }

        void ReleaseSprite(Sprite sprite)
        {
            if (sprite == null)
                return;
            ImportedSpriteFrames.Forget(sprite);
            Texture texture = sprite.texture;
            Destroy(sprite);
            if (texture != null && owned.Remove(texture))
                Destroy(texture);
        }
    }
}
