using System;
using System.Collections.Generic;
using DressUp.Audio;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Import
{
    /// <summary>
    /// InputPad 的分类页。一级是衣柜根 Tag；点「头发」「其它饰品」切到二级，返回回到一级。
    /// </summary>
    public class InputPadMenu : MonoBehaviour
    {
        public const string BackCategory = "__back__";

        [Serializable]
        public class SubPage
        {
            public string parentCategory;
            public GameObject page;
        }

        [SerializeField] GameObject rootPage;
        [SerializeField] SubPage[] subPages;

        readonly HashSet<Button> wiredButtons = new HashSet<Button>();

        void Awake()
        {
            // PageTag 是全量可导入 TAG（与 PSD 分组名一致）。缺 Button / ImportCategoryButton 时按物体名补上。
            EnsurePageTagMarks(transform);
            WireCategoryButtons();

            ShowRoot();
            AlignPageLabels(rootPage);
            if (subPages != null)
            {
                for (int i = 0; i < subPages.Length; i++)
                    AlignPageLabels(subPages[i]?.page);
            }
        }

        /// <summary>给尚未接线的 ImportCategoryButton 挂上点击；可重复调用（Awake 顺序不定时用）。</summary>
        public void WireCategoryButtons()
        {
            ImportCategoryButton[] buttons = GetComponentsInChildren<ImportCategoryButton>(true);
            for (int i = 0; i < buttons.Length; i++)
            {
                ImportCategoryButton mark = buttons[i];
                if (mark == null)
                    continue;
                Button button = mark.GetComponent<Button>();
                if (button == null || wiredButtons.Contains(button))
                    continue;
                wiredButtons.Add(button);
                string category = mark.category;
                button.onClick.AddListener(() => OnCategory(category));
            }
        }

        /// <summary>给 PageTag 子键补 Button + ImportCategoryButton；category 与物体名对齐。</summary>
        public static void EnsurePageTagMarks(Transform padRoot)
        {
            if (padRoot == null)
                return;
            Transform page = padRoot.Find("PageTag");
            if (page == null)
                return;
            for (int i = 0; i < page.childCount; i++)
            {
                Transform child = page.GetChild(i);
                if (child == null)
                    continue;
                string name = child.gameObject.name;
                if (string.IsNullOrEmpty(name) || name == "返回")
                    continue;

                ImportCategoryButton mark = child.GetComponent<ImportCategoryButton>();
                if (mark == null)
                    mark = child.gameObject.AddComponent<ImportCategoryButton>();
                // PageTag 物体名即 PSD/衣柜 Tag 名，以物体名为准，避免复制键后 category 漂移。
                mark.category = name;

                Button button = child.GetComponent<Button>();
                if (button == null)
                {
                    Image image = child.GetComponent<Image>();
                    button = child.gameObject.AddComponent<Button>();
                    if (image != null)
                        button.targetGraphic = image;
                }
            }
        }

        public static void AlignPageLabels(GameObject page)
        {
            if (page == null)
                return;

            TMP_Text[] texts = page.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                TMP_Text text = texts[i];
                if (text == null || text.gameObject.name != "Text (TMP)" || IsBackLabel(text))
                    continue;

                RectTransform rect = text.rectTransform;
                Vector2 position = rect.anchoredPosition;
                if (Mathf.Abs(position.y - 3.75f) > 0.02f)
                {
                    position.y = 3.75f;
                    rect.anchoredPosition = position;
                }

                Vector2 size = rect.sizeDelta;
                if (Mathf.Abs(size.y - (-10f)) > 0.05f)
                {
                    size.y = -10f;
                    rect.sizeDelta = size;
                }
            }
        }

        static bool IsBackLabel(TMP_Text text)
        {
            if (text.text != null && text.text.Contains("返回"))
                return true;
            ImportCategoryButton mark = text.GetComponentInParent<ImportCategoryButton>();
            return mark != null && mark.category == BackCategory;
        }

        public void OnCategory(string category)
        {
            if (category == BackCategory)
            {
                DressUpAudio.Instance?.PlayBack();
                ShowRoot();
                return;
            }

            DressUpAudio.Instance?.PlayPopup();

            if (subPages != null)
            {
                for (int i = 0; i < subPages.Length; i++)
                {
                    SubPage page = subPages[i];
                    if (page == null || page.page == null)
                        continue;
                    if (page.parentCategory != category)
                        continue;

                    if (rootPage != null)
                        rootPage.SetActive(false);
                    for (int j = 0; j < subPages.Length; j++)
                    {
                        if (subPages[j]?.page != null)
                            subPages[j].page.SetActive(j == i);
                    }
                    return;
                }
            }

            LeafChosen?.Invoke(category);
        }

        public event Action<string> LeafChosen;

        public void ShowRoot()
        {
            if (rootPage != null)
                rootPage.SetActive(true);
            if (subPages == null)
                return;
            for (int i = 0; i < subPages.Length; i++)
            {
                if (subPages[i]?.page != null)
                    subPages[i].page.SetActive(false);
            }
        }
    }
}
