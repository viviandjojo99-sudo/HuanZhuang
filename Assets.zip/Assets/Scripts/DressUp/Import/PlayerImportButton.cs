using System;
using System.Collections;
using System.Collections.Generic;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Motion;
using DressUp.Data;
using DressUp.Wardrobe;
using TMPro;
using UnityEngine;
using DressUp.Actions;
using UnityEngine.Events;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif

namespace DressUp.Import
{
    /// <summary>
    /// ButtonInput 打开场景里的 InputPad：SelectPad 选导入方式，分类页选 TAG。确认后选手动 PSD 或图片 PNG。
    /// </summary>
    [RequireComponent(typeof(Button))]
    public class PlayerImportButton : MonoBehaviour
    {
        const string ServiceLine = "定制化服务：小红书 <color=#B97272>@赛博凌月娘</color>";
        const string PromptManualMode = "请选择导入模式";
        const string UnsortedTag = "未分类";
        const string SureDone = "已完成";

        enum Mode
        {
            None,
            Manual,
            Png
        }

        enum Step
        {
            Modes,
            Auto,
            ManualPair,
            Manual,
            PictureCategory
        }

        Button button;
        InputPadMenu pad;
        TMP_Text chooseText;
        TMP_Text choosePictureText;
        GameObject caution;
        GameObject selectPad;
        GameObject picturePage;
        Button cancelButton;
        Button sureButton;
        TMP_Text sureLabel;
        TMP_Text cancelLabel;
        TMP_Text cautionLabel;
        TMP_Text serviceLabel;
        string sureHome;
        bool finished;
        Coroutine shake;
        Image padImage;
        ImportPadCopy copy;
        Mode mode;
        Step step;
        string chosenTag;
        bool manualEachLayer;
        bool busy;
        Button[] selectButtons;
        string[] selectCaptions;
        SelectRole[] selectRoles;

        enum SelectRole
        {
            None,
            Auto,
            Manual,
            Category,
            Clear
        }

        ClothingCatalog catalog;
        BodyAvatar avatar;

        GameObject processBar;
        RectTransform processBarRect;
        RectTransform processFillRect;
        Image processFillImage;
        Image processIcon;
        RectTransform processIconRect;
        readonly Dictionary<string, Sprite> tagIcons = new Dictionary<string, Sprite>(StringComparer.Ordinal);
        string lastProgressTag;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void EnsureOnInput()
        {
            GameObject input = GameObject.Find("ButtonInput");
            if (input != null && input.GetComponent<PlayerImportButton>() == null)
                input.AddComponent<PlayerImportButton>();
        }

        void Awake()
        {
            PadHost.Wire();
            PadHost.Closed += ResetImport;
            button = GetComponent<Button>();
            button.onClick.AddListener(OpenChoice);
            pad = FindAnyObjectByType<InputPadMenu>(FindObjectsInactive.Include);
            if (pad != null)
            {
                pad.LeafChosen += OnLeaf;
                BindScene(pad.transform);
                pad.gameObject.SetActive(false);
            }
        }

        void OnDestroy()
        {
            PadHost.Closed -= ResetImport;
            if (button != null)
                button.onClick.RemoveListener(OpenChoice);
            if (pad != null)
                pad.LeafChosen -= OnLeaf;
        }

        void BindScene(Transform root)
        {
            chooseText = FindText(root, "ChooseText");
            choosePictureText = FindText(root, "ChooseText (1)");
            caution = FindChild(root, "CautionText");
            selectPad = FindChild(root, "SelectPad");
            picturePage = FindChild(root, "PagePicType");
            if (chooseText != null)
            {
                chooseText.enableWordWrapping = true;
                chooseText.overflowMode = TextOverflowModes.Overflow;
                chooseText.raycastTarget = false;
            }

            if (choosePictureText != null)
                choosePictureText.raycastTarget = false;
            if (caution != null)
            {
                cautionLabel = caution.GetComponent<TMP_Text>();
                if (cautionLabel != null)
                {
                    cautionLabel.raycastTarget = false;
                    cautionLabel.enableWordWrapping = true;
                    cautionLabel.richText = true;
                }
            }

            padImage = root.GetComponent<Image>();
            copy = root.GetComponent<ImportPadCopy>();
            // 先于图标表 / 按压缩，保证 PageTag 已有 Button + category（与 Awake 顺序无关）。
            InputPadMenu.EnsurePageTagMarks(root);
            if (pad != null)
                pad.WireCategoryButtons();
            BindProcessBar(root);
            BuildTagIconMap(root);
            EnsureServiceLine(root);
            BindSelectPad();
            BindConfirm(root);
            BindPress(root);
            SetActive(picturePage, false);
        }

        void BindPress(Transform root)
        {
            BindPressOn(FindChild(root, "PageRoot"), false, true);
            BindPressOn(FindChild(root, "PageHair"), false, true);
            BindPressOn(FindChild(root, "PageOther"), false, true);
            BindPressOn(FindChild(root, "PageTag"), false, true);
        }

        static void BindPressOn(GameObject page, bool gray, bool shiftContent)
        {
            if (page == null)
                return;
            GridLayoutGroup grid = page.GetComponent<GridLayoutGroup>();
            if (grid != null)
            {
                LayoutRebuilder.ForceRebuildLayoutImmediate(page.GetComponent<RectTransform>());
                Destroy(grid);
            }

            Button[] buttons = page.GetComponentsInChildren<Button>(true);
            var keys = new List<NumberKeyButton>();
            for (int i = 0; i < buttons.Length; i++)
            {
                if (IsPlainClick(buttons[i]))
                    continue;
                LockLabelSize(buttons[i]);
                NumberKeyButton key = buttons[i].GetComponent<NumberKeyButton>();
                if (key == null)
                    key = buttons[i].gameObject.AddComponent<NumberKeyButton>();
                key.SetStayDown(true);
                key.SetGray(gray);
                key.SetShiftContent(shiftContent);
                keys.Add(key);
            }

            NumberKeyButton[] group = keys.ToArray();
            for (int i = 0; i < group.Length; i++)
                group[i].SetGroup(group);
        }

        static void LockLabelSize(Button button)
        {
            TMP_Text[] labels = button.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < labels.Length; i++)
            {
                TMP_Text label = labels[i];
                if (label == null || !label.enableAutoSizing)
                    continue;
                float size = label.fontSize;
                label.enableAutoSizing = false;
                label.fontSize = size > 0f ? size : label.fontSizeMax;
            }
        }

        static bool IsPlainClick(Button button)
        {
            if (button == null)
                return true;
            if (button.name == "CloseButton")
                return true;
            ImportCategoryButton mark = button.GetComponent<ImportCategoryButton>();
            if (mark != null && mark.category == InputPadMenu.BackCategory)
                return true;
            return FirstLabel(button.transform).Contains("返回");
        }

        void ResetPresses()
        {
            if (pad == null)
                return;
            NumberKeyButton[] keys = pad.GetComponentsInChildren<NumberKeyButton>(true);
            for (int i = 0; i < keys.Length; i++)
                keys[i].Release();
        }

        void BindSelectPad()
        {
            if (selectPad == null)
                return;

            var buttons = new List<Button>();
            for (int i = 0; i < selectPad.transform.childCount; i++)
            {
                Button modeButton = selectPad.transform.GetChild(i).GetComponent<Button>();
                if (modeButton == null)
                    continue;
                if (RoleOf(modeButton.gameObject) == SelectRole.Clear)
                {
                    modeButton.gameObject.SetActive(false);
                    continue;
                }

                buttons.Add(modeButton);
            }

            Button auto = null;
            Button manual = null;
            Button png = null;
            selectRoles = new SelectRole[buttons.Count];
            for (int i = 0; i < buttons.Count; i++)
            {
                SelectRole role = RoleOf(buttons[i].gameObject);
                selectRoles[i] = role;
                if (role == SelectRole.Auto)
                    auto = buttons[i];
                else if (role == SelectRole.Category)
                    png = buttons[i];
                else if (role == SelectRole.Manual)
                    manual = buttons[i];
            }

            if (manual != null)
            {
                manual.transform.localRotation = Quaternion.identity;
                manual.transform.localScale = Vector3.one;
            }

            TMP_Text manualLabel = manual != null ? manual.GetComponentInChildren<TMP_Text>(true) : null;
            if (manualLabel != null && manualLabel.transform.parent != manual.transform)
            {
                manualLabel.transform.SetParent(manual.transform, false);
                RectTransform labelRect = manualLabel.rectTransform;
                labelRect.anchorMin = labelRect.anchorMax = new Vector2(0.5f, 0.5f);
                labelRect.pivot = new Vector2(0.5f, 0.5f);
                labelRect.anchoredPosition = Vector2.zero;
                manualLabel.raycastTarget = false;
            }

            if (auto != null)
                auto.onClick.RemoveListener(BeginAuto);
            if (manual != null)
                manual.onClick.RemoveListener(BeginManual);
            if (png != null)
                png.onClick.RemoveListener(BeginPng);

            selectButtons = buttons.ToArray();
            selectCaptions = new string[selectButtons.Length];
            for (int i = 0; i < selectButtons.Length; i++)
                selectCaptions[i] = FirstLabel(selectButtons[i].transform);
            WireSelectPad(false);
        }

        void WireSelectPad(bool pairing)
        {
            if (selectButtons == null)
                return;

            for (int i = 0; i < selectButtons.Length; i++)
            {
                Button button = selectButtons[i];
                if (button == null)
                    continue;
                button.onClick.RemoveListener(BeginAuto);
                button.onClick.RemoveListener(BeginManual);
                button.onClick.RemoveListener(BeginPng);
                button.onClick.RemoveListener(BeginManualDual);
                button.onClick.RemoveListener(BeginManualMerged);
                button.gameObject.SetActive(true);
                if (!pairing && selectCaptions != null && i < selectCaptions.Length)
                    SetCaption(button, selectCaptions[i]);
            }

            if (pairing)
            {
                for (int i = 2; i < selectButtons.Length; i++)
                {
                    if (selectButtons[i] != null)
                        selectButtons[i].gameObject.SetActive(false);
                }
                if (selectButtons.Length > 0 && selectButtons[0] != null)
                {
                    SetCaption(selectButtons[0], "线稿+色稿双图层");
                    selectButtons[0].onClick.AddListener(BeginManualDual);
                }

                if (selectButtons.Length > 1 && selectButtons[1] != null)
                {
                    SetCaption(selectButtons[1], "单图层");
                    selectButtons[1].onClick.AddListener(BeginManualMerged);
                }
            }
            else
            {
                for (int i = 0; i < selectButtons.Length; i++)
                {
                    Button button = selectButtons[i];
                    if (button == null)
                        continue;
                    SelectRole role = selectRoles != null && i < selectRoles.Length
                        ? selectRoles[i]
                        : SelectRole.None;
                    if (role == SelectRole.Auto)
                        button.onClick.AddListener(BeginAuto);
                    else if (role == SelectRole.Category)
                        button.onClick.AddListener(BeginPng);
                    else if (role == SelectRole.Manual)
                        button.onClick.AddListener(BeginManual);
                }
            }

            if (selectPad != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(selectPad.GetComponent<RectTransform>());
        }

        static SelectRole RoleOf(GameObject go)
        {
            if (go == null)
                return SelectRole.None;
            string label = FirstLabel(go.transform);
            if (label.Contains("个人私橱"))
                return SelectRole.Auto;
            if (label.Contains("一键导入"))
                return SelectRole.Manual;
            if (label.Contains("分类导入"))
                return SelectRole.Category;
            string name = go.name;
            if (name == "InputCategory")
                return SelectRole.Auto;
            if (name == "InputCategory (1)")
                return SelectRole.Manual;
            if (name == "InputCategory (2)")
                return SelectRole.Category;
            if (name == "InputCategory (3)")
                return SelectRole.Clear;
            return SelectRole.None;
        }

        static void SetCaption(Button button, string text)
        {
            if (button == null)
                return;
            TMP_Text[] labels = button.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < labels.Length; i++)
            {
                if (labels[i] == null)
                    continue;
                labels[i].text = text;
                labels[i].enableWordWrapping = true;
                labels[i].raycastTarget = false;
            }
        }

        void OpenChoice()
        {
            if (busy || pad == null)
                return;
            DressUpAudio.Instance?.PlayPopup();
            ResolveTargets();
            GameObject leftover = GameObject.Find("ImportDialog");
            if (leftover != null)
                Destroy(leftover);
            ShowModeSelect();
        }

        void BindConfirm(Transform root)
        {
            cancelButton = FindButton(root, "cancel");
            sureButton = FindButton(root, "sure");
            if (cancelButton != null)
            {
                cancelButton.onClick.AddListener(OnCancel);
                cancelLabel = cancelButton.GetComponentInChildren<TMP_Text>(true);
            }
            if (sureButton != null)
            {
                sureButton.onClick.AddListener(OnSure);
                sureLabel = sureButton.GetComponentInChildren<TMP_Text>(true);
                if (sureLabel != null)
                    sureHome = sureLabel.text;
            }

            SetConfirmVisible(false);
        }

        void ShowModeSelect()
        {
            mode = Mode.None;
            step = Step.Modes;
            chosenTag = null;
            manualEachLayer = false;
            finished = false;
            PresentPad();
            SetChoose(Choose(copy != null ? copy.modes : null));
            SetCaution(Caution(copy != null ? copy.modes : null));
            SetActive(choosePictureText, false);
            SetActive(caution, true);
            SetActive(selectPad, true);
            WireSelectPad(false);
            SetActive(picturePage, false);
            HideCategoryPages();
            ShowConfirm(true);
            SetServiceLine(false);
            ResetPresses();
            BringChromeForward();
        }

        void BeginAuto()
        {
            if (busy || pad == null)
                return;
            DressUpAudio.Instance?.PlayPopup();
            mode = Mode.None;
            step = Step.Auto;
            finished = false;
            SetActive(selectPad, false);
            SetActive(choosePictureText, false);
            SetActive(picturePage, false);
            HideCategoryPages();
            SetChoose(Choose(copy != null ? copy.autoImport : null));
            SetCaution(Caution(copy != null ? copy.autoImport : null));
            SetSure(sureHome);
            ShowConfirm(false);
            SetServiceLine(false);
        }

        void BeginManual()
        {
            if (busy || pad == null)
                return;
            DressUpAudio.Instance?.PlayPopup();
            mode = Mode.Manual;
            step = Step.ManualPair;
            chosenTag = null;
            manualEachLayer = false;
            finished = false;
            SetActive(choosePictureText, false);
            SetActive(picturePage, false);
            HideCategoryPages();
            SetChoose(PromptManualMode);
            SetSure(sureHome);
            SetActive(selectPad, true);
            WireSelectPad(true);
            ShowConfirm(false);
            SetServiceLine(false);
        }

        public void ClearWardrobe()
        {
            if (busy)
                return;
            DressUpAudio.Instance?.PlayClear();
            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            BodyAvatar target = binder != null ? binder.ActiveAvatar : avatar;
            target?.StripAllClothes();
            ImportedSave.Erase();
            if (binder != null)
                binder.ResetToDefaultOutfit();
            else if (avatar != null)
            {
                avatar.ClearChosenColors();
                avatar.ClearClothes();
            }

            RefreshWardrobe();
        }

        void RestoreInitialWardrobe()
        {
            if (busy)
                return;
            DressUpAudio.Instance?.PlayConfirm();
            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            ImportedSave.UseBuiltin();
            if (binder != null)
                binder.ResetToDefaultOutfit();
            else if (avatar != null)
            {
                avatar.ClearChosenColors();
                avatar.ClearClothes();
            }

            RefreshWardrobe();
        }

        void BeginManualDual()
        {
            EnterManualTags(false);
        }

        void BeginManualMerged()
        {
            EnterManualTags(true);
        }

        void EnterManualTags(bool eachLayer)
        {
            if (busy || pad == null)
                return;
            DressUpAudio.Instance?.PlayPopup();
            manualEachLayer = eachLayer;
            mode = Mode.Manual;
            step = Step.Manual;
            finished = false;
            WireSelectPad(false);
            SetActive(selectPad, false);
            SetActive(choosePictureText, false);
            SetActive(picturePage, false);
            SetSure(sureHome);
            HideCategoryPages();
            SetNamed("PageTag", true);
            SetChoose(Choose(copy != null ? copy.manualImport : null));
            SetCaution(Caution(copy != null ? copy.manualImport : null));
            ShowConfirm(false);
        }

        void BeginPng()
        {
            if (busy || pad == null)
                return;
            DressUpAudio.Instance?.PlayPopup();
            mode = Mode.Png;
            step = Step.PictureCategory;
            chosenTag = null;
            finished = false;
            SetActive(selectPad, false);
            SetActive(choosePictureText, false);
            SetActive(picturePage, false);
            SetSure(sureHome);
            pad.ShowRoot();
            SetChoose(Choose(copy != null ? copy.pictureCategory : null));
            SetCaution(Caution(copy != null ? copy.pictureCategory : null));
            ShowConfirm(false);
        }

        void OnLeaf(string category)
        {
            if (busy || finished || string.IsNullOrEmpty(category))
                return;

            if (step == Step.Manual || step == Step.PictureCategory)
                chosenTag = category;
        }

        void OnCancel()
        {
            if (busy)
                return;
            if (step == Step.Modes)
            {
                ClearWardrobe();
                return;
            }

            DressUpAudio.Instance?.PlayBack();
            ShowModeSelect();
        }

        void OnSure()
        {
            if (busy)
                return;
            if (step == Step.Modes)
            {
                RestoreInitialWardrobe();
                return;
            }

            DressUpAudio.Instance?.PlayConfirm();
            if (finished)
            {
                HidePad();
                return;
            }

#if UNITY_WEBGL && !UNITY_EDITOR
            if (step == Step.Auto || step == Step.Manual || step == Step.PictureCategory)
            {
                if (step == Step.PictureCategory && string.IsNullOrEmpty(chosenTag))
                {
                    ShakeChoose();
                    return;
                }

                DressUpClickFileInput();
                return;
            }
#elif UNITY_ANDROID && !UNITY_EDITOR
            if (step == Step.Auto || step == Step.Manual || step == Step.PictureCategory)
            {
                if (step == Step.PictureCategory && string.IsNullOrEmpty(chosenTag))
                {
                    ShakeChoose();
                    return;
                }

                AndroidFileDialog.Open(gameObject.name, nameof(OnAndroidFilePicked), step == Step.PictureCategory);
                return;
            }
#endif

            if (step == Step.ManualPair)
            {
                ShakeChoose();
                return;
            }

            if (step == Step.Auto)
            {
                string path = PickFile("选择 PSD", "psd");
                if (!string.IsNullOrEmpty(path))
                    StartCoroutine(ImportTemplate(path));
                return;
            }

            if (step == Step.Manual)
            {
                string path = PickFile("选择分组 PSD", "psd");
                if (!string.IsNullOrEmpty(path))
                    StartCoroutine(ImportGrouped(path, null, manualEachLayer));
                return;
            }

            if (step == Step.PictureCategory)
            {
                if (string.IsNullOrEmpty(chosenTag))
                {
                    ShakeChoose();
                    return;
                }

                ImportChosenCategory();
            }
        }

        void ImportChosenCategory()
        {
            string path = PickFile("选择 PSD 或 PNG", "psd,png");
            if (!string.IsNullOrEmpty(path))
                ImportFromPath(path);
        }

        void ImportFromPath(string path)
        {
            if (path.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
            {
                ImportMergedPicture(path);
                return;
            }

            if (path.EndsWith(".psd", StringComparison.OrdinalIgnoreCase))
            {
                StartCoroutine(ImportGrouped(path, chosenTag, true));
                return;
            }

            SetChoose("请选 psd 或 png。");
        }

        void ImportMergedPicture(string path)
        {
            SetChoose("正在导入...");
            Sprite sprite = LoadSprite(path);
            if (sprite == null)
            {
                SetChoose("这张图读不了。");
                return;
            }

            ResolveTargets();
            ImportedSave.EnsureLoaded();
            ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
            string layer = PsdClothingBuilder.LayerForTag(catalog, chosenTag, null);
            var item = new ClothingItem
            {
                layerName = layer,
                itemId = layer + "_p" + wardrobe.NextSerial(layer + "_p").ToString(),
                presetColor = Color.white,
                tintable = true
            };
            ImportedSave.Attach(item, ImportedSave.Take(sprite), null, null, null, null);
            wardrobe.AddOrReplace(item);
            RefreshWardrobe();
            ImportedSave.RequestFullWrite();
            MarkFinished();
        }

        void ShowConfirm(bool home)
        {
            SetCancel(home ? "清空衣柜" : "返回");
            SetSure(home ? "还原初始衣柜" : sureHome);
            SetConfirmVisible(true);
            BringChromeForward();
        }

        void SetConfirmVisible(bool visible)
        {
            if (cancelButton != null)
                cancelButton.gameObject.SetActive(visible);
            if (sureButton != null)
                sureButton.gameObject.SetActive(visible);
        }

        static Button FindButton(Transform root, string name)
        {
            Transform child = root.Find(name);
            return child != null ? child.GetComponent<Button>() : null;
        }

        Sprite LoadSprite(string path)
        {
            byte[] bytes;
            try
            {
                bytes = System.IO.File.ReadAllBytes(path);
            }
            catch (Exception exception)
            {
                SetChoose(exception.Message);
                return null;
            }
            finally
            {
                ReleaseWebFile(path);
            }

            var texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            if (!ImageConversion.LoadImage(texture, bytes))
            {
                Destroy(texture);
                return null;
            }

            texture.hideFlags = HideFlags.HideAndDontSave;
            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f, 0.5f), 100f);
            sprite.hideFlags = HideFlags.HideAndDontSave;
            float canvas = CanvasSize();
            if (texture.width < canvas - 1f || texture.height < canvas - 1f)
                ImportedSpriteFrames.Remember(sprite, Vector2.zero, new Vector2(texture.width, texture.height));
            return sprite;
        }

        IEnumerator ImportTemplate(string path)
        {
            busy = true;
            ImportedSave.EnsureLoaded();
            BeginProgressUi();
            SetChoose("正在导入...");
            yield return null;

            PsdDocument doc = null;
            Exception error = null;
            string fail = null;
            var items = new List<ClothingItem>();
            Dictionary<int, TemplatePart> map = null;
            TemplateSheet sheet = null;
            int matched = 0;
            try
            {
                doc = PsdDocument.Open(path);
                map = TemplateLayerMap.Load();
                matched = CountMatched(doc, map);
            }
            catch (Exception exception)
            {
                error = exception;
            }

            if (error == null && doc != null && matched < TemplateLayerMap.SuccessMatchedLayers)
            {
                var found = new List<TemplateSheet>();
                yield return TemplateLibrary.Match(doc, found);
                if (found.Count == 0)
                    fail = "数据不匹配，请手动导入";
                else
                    sheet = found[0];
            }

            if (error == null && fail == null && doc != null)
            {
                var progress = NewProgress();
                if (sheet != null)
                {
                    ResolveTargets();
                    List<PsdGarment> garments = sheet.Rebuild(doc);
                    yield return StartCoroutine(BuildGroupedItems(garments, doc, null, items, progress));
                }
                else
                {
                    ResolveTargets();
                    yield return StartCoroutine(PsdClothingBuilder.FromTemplate(
                        doc,
                        map,
                        ImportedWardrobe.Ensure(),
                        items,
                        progress,
                        LayerToTagName));
                }
            }

            doc?.Dispose();
            ReleaseWebFile(path);

            string message;
            if (error != null)
                message = "读不了这个 PSD：" + error.Message;
            else if (fail != null || items.Count == 0)
            {
                message = fail ?? "数据不匹配，请手动导入";
                fail = message;
            }
            else
            {
                ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
                ImportedSave.SetSuppress(true);
                try
                {
                    for (int i = 0; i < items.Count; i++)
                    {
                        wardrobe.AddOrReplace(items[i]);
                        if (items[i].layerName == "RM")
                            continue;
                        if (avatar != null && avatar.IsWearing(items[i]))
                            avatar.Equip(items[i]);
                    }
                }
                finally
                {
                    ImportedSave.SetSuppress(false);
                }

                RefreshWardrobe();
                ImportedSave.RequestFullWrite();
                message = $"模板已导入 {items.Count} 件。打开衣柜就能穿。";
            }

            EndProgressUi();
            busy = false;
            if (error != null || fail != null)
                SetChoose(message);
            else
                MarkFinished();
        }

        IEnumerator ImportGrouped(string path, string tagName, bool eachLayer)
        {
            busy = true;
            ImportedSave.EnsureLoaded();
            BeginProgressUi();
            if (!string.IsNullOrEmpty(tagName))
                SetProgressIcon(tagName);
            SetChoose("正在导入...");
            yield return null;

            PsdDocument doc = null;
            Exception error = null;
            string fail = null;
            var items = new List<ClothingItem>();
            List<PsdGarment> garments = null;
            try
            {
                doc = PsdDocument.Open(path);
                garments = PsdGroups.Collect(doc, eachLayer);
                if (garments.Count == 0)
                    fail = "这份 PSD 里没有图层。";
                else
                    ResolveTargets();
            }
            catch (Exception exception)
            {
                error = exception;
            }

            if (error == null && fail == null && doc != null)
                yield return StartCoroutine(BuildGroupedItems(garments, doc, tagName, items, NewProgress()));

            doc?.Dispose();
            ReleaseWebFile(path);

            string message;
            if (error != null)
                message = "读不了这个 PSD：" + error.Message;
            else if (fail != null)
                message = fail;
            else
            {
                ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
                ImportedSave.SetSuppress(true);
                try
                {
                    for (int i = 0; i < items.Count; i++)
                        wardrobe.AddOrReplace(items[i]);
                }
                finally
                {
                    ImportedSave.SetSuppress(false);
                }

                RefreshWardrobe();
                ImportedSave.RequestFullWrite();
                message = string.IsNullOrEmpty(tagName)
                    ? $"已导入 {items.Count} 件。"
                    : $"已把 {items.Count} 件放进{tagName}。";
                WardrobeWarmup.WarmAfterImport(items);
            }

            EndProgressUi();
            busy = false;
            if (error != null || fail != null)
                SetChoose(message);
            else if (PsdGroups.Mismatches.Count > 0)
            {
                MarkFinished();
                SetNamed("PageTag", false);
                SetCaution(MismatchText());
                if (caution != null)
                    caution.SetActive(true);
            }
            else
                MarkFinished();
        }

        static string MismatchText()
        {
            List<string> list = PsdGroups.Mismatches;
            int show = Math.Min(10, list.Count);
            var text = new System.Text.StringBuilder("以下图层未对齐：");
            for (int i = 0; i < show; i++)
            {
                if (i > 0)
                    text.Append('、');
                text.Append('【');
                text.Append(list[i]);
                text.Append('】');
            }

            if (list.Count > show)
                text.Append("...");
            return text.ToString();
        }

        static int CountMatched(PsdDocument doc, Dictionary<int, TemplatePart> map)
        {
            int matched = 0;
            for (int i = 0; i < doc.Layers.Count; i++)
            {
                if (TemplateLayerMap.TryParseLayerNumber(doc.Layers[i].Name, out int number) && map.ContainsKey(number))
                    matched++;
            }

            return matched;
        }

        void RefreshWardrobe()
        {
            WardrobeController wardrobe = FindAnyObjectByType<WardrobeController>();
            if (wardrobe == null)
                return;
            wardrobe.RefreshTagButtons();
            wardrobe.RebuildPlots();
            wardrobe.RefreshTagButtons();
        }

        void ResolveTargets()
        {
            if (avatar == null)
            {
                avatar = FindAnyObjectByType<ActiveAvatarBinder>()?.ActiveAvatar
                         ?? FindAnyObjectByType<BodyAvatar>();
            }

            if (catalog == null)
            {
                WardrobeController wardrobe = FindAnyObjectByType<WardrobeController>();
                catalog = wardrobe != null ? wardrobe.Catalog : null;
            }
        }

        float CanvasSize()
        {
            ResolveTargets();
            if (avatar != null)
            {
                var panel = avatar.transform.parent as RectTransform;
                if (panel != null)
                {
                    float size = Mathf.Max(panel.rect.width, panel.rect.height);
                    if (size > 1f)
                        return size;
                }
            }

            return 888f;
        }

        void HideCategoryPages()
        {
            SetNamed("PageRoot", false);
            SetNamed("PageHair", false);
            SetNamed("PageOther", false);
            SetNamed("PageTag", false);
        }

        void BindProcessBar(Transform root)
        {
            processBar = FindChild(root, "ProcessBar");
            if (processBar == null)
                return;

            processBarRect = processBar.transform as RectTransform;
            // 只裁切填充条，不要给整条 ProcessBar 挂 RectMask2D，否则会把 Icon 裁没。
            Transform fill = processBar.transform.Find("ProcessBar (1)");
            processFillRect = fill != null ? fill as RectTransform : null;
            processFillImage = fill != null ? fill.GetComponent<Image>() : null;
            if (processFillImage != null)
            {
                processFillImage.type = Image.Type.Filled;
                processFillImage.fillMethod = Image.FillMethod.Horizontal;
                processFillImage.fillOrigin = (int)Image.OriginHorizontal.Left;
                processFillImage.fillAmount = 0f;
            }

            Transform icon = processBar.transform.Find("Icon");
            processIcon = icon != null ? icon.GetComponent<Image>() : null;
            processIconRect = icon as RectTransform;
            processBar.SetActive(false);
            SetProgress(0f);
        }

        void BuildTagIconMap(Transform root)
        {
            // ProcessBar Icon 只跟 PageTag 一一对应，不扫分组页 PageRoot/Hair/Other。
            tagIcons.Clear();
            CollectTagIcons(FindChild(root, "PageTag"));
        }

        void CollectTagIcons(GameObject page)
        {
            if (page == null)
                return;
            ImportCategoryButton[] buttons = page.GetComponentsInChildren<ImportCategoryButton>(true);
            for (int i = 0; i < buttons.Length; i++)
            {
                ImportCategoryButton button = buttons[i];
                if (button == null || string.IsNullOrEmpty(button.category))
                    continue;
                if (button.category == InputPadMenu.BackCategory || button.category == "返回")
                    continue;
                Sprite sprite = ReadIconSprite(button.transform);
                if (sprite != null)
                    tagIcons[button.category] = sprite;
            }

            // PageTag 若尚未挂 ImportCategoryButton，仍按物体名 + Icon 补进表。
            for (int i = 0; i < page.transform.childCount; i++)
            {
                Transform child = page.transform.GetChild(i);
                if (child == null)
                    continue;
                string name = child.gameObject.name;
                if (string.IsNullOrEmpty(name) || name == "返回" || tagIcons.ContainsKey(name))
                    continue;
                Sprite sprite = ReadIconSprite(child);
                if (sprite != null)
                    tagIcons[name] = sprite;
            }
        }

        static Sprite ReadIconSprite(Transform key)
        {
            if (key == null)
                return null;
            Transform icon = key.Find("Icon");
            Image image = icon != null ? icon.GetComponent<Image>() : null;
            return image != null ? image.sprite : null;
        }

        void BeginProgressUi()
        {
            HideCategoryPages();
            SetActive(selectPad, false);
            SetActive(picturePage, false);
            SetActive(choosePictureText, false);
            lastProgressTag = null;
            if (processBar != null)
            {
                processBar.SetActive(true);
                processBar.transform.SetAsLastSibling();
            }

            SetProgress(0f);
            if (processIcon != null)
                processIcon.enabled = false;
            BringChromeForward();
            if (processBar != null)
                processBar.transform.SetAsLastSibling();
        }

        void EndProgressUi()
        {
            if (processBar != null)
                processBar.SetActive(false);
            SetProgress(0f);
            lastProgressTag = null;
        }

        ImportProgress NewProgress()
        {
            return new ImportProgress
            {
                Changed = OnImportProgress
            };
        }

        void OnImportProgress(string tag, int done, int total)
        {
            if (total < 1)
                total = 1;
            SetProgress(done / (float)total);
            SetProgressIcon(tag);
        }

        void SetProgress(float value)
        {
            float t = Mathf.Clamp01(value);
            if (processFillImage != null)
            {
                if (processFillImage.type != Image.Type.Filled)
                {
                    processFillImage.type = Image.Type.Filled;
                    processFillImage.fillMethod = Image.FillMethod.Horizontal;
                    processFillImage.fillOrigin = (int)Image.OriginHorizontal.Left;
                }

                processFillImage.fillAmount = t;
            }
            else if (processFillRect != null)
            {
                processFillRect.anchorMin = new Vector2(0f, 0f);
                processFillRect.anchorMax = new Vector2(t, 1f);
                processFillRect.pivot = new Vector2(0f, 0.5f);
                processFillRect.offsetMin = Vector2.zero;
                processFillRect.offsetMax = Vector2.zero;
            }

            // Icon 跟着进度条前端（右端）走。
            if (processIconRect != null && processBarRect != null)
            {
                float width = processBarRect.rect.width;
                if (width < 1f)
                    width = processBarRect.sizeDelta.x;
                Vector2 pos = processIconRect.anchoredPosition;
                pos.x = width * (t - 0.5f);
                processIconRect.anchoredPosition = pos;
            }
        }

        void SetProgressIcon(string tag)
        {
            if (processIcon == null || string.IsNullOrEmpty(tag))
                return;
            if (string.Equals(tag, lastProgressTag, StringComparison.Ordinal))
                return;
            lastProgressTag = tag;
            if (TryFindTagIcon(tag, out Sprite sprite))
            {
                processIcon.sprite = sprite;
                processIcon.enabled = true;
            }
        }

        bool TryFindTagIcon(string tag, out Sprite sprite)
        {
            sprite = null;
            if (string.IsNullOrEmpty(tag))
                return false;
            if (tagIcons.TryGetValue(tag, out sprite) && sprite != null)
                return true;

            if (catalog != null)
            {
                WardrobeTagDef def = catalog.FindTag(tag);
                if (def != null && !string.IsNullOrEmpty(def.tagName)
                    && tagIcons.TryGetValue(def.tagName, out sprite) && sprite != null)
                    return true;
            }

            if (tagIcons.TryGetValue("其它饰品", out sprite) && sprite != null)
                return true;
            return tagIcons.TryGetValue("场景", out sprite) && sprite != null;
        }

        string LayerToTagName(string layerName)
        {
            if (string.IsNullOrEmpty(layerName))
                return layerName;
            if (catalog != null)
            {
                WardrobeTagDef tag = catalog.FindTag(layerName);
                if (tag != null && !string.IsNullOrEmpty(tag.tagName))
                    return tag.tagName;
            }

            return layerName;
        }

        IEnumerator BuildGroupedItems(
            List<PsdGarment> garments,
            PsdDocument doc,
            string tagName,
            List<ClothingItem> items,
            ImportProgress progress)
        {
            var buckets = new Dictionary<string, List<PsdGarment>>();
            var bucketTags = new Dictionary<string, string>();
            for (int i = 0; i < garments.Count; i++)
            {
                PsdGarment garment = garments[i];
                string tag = string.IsNullOrEmpty(tagName) ? MatchGroupTag(garment) : tagName;
                string layer = tag == UnsortedTag
                    ? "QJ"
                    : PsdClothingBuilder.LayerForTag(catalog, tag, garment != null ? garment.GroupName : null);
                if (!buckets.TryGetValue(layer, out List<PsdGarment> bucket))
                {
                    bucket = new List<PsdGarment>();
                    buckets.Add(layer, bucket);
                    bucketTags[layer] = tag;
                }

                bucket.Add(garment);
            }

            if (progress != null)
            {
                progress.Total = Mathf.Max(1, PsdClothingBuilder.CountLayers(garments));
                progress.Done = 0;
                progress.Changed?.Invoke(tagName, 0, progress.Total);
            }

            ImportedWardrobe wardrobe = ImportedWardrobe.Ensure();
            foreach (KeyValuePair<string, List<PsdGarment>> pair in buckets)
            {
                string layer = pair.Key;
                string tag = bucketTags.TryGetValue(layer, out string mapped) ? mapped : tagName;
                int first = wardrobe.NextSerial(layer + "_m");
                yield return StartCoroutine(PsdClothingBuilder.FromGarments(
                    doc,
                    pair.Value,
                    layer,
                    layer + "_m",
                    wardrobe,
                    first,
                    items,
                    string.IsNullOrEmpty(tagName) ? null : tagName,
                    string.IsNullOrEmpty(tagName) ? MatchGroupTag : null,
                    progress));
            }
        }

        string MatchGroupTag(PsdGarment garment)
        {
            if (garment != null)
            {
                for (int i = 0; i < garment.GroupNames.Count; i++)
                {
                    string matched = MatchGroupName(garment.GroupNames[i]);
                    if (matched != UnsortedTag)
                        return matched;
                }
            }

            return UnsortedTag;
        }

        string MatchGroupName(string groupName)
        {
            if (catalog == null || string.IsNullOrEmpty(groupName))
                return UnsortedTag;

            WardrobeTagDef tag = catalog.FindTag(groupName);
            if (tag == null || tag.layers == null || tag.layers.Count == 0)
                return UnsortedTag;

            return tag.tagName;
        }

        void PresentPad()
        {
            PadHost.Show("InputPad");
            if (padImage != null)
                padImage.raycastTarget = true;
        }

        static void HideWebFileInput()
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            DressUpHideFileInput();
#endif
        }

        void ResetImport()
        {
            EndProgressUi();
            finished = false;
            SetSure(sureHome);
            HideWebFileInput();
            mode = Mode.None;
            step = Step.Modes;
        }

        void HidePad()
        {
            if (pad != null)
                pad.gameObject.SetActive(false);
            PadHost.Close();
        }

        void BringChromeForward()
        {
            if (selectPad != null && selectPad.activeSelf)
                selectPad.transform.SetAsLastSibling();
            if (picturePage != null && picturePage.activeSelf)
                picturePage.transform.SetAsLastSibling();
            if (chooseText != null)
                chooseText.transform.SetAsLastSibling();
            if (choosePictureText != null && choosePictureText.gameObject.activeSelf)
                choosePictureText.transform.SetAsLastSibling();
            if (caution != null)
            {
                caution.SetActive(true);
                caution.transform.SetAsLastSibling();
            }

            if (cancelButton != null && cancelButton.gameObject.activeSelf)
                cancelButton.transform.SetAsLastSibling();
            if (sureButton != null && sureButton.gameObject.activeSelf)
                sureButton.transform.SetAsLastSibling();

            Transform close = pad != null ? pad.transform.Find("CloseButton") : null;
            if (close != null)
                close.SetAsLastSibling();
        }

        static string Choose(ImportPadCopy.Situation situation)
        {
            return situation != null ? situation.choose : null;
        }

        static string Caution(ImportPadCopy.Situation situation)
        {
            return situation != null ? situation.caution : null;
        }

        void SetChoose(string message)
        {
            if (chooseText != null)
                chooseText.text = message;
        }

        public void NotifyStorage(string message)
        {
            if (!string.IsNullOrEmpty(message))
                SetChoose(message);
        }

        void SetCaution(string message)
        {
            if (cautionLabel != null && message != null)
                cautionLabel.text = message;
        }

        void SetSure(string message)
        {
            if (sureLabel != null && !string.IsNullOrEmpty(message))
                sureLabel.text = message;
        }

        void SetCancel(string message)
        {
            if (cancelLabel != null && !string.IsNullOrEmpty(message))
                cancelLabel.text = message;
        }

        void EnsureServiceLine(Transform root)
        {
            var go = new GameObject("ServiceLine", typeof(RectTransform));
            go.transform.SetParent(root, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(860f, 80f);
            serviceLabel = go.AddComponent<TextMeshProUGUI>();
            if (cautionLabel != null)
            {
                serviceLabel.font = cautionLabel.font;
                serviceLabel.fontSharedMaterial = cautionLabel.fontSharedMaterial;
                serviceLabel.fontSize = cautionLabel.fontSize;
                serviceLabel.color = cautionLabel.color;
            }

            serviceLabel.alignment = TextAlignmentOptions.Center;
            serviceLabel.richText = true;
            serviceLabel.enableWordWrapping = false;
            serviceLabel.raycastTarget = false;
            serviceLabel.text = ServiceLine;
            go.SetActive(false);
        }

        void SetServiceLine(bool visible)
        {
            if (serviceLabel == null)
                return;
            serviceLabel.gameObject.SetActive(visible);
            if (visible)
                serviceLabel.transform.SetAsLastSibling();
        }

        void MarkFinished()
        {
            EndProgressUi();
            busy = false;
            finished = true;
            SetSure(sureHome);
            SetChoose(SureDone);
        }

        void ShakeChoose()
        {
            if (shake != null)
                StopCoroutine(shake);
            shake = StartCoroutine(ShakeRoutine());
        }

        System.Collections.IEnumerator ShakeRoutine()
        {
            if (chooseText == null)
                yield break;
            RectTransform rect = chooseText.rectTransform;
            float origin = rect.anchoredPosition.x;
            float time = 0f;
            const float duration = 0.35f;
            while (time < duration)
            {
                time += Time.unscaledDeltaTime;
                float falloff = 1f - time / duration;
                Vector2 position = rect.anchoredPosition;
                position.x = origin + Mathf.Sin(time * 46f) * 14f * falloff;
                rect.anchoredPosition = position;
                yield return null;
            }

            Vector2 end = rect.anchoredPosition;
            end.x = origin;
            rect.anchoredPosition = end;
            shake = null;
        }

        void SetNamed(string name, bool active)
        {
            if (pad == null)
                return;
            SetActive(FindChild(pad.transform, name), active);
        }

        static void SetActive(GameObject target, bool active)
        {
            if (target != null)
                target.SetActive(active);
        }

        static void SetActive(TMP_Text target, bool active)
        {
            if (target != null)
                target.gameObject.SetActive(active);
        }

        static GameObject FindChild(Transform parent, string name)
        {
            Transform child = parent.Find(name);
            return child != null ? child.gameObject : null;
        }

        static TMP_Text FindText(Transform parent, string name)
        {
            Transform child = parent.Find(name);
            return child != null ? child.GetComponent<TMP_Text>() : null;
        }

        static string FirstLabel(Transform root)
        {
            TMP_Text[] texts = root.GetComponentsInChildren<TMP_Text>(true);
            for (int i = 0; i < texts.Length; i++)
            {
                if (texts[i] == null || string.IsNullOrWhiteSpace(texts[i].text))
                    continue;
                return texts[i].text.Replace("\n", "").Trim();
            }

            return "";
        }

#if UNITY_WEBGL && !UNITY_EDITOR
        [DllImport("__Internal")]
        static extern void DressUpShowFileInput(string accept, float x, float y, float w, float h, string objectName, string methodName);

        [DllImport("__Internal")]
        static extern void DressUpHideFileInput();

        [DllImport("__Internal")]
        static extern void DressUpClickFileInput();

        void LateUpdate()
        {
            if (!WebFilePickReady())
            {
                DressUpHideFileInput();
                return;
            }

            if (!TrySureScreenRect(out float x, out float y, out float w, out float h))
            {
                DressUpHideFileInput();
                return;
            }

            DressUpShowFileInput(WebFileAccept(), x, y, w, h, gameObject.name, nameof(OnWebFilePicked));
        }

        bool WebFilePickReady()
        {
            if (busy || finished || sureButton == null || !sureButton.gameObject.activeInHierarchy)
                return false;
            if (step == Step.Auto || step == Step.Manual)
                return true;
            return step == Step.PictureCategory && !string.IsNullOrEmpty(chosenTag);
        }

        string WebFileAccept()
        {
            return step == Step.PictureCategory ? ".psd,.png,image/png" : ".psd";
        }

        bool TrySureScreenRect(out float x, out float y, out float w, out float h)
        {
            x = 0f;
            y = 0f;
            w = 0f;
            h = 0f;
            RectTransform rect = sureButton.transform as RectTransform;
            if (rect == null)
                return false;

            Vector3[] corners = new Vector3[4];
            rect.GetWorldCorners(corners);
            Canvas canvas = sureButton.GetComponentInParent<Canvas>();
            Camera cam = null;
            if (canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay)
                cam = canvas.worldCamera;
            Vector2 min = RectTransformUtility.WorldToScreenPoint(cam, corners[0]);
            Vector2 max = RectTransformUtility.WorldToScreenPoint(cam, corners[2]);
            x = min.x;
            y = min.y;
            w = max.x - min.x;
            h = max.y - min.y;
            return w > 1f && h > 1f;
        }
#endif

        public void OnWebFilePicked(string message) => HandlePickedFile(message);

        public void OnAndroidFilePicked(string message) => HandlePickedFile(message);

        void HandlePickedFile(string message)
        {
            if (string.IsNullOrEmpty(message) || busy)
                return;
            if (message.StartsWith("error:", StringComparison.Ordinal))
            {
                SetChoose(message.Substring(6));
                return;
            }

            DressUpAudio.Instance?.PlayPopup();
            if (step == Step.Auto)
                StartCoroutine(ImportTemplate(message));
            else if (step == Step.Manual)
                StartCoroutine(ImportGrouped(message, null, manualEachLayer));
            else if (step == Step.PictureCategory)
                ImportFromPath(message);
        }

        static void ReleaseWebFile(string path)
        {
            if (string.IsNullOrEmpty(path))
                return;
            bool webTmp = path.IndexOf("/tmp/dressup-import", StringComparison.Ordinal) == 0;
            bool androidCopy = path.IndexOf("dressup-import-", StringComparison.Ordinal) >= 0;
            if (!webTmp && !androidCopy)
                return;
            try
            {
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
            }
            catch (Exception)
            {
            }
        }

        string PickFile(string title, string extension)
        {
#if UNITY_WEBGL && !UNITY_EDITOR
            DressUpClickFileInput();
            return null;
#elif UNITY_EDITOR
            if (extension != null && extension.IndexOf(',') >= 0)
                return EditorUtility.OpenFilePanelWithFilters(title, "", new[] { "PSD 或 PNG", extension });
            return EditorUtility.OpenFilePanel(title, "", extension);
#else
            string filter;
            if (extension == "png")
                filter = "PNG\0*.png\0\0";
            else if (extension != null && extension.IndexOf(',') >= 0)
                filter = "PSD 或 PNG\0*.psd;*.png\0\0";
            else
                filter = "PSD\0*.psd\0\0";
            return WindowsFileDialog.OpenSingle(title, filter);
#endif
        }

    }
}
