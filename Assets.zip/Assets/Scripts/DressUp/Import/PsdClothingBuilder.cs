using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using DressUp.Data;
using UnityEngine;

namespace DressUp.Import
{
    public sealed class TemplatePart
    {
        public int Number;
        public string LayerName;
        public int ItemIndex;
        public string Part;
    }

    /// <summary>导入进度：已处理图层 / 总图层，以及当前部位 tag。</summary>
    public sealed class ImportProgress
    {
        public int Done;
        public int Total = 1;
        public Action<string, int, int> Changed;

        public void Report(string tag)
        {
            if (Done < Total)
                Done++;
            Changed?.Invoke(tag, Done, Total);
        }
    }

    public static class TemplateLayerMap
    {
        public const int SuccessMatchedLayers = 80;

        static Dictionary<int, TemplatePart> cache;

        public static Dictionary<int, TemplatePart> Load()
        {
            if (cache != null)
                return cache;

            cache = new Dictionary<int, TemplatePart>();
            TextAsset asset = Resources.Load<TextAsset>("DressUp/BodyPanelTemplateMap");
            if (asset == null)
            {
                Debug.LogError("[Import] 找不到模板图层表 DressUp/BodyPanelTemplateMap");
                return cache;
            }

            string[] lines = asset.text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim().TrimStart('\uFEFF');
                if (line.Length == 0 || line[0] == '#')
                    continue;
                string[] bits = line.Split(' ');
                if (bits.Length < 4)
                    continue;
                if (!int.TryParse(bits[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int number))
                    continue;
                if (!int.TryParse(bits[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out int index))
                    continue;
                cache[number] = new TemplatePart
                {
                    Number = number,
                    LayerName = bits[1],
                    ItemIndex = index,
                    Part = bits[3]
                };
            }

            return cache;
        }

        public static bool TryParseLayerNumber(string name, out int number)
        {
            number = 0;
            if (string.IsNullOrEmpty(name))
                return false;
            Match match = Regex.Match(name.Trim(), @"^图层\s*(\d+)$");
            return match.Success && int.TryParse(match.Groups[1].Value, out number);
        }
    }

    public static class PsdClothingBuilder
    {
        const int LayersPerYield = 8;

        public static Sprite CreateSprite(PsdDocument doc, PsdLayerInfo layer, List<Texture> owned, bool placeOnPanel = false)
        {
            if (layer == null || layer.IsGroup || layer.IsGroupEnd)
                return null;
            if (!layer.HasPixels)
                return CreateBlank(owned);

            byte[] rgba = doc.ReadRgba(layer);
            if (rgba == null)
                return CreateBlank(owned);
            if (!PsdPixels.Crop(rgba, layer.Width, layer.Height, out byte[] cropped, out int cropX, out int cropY, out int cropWidth, out int cropHeight))
                return CreateBlank(owned);
            rgba = null;

            int docX = layer.Left + cropX;
            int docY = layer.Top + cropY;
            return CreateSprite(cropped, cropWidth, cropHeight, docX, docY, doc.Width, doc.Height, owned, placeOnPanel);
        }

        public static Sprite CreateSprite(byte[] rgbaTopLeft, int width, int height, int docX, int docY, int canvasWidth, int canvasHeight, List<Texture> owned, bool placeOnPanel = false)
        {
            const float panel = 888f;
            float fit = 1f;
            float layout = 1f;
            if (placeOnPanel)
            {
                float longest = Mathf.Max(canvasWidth, canvasHeight);
                if (longest > panel)
                    fit = panel / longest;
                if (longest > 1f)
                    layout = panel / longest;
            }

            int outW = Mathf.Max(1, Mathf.RoundToInt(width * fit));
            int outH = Mathf.Max(1, Mathf.RoundToInt(height * fit));

            var pixels = new Color32[outW * outH];
            int opaque = 0;
            for (int y = 0; y < outH; y++)
            {
                int srcY = height <= 1 ? 0 : Mathf.Min(height - 1, y * height / outH);
                int srcRow = srcY * width * 4;
                int unityY = outH - 1 - y;
                for (int x = 0; x < outW; x++)
                {
                    int srcX = width <= 1 ? 0 : Mathf.Min(width - 1, x * width / outW);
                    int src = srcRow + srcX * 4;
                    var pixel = new Color32(
                        rgbaTopLeft[src], rgbaTopLeft[src + 1], rgbaTopLeft[src + 2], rgbaTopLeft[src + 3]);
                    pixels[unityY * outW + x] = pixel;
                    if (pixel.a > 16)
                        opaque++;
                }
            }

            var texture = new Texture2D(outW, outH, TextureFormat.RGBA32, false);
            texture.SetPixels32(pixels);
            texture.Apply(false, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            if (owned != null)
                owned.Add(texture);

            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, outW, outH), new Vector2(0.5f, 0.5f), 100f);
            sprite.hideFlags = HideFlags.HideAndDontSave;
            if (outW * outH > 0 && opaque >= outW * outH * 0.92f)
                sprite.name = "plate";
            bool fullCanvas = width >= canvasWidth - 1 && height >= canvasHeight - 1;
            if (!placeOnPanel || !fullCanvas)
            {
                float centerX = (docX + width * 0.5f) * layout;
                float centerY = (docY + height * 0.5f) * layout;
                float canvasW = canvasWidth * layout;
                float canvasH = canvasHeight * layout;
                float showW = layout < 1f ? outW : width * layout;
                float showH = layout < 1f ? outH : height * layout;
                var anchored = new Vector2(centerX - canvasW * 0.5f, canvasH * 0.5f - centerY);
                ImportedSpriteFrames.Remember(sprite, anchored, new Vector2(showW, showH));
            }

            // PNG 延后到 Take / WriteNow，避免导入阶段双编码。
            NoteImportedSprite();
            return sprite;
        }

        static Sprite CreateBlank(List<Texture> owned)
        {
            var texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            texture.SetPixel(0, 0, new Color(0f, 0f, 0f, 0f));
            texture.Apply(false, false);
            texture.hideFlags = HideFlags.HideAndDontSave;
            if (owned != null)
                owned.Add(texture);

            Sprite sprite = Sprite.Create(texture, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 100f);
            sprite.hideFlags = HideFlags.HideAndDontSave;
            sprite.name = "blank";
            ImportedSpriteFrames.Remember(sprite, Vector2.zero, Vector2.one);
            NoteImportedSprite();
            return sprite;
        }

        static bool IsPlate(Sprite sprite)
        {
            return sprite != null && sprite.name == "plate";
        }

        static void DropSolidPlates(List<Sprite> fills, List<Sprite> outlines)
        {
            bool drawing = false;
            for (int i = 0; i < fills.Count; i++)
            {
                if (!IsPlate(fills[i]))
                    drawing = true;
            }

            for (int i = 0; i < outlines.Count; i++)
            {
                if (!IsPlate(outlines[i]))
                    drawing = true;
            }

            if (!drawing)
            {
                DestroySprites(fills);
                DestroySprites(outlines);
                return;
            }

            for (int i = fills.Count - 1; i >= 0; i--)
            {
                if (!IsPlate(fills[i]))
                    continue;
                DestroySprite(fills[i]);
                fills.RemoveAt(i);
            }

            for (int i = outlines.Count - 1; i >= 0; i--)
            {
                if (!IsPlate(outlines[i]))
                    continue;
                DestroySprite(outlines[i]);
                outlines.RemoveAt(i);
            }
        }

        static void DestroySprites(List<Sprite> sprites)
        {
            for (int i = 0; i < sprites.Count; i++)
                DestroySprite(sprites[i]);
            sprites.Clear();
        }

        static void DestroySprite(Sprite sprite)
        {
            if (sprite == null)
                return;
            Texture texture = sprite.texture;
            ImportedSpriteFrames.Forget(sprite);
            UnityEngine.Object.DestroyImmediate(sprite);
            if (texture != null)
                UnityEngine.Object.DestroyImmediate(texture);
        }

        static int importedSinceCollect;

        static void NoteImportedSprite()
        {
#if !UNITY_EDITOR
            importedSinceCollect++;
            if (importedSinceCollect < LayersPerYield)
                return;
            importedSinceCollect = 0;
            GC.Collect();
#else
            importedSinceCollect = 0;
#endif
        }

        public static int CountLayers(IList<PsdGarment> garments)
        {
            if (garments == null)
                return 0;
            int total = 0;
            for (int i = 0; i < garments.Count; i++)
            {
                PsdGarment g = garments[i];
                if (g == null)
                    continue;
                total += g.Fills.Count + g.Outlines.Count;
            }

            return total;
        }

        public static IEnumerator FromTemplate(
            PsdDocument doc,
            Dictionary<int, TemplatePart> map,
            ImportedWardrobe wardrobe,
            List<ClothingItem> items,
            ImportProgress progress = null,
            Func<string, string> layerToTag = null)
        {
            if (wardrobe == null)
                wardrobe = ImportedWardrobe.Ensure();
            var grouped = new Dictionary<string, PartBucket>();
            int burst = 0;
            int total = 0;
            if (progress != null && doc != null)
            {
                for (int i = 0; i < doc.Layers.Count; i++)
                {
                    PsdLayerInfo layer = doc.Layers[i];
                    if (TemplateLayerMap.TryParseLayerNumber(layer.Name, out int number) && map != null && map.ContainsKey(number))
                        total++;
                }

                progress.Total = Mathf.Max(1, total);
                progress.Done = 0;
            }

            for (int i = 0; i < doc.Layers.Count; i++)
            {
                PsdLayerInfo layer = doc.Layers[i];
                if (TemplateLayerMap.TryParseLayerNumber(layer.Name, out int number) && map.TryGetValue(number, out TemplatePart part))
                {
                    Sprite sprite = CreateSprite(doc, layer, null, true);
                    ImportedSave.Picture picture = ImportedSave.Take(sprite);
                    if (picture != null)
                    {
                        string key = part.LayerName + "\n" + part.ItemIndex.ToString(CultureInfo.InvariantCulture);
                        if (!grouped.TryGetValue(key, out PartBucket bucket))
                        {
                            bucket = new PartBucket { LayerName = part.LayerName, ItemIndex = part.ItemIndex };
                            grouped[key] = bucket;
                        }

                        if (part.Part == "C")
                            bucket.Companion = picture;
                        else
                            bucket.Parts.Add(new PartSprite { Part = part.Part, Picture = picture });
                    }

                    string tag = layerToTag != null ? layerToTag(part.LayerName) : part.LayerName;
                    progress?.Report(tag);
                    burst++;
                    if (burst >= LayersPerYield)
                    {
                        burst = 0;
                        yield return null;
                    }
                }
            }

            var byKey = new Dictionary<string, ClothingItem>();
            foreach (PartBucket bucket in grouped.Values)
            {
                if (bucket.LayerName == "YJT")
                    continue;
                ClothingItem item = bucket.ToItem();
                if (item == null)
                    continue;
                items.Add(item);
                byKey[bucket.LayerName + "\n" + bucket.ItemIndex.ToString(CultureInfo.InvariantCulture)] = item;
            }

            foreach (PartBucket bucket in grouped.Values)
            {
                if (bucket.LayerName != "YJT" || bucket.Companion == null)
                    continue;
                string eyeKey = "YJ\n" + bucket.ItemIndex.ToString(CultureInfo.InvariantCulture);
                if (!byKey.TryGetValue(eyeKey, out ClothingItem eye))
                    continue;
                eye.tintCompanionLayer = "YJT";
                ImportedSave.AttachCompanion(eye, bucket.Companion);
            }

            items.Reverse();
        }

        public static string LayerForTag(ClothingCatalog catalog, string tagName, string groupName)
        {
            // 特例：角 → J（衣柜并兽耳）。
            if (tagName == "角")
                return "J";
            // 特例：纹身 → WS（衣柜并人模）。
            if (tagName == "纹身")
                return "WS";

            WardrobeTagDef tag = catalog != null ? catalog.FindTag(tagName) : null;
            if (tag?.layers == null || tag.layers.Count == 0)
                return catalog != null ? catalog.PrimaryLayerForTag(tagName) : tagName;

            // 兽耳 / 人模等多图层：按 PSD 组名挑 SE / J / RM / WS。
            if (tag.layers.Count > 1 && !string.IsNullOrEmpty(groupName))
            {
                if (groupName.Contains("角") && tag.layers.Contains("J"))
                    return "J";
                if (groupName.Contains("兽耳") && tag.layers.Contains("SE"))
                    return "SE";
                if (groupName.Contains("纹身") && tag.layers.Contains("WS"))
                    return "WS";
                if (groupName.Contains("人模") && tag.layers.Contains("RM"))
                    return "RM";
            }

            return tag.layers[0];
        }

        public static IEnumerator FromGarments(
            PsdDocument doc,
            IList<PsdGarment> garments,
            string layerName,
            string idPrefix,
            ImportedWardrobe wardrobe,
            int firstIndex,
            List<ClothingItem> items,
            string progressTag = null,
            Func<PsdGarment, string> resolveTag = null,
            ImportProgress progress = null)
        {
            if (items == null)
                yield break;
            if (wardrobe == null)
                wardrobe = ImportedWardrobe.Ensure();
            int index = firstIndex < 1 ? 1 : firstIndex;
            int burst = 0;
            for (int i = 0; i < garments.Count; i++)
            {
                PsdGarment garment = garments[i];
                string layer = layerName;
                if (garment.GroupName != null && garment.GroupName.Contains("角") && layerName == "WB")
                    layer = "J";

                string tag = progressTag;
                if (string.IsNullOrEmpty(tag) && resolveTag != null)
                    tag = resolveTag(garment);
                if (string.IsNullOrEmpty(tag))
                    tag = garment != null ? garment.GroupName : layerName;

                var fillSprites = new List<Sprite>();
                var outlineSprites = new List<Sprite>();
                for (int f = 0; f < garment.Fills.Count; f++)
                {
                    Sprite sprite = CreateSprite(doc, garment.Fills[f], null);
                    if (sprite != null)
                        fillSprites.Add(sprite);
                    progress?.Report(tag);
                    burst++;
                    if (burst >= LayersPerYield)
                    {
                        burst = 0;
                        yield return null;
                    }
                }

                for (int o = 0; o < garment.Outlines.Count; o++)
                {
                    Sprite sprite = CreateSprite(doc, garment.Outlines[o], null);
                    if (sprite != null)
                        outlineSprites.Add(sprite);
                    progress?.Report(tag);
                    burst++;
                    if (burst >= LayersPerYield)
                    {
                        burst = 0;
                        yield return null;
                    }
                }

                DropSolidPlates(fillSprites, outlineSprites);

                var fills = new List<ImportedSave.Picture>();
                var outlines = new List<ImportedSave.Picture>();
                for (int f = 0; f < fillSprites.Count; f++)
                {
                    ImportedSave.Picture picture = ImportedSave.Take(fillSprites[f]);
                    if (picture != null)
                        fills.Add(picture);
                }

                for (int o = 0; o < outlineSprites.Count; o++)
                {
                    ImportedSave.Picture picture = ImportedSave.Take(outlineSprites[o]);
                    if (picture != null)
                        outlines.Add(picture);
                }

                if (fills.Count == 0 && outlines.Count > 0)
                {
                    fills.Add(outlines[0]);
                    outlines.RemoveAt(0);
                }

                if (fills.Count == 0)
                    continue;

                var item = new ClothingItem
                {
                    layerName = layer,
                    itemId = idPrefix + index.ToString(CultureInfo.InvariantCulture),
                    presetColor = Color.white,
                    tintable = true
                };
                ImportedSave.Attach(
                    item,
                    fills[0],
                    outlines.Count > 0 ? outlines[0] : null,
                    fills.Count > 1 ? fills.GetRange(1, fills.Count - 1) : null,
                    outlines.Count > 1 ? outlines.GetRange(1, outlines.Count - 1) : null,
                    null);
                items.Add(item);
                index++;
            }
        }

        sealed class PartSprite
        {
            public string Part;
            public ImportedSave.Picture Picture;
        }

        sealed class PartBucket
        {
            public string LayerName;
            public int ItemIndex;
            public ImportedSave.Picture Companion;
            public readonly List<PartSprite> Parts = new List<PartSprite>();

            public ClothingItem ToItem()
            {
                Parts.Sort((a, b) => Rank(a.Part).CompareTo(Rank(b.Part)));
                var fills = new List<ImportedSave.Picture>();
                var outlines = new List<ImportedSave.Picture>();
                for (int i = 0; i < Parts.Count; i++)
                {
                    if (Parts[i].Part.StartsWith("B", StringComparison.Ordinal))
                        outlines.Add(Parts[i].Picture);
                    else
                        fills.Add(Parts[i].Picture);
                }

                if (fills.Count == 0 && outlines.Count > 0)
                {
                    fills.Add(outlines[0]);
                    outlines.RemoveAt(0);
                }

                if (fills.Count == 0)
                    return null;

                var item = new ClothingItem
                {
                    layerName = LayerName,
                    itemId = LayerName + "_" + ItemIndex.ToString(CultureInfo.InvariantCulture),
                    presetColor = Color.white,
                    tintable = true
                };
                ImportedSave.Attach(
                    item,
                    fills[0],
                    outlines.Count > 0 ? outlines[0] : null,
                    fills.Count > 1 ? fills.GetRange(1, fills.Count - 1) : null,
                    outlines.Count > 1 ? outlines.GetRange(1, outlines.Count - 1) : null,
                    null);
                return item;
            }

            static int Rank(string part)
            {
                if (string.IsNullOrEmpty(part))
                    return 0;
                int number = 1;
                if (part.Length > 1)
                    int.TryParse(part.Substring(1), out number);
                int group = part[0] == 'B' ? 0 : 100;
                return group + number;
            }
        }
    }
}
