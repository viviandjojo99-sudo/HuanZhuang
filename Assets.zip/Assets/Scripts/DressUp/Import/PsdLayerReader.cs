using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DressUp.Import
{
    public sealed class PsdLayerInfo
    {
        public string Name;
        public int Top;
        public int Left;
        public int Bottom;
        public int Right;
        public int Section;
        public bool IsGroup;
        public bool IsGroupEnd;
        public List<PsdChannelRef> Channels = new List<PsdChannelRef>();

        public int Width => Math.Max(0, Right - Left);
        public int Height => Math.Max(0, Bottom - Top);
        public bool HasPixels => Width > 0 && Height > 0 && !IsGroup && !IsGroupEnd;
    }

    public struct PsdChannelRef
    {
        public short Id;
        public long DataOffset;
        public uint DataLength;
    }

    /// <summary>
    /// 只读 PSD 图层记录和像素。不依赖画师图片进包，玩家选文件后再读。
    /// </summary>
    public sealed class PsdDocument : IDisposable
    {
        readonly FileStream stream;
        readonly BinaryReader reader;

        public int Width { get; private set; }
        public int Height { get; private set; }
        public int Depth { get; private set; }
        public List<PsdLayerInfo> Layers { get; } = new List<PsdLayerInfo>();

        PsdDocument(string path)
        {
            stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            reader = new BinaryReader(stream);
        }

        public static PsdDocument Open(string path)
        {
            var doc = new PsdDocument(path);
            try
            {
                doc.ReadStructure();
                return doc;
            }
            catch
            {
                doc.Dispose();
                throw;
            }
        }

        public void Dispose()
        {
            reader?.Dispose();
            stream?.Dispose();
        }

        /// <summary>像素按从上到下、从左到右，每像素 R,G,B,A。</summary>
        public byte[] ReadRgba(PsdLayerInfo layer)
        {
            int width = layer.Width;
            int height = layer.Height;
            if (width <= 0 || height <= 0)
                return null;

            var channels = new Dictionary<short, byte[]>();
            for (int i = 0; i < layer.Channels.Count; i++)
            {
                PsdChannelRef channel = layer.Channels[i];
                if (channel.Id > 2 && channel.Id != -1)
                    continue;
                channels[channel.Id] = ReadChannel(channel, width, height);
            }

            byte[] rgba = new byte[width * height * 4];
            bool hasAlpha = channels.ContainsKey(-1);
            for (int i = 0; i < width * height; i++)
            {
                int o = i * 4;
                rgba[o] = channels.TryGetValue(0, out byte[] r) ? r[i] : (byte)0;
                rgba[o + 1] = channels.TryGetValue(1, out byte[] g) ? g[i] : (byte)0;
                rgba[o + 2] = channels.TryGetValue(2, out byte[] b) ? b[i] : (byte)0;
                rgba[o + 3] = hasAlpha ? channels[-1][i] : (byte)255;
            }

            return rgba;
        }

        void ReadStructure()
        {
            if (ReadFourCC() != "8BPS")
                throw new InvalidDataException("不是 PSD 文件。");
            ushort version = ReadU16();
            if (version != 1)
                throw new InvalidDataException("只支持普通 PSD，不支持 PSB。");
            stream.Seek(6, SeekOrigin.Current);
            ReadU16();
            Height = (int)ReadU32();
            Width = (int)ReadU32();
            Depth = ReadU16();
            ushort colorMode = ReadU16();
            if (Depth != 8 || colorMode != 3)
                throw new InvalidDataException("只支持 8 位 RGB 的 PSD。");

            SkipBlock32();
            SkipBlock32();

            long layerAndMaskLength = ReadU32();
            long layerAndMaskEnd = stream.Position + layerAndMaskLength;
            if (layerAndMaskLength == 0)
                return;

            long layerInfoLength = ReadU32();
            long layerInfoEnd = stream.Position + layerInfoLength;
            short layerCount = ReadI16();
            int count = Math.Abs(layerCount);

            var pending = new List<PsdLayerInfo>(count);
            for (int i = 0; i < count; i++)
                pending.Add(ReadLayerRecord());

            for (int i = 0; i < pending.Count; i++)
            {
                PsdLayerInfo layer = pending[i];
                for (int c = 0; c < layer.Channels.Count; c++)
                {
                    PsdChannelRef channel = layer.Channels[c];
                    channel.DataOffset = stream.Position;
                    layer.Channels[c] = channel;
                    stream.Seek(channel.DataLength, SeekOrigin.Current);
                }
            }

            Layers.AddRange(pending);
            stream.Seek(layerInfoEnd, SeekOrigin.Begin);
            if (stream.Position < layerAndMaskEnd)
                stream.Seek(layerAndMaskEnd, SeekOrigin.Begin);
        }

        PsdLayerInfo ReadLayerRecord()
        {
            var layer = new PsdLayerInfo
            {
                Top = ReadI32(),
                Left = ReadI32(),
                Bottom = ReadI32(),
                Right = ReadI32()
            };

            int channelCount = ReadU16();
            for (int i = 0; i < channelCount; i++)
            {
                layer.Channels.Add(new PsdChannelRef
                {
                    Id = ReadI16(),
                    DataLength = ReadU32()
                });
            }

            if (ReadFourCC() != "8BIM")
                throw new InvalidDataException("图层混合模式标记不对。");
            ReadFourCC();
            stream.Seek(4, SeekOrigin.Current);

            uint extraLength = ReadU32();
            long extraEnd = stream.Position + extraLength;
            uint maskLength = ReadU32();
            stream.Seek(maskLength, SeekOrigin.Current);
            uint blendLength = ReadU32();
            stream.Seek(blendLength, SeekOrigin.Current);

            layer.Name = ReadPascalName();
            while (stream.Position + 12 <= extraEnd)
            {
                string signature = ReadFourCC();
                if (signature != "8BIM" && signature != "8B64")
                {
                    stream.Seek(extraEnd, SeekOrigin.Begin);
                    break;
                }

                string key = ReadFourCC();
                uint length = ReadU32();
                long dataEnd = stream.Position + length;
                if (key == "luni" && length >= 4)
                {
                    int charCount = (int)ReadU32();
                    int bytes = Math.Min(charCount * 2, (int)(dataEnd - stream.Position));
                    if (bytes > 0)
                    {
                        byte[] raw = reader.ReadBytes(bytes);
                        string unicode = Encoding.BigEndianUnicode.GetString(raw).TrimEnd('\0');
                        if (!string.IsNullOrEmpty(unicode))
                            layer.Name = unicode;
                    }
                }
                else if ((key == "lsct" || key == "lsdk") && length >= 4)
                {
                    layer.Section = (int)ReadU32();
                    layer.IsGroup = layer.Section == 1 || layer.Section == 2;
                    layer.IsGroupEnd = layer.Section == 3;
                }

                long padded = dataEnd + (length & 1);
                if (padded > extraEnd)
                    padded = extraEnd;
                stream.Seek(padded, SeekOrigin.Begin);
            }

            if (stream.Position != extraEnd)
                stream.Seek(extraEnd, SeekOrigin.Begin);
            return layer;
        }

        byte[] ReadChannel(PsdChannelRef channel, int width, int height)
        {
            stream.Seek(channel.DataOffset, SeekOrigin.Begin);
            ushort compression = ReadU16();
            int count = width * height;
            if (compression == 0)
                return reader.ReadBytes(count);
            if (compression == 1)
                return ReadRle(width, height);
            throw new InvalidDataException("这个 PSD 的图层用了压缩方式 " + compression + "，当前只读未压缩和 RLE。");
        }

        byte[] ReadRle(int width, int height)
        {
            var rowLengths = new int[height];
            for (int y = 0; y < height; y++)
                rowLengths[y] = ReadU16();

            byte[] pixels = new byte[width * height];
            int dst = 0;
            for (int y = 0; y < height; y++)
            {
                int rowEnd = dst + width;
                long packedEnd = stream.Position + rowLengths[y];
                while (dst < rowEnd && stream.Position < packedEnd)
                {
                    int n = reader.ReadSByte();
                    if (n >= 0)
                    {
                        int literal = n + 1;
                        int take = Math.Min(literal, rowEnd - dst);
                        int read = reader.Read(pixels, dst, take);
                        dst += read;
                        if (read < literal)
                            stream.Seek(literal - read, SeekOrigin.Current);
                    }
                    else if (n > -128)
                    {
                        byte value = reader.ReadByte();
                        int run = Math.Min(-n + 1, rowEnd - dst);
                        for (int i = 0; i < run; i++)
                            pixels[dst++] = value;
                    }
                }

                if (stream.Position < packedEnd)
                    stream.Seek(packedEnd, SeekOrigin.Begin);
                dst = rowEnd;
            }

            return pixels;
        }

        string ReadPascalName()
        {
            int length = reader.ReadByte();
            byte[] bytes = length > 0 ? reader.ReadBytes(length) : Array.Empty<byte>();
            int padded = (1 + length + 3) & ~3;
            int skip = padded - (1 + length);
            if (skip > 0)
                stream.Seek(skip, SeekOrigin.Current);
            return bytes.Length == 0 ? "" : Encoding.UTF8.GetString(bytes);
        }

        void SkipBlock32()
        {
            uint length = ReadU32();
            stream.Seek(length, SeekOrigin.Current);
        }

        string ReadFourCC()
        {
            byte[] raw = reader.ReadBytes(4);
            if (raw.Length < 4)
                throw new EndOfStreamException();
            return Encoding.ASCII.GetString(raw);
        }

        ushort ReadU16()
        {
            byte[] raw = reader.ReadBytes(2);
            return (ushort)((raw[0] << 8) | raw[1]);
        }

        short ReadI16()
        {
            return unchecked((short)ReadU16());
        }

        uint ReadU32()
        {
            byte[] raw = reader.ReadBytes(4);
            return (uint)((raw[0] << 24) | (raw[1] << 16) | (raw[2] << 8) | raw[3]);
        }

        int ReadI32()
        {
            return unchecked((int)ReadU32());
        }
    }

    public sealed class PsdGarment
    {
        public string GroupName;
        public readonly List<string> GroupNames = new List<string>();
        public readonly List<PsdLayerInfo> Outlines = new List<PsdLayerInfo>();
        public readonly List<PsdLayerInfo> Fills = new List<PsdLayerInfo>();
    }

    /// <summary>
    /// 图层记录仍按 PSD 从下往上读，组内下面是填色、上面是线稿。
    /// 导入顺序改成从上往下，最上面的衣服先进入衣柜。
    /// </summary>
    public static class PsdGroups
    {
        public static readonly List<string> Mismatches = new List<string>();
        sealed class Bucket
        {
            public string Name;
            public readonly List<PsdLayerInfo> Leaves = new List<PsdLayerInfo>();
            public readonly List<Bucket> Children = new List<Bucket>();
        }

        public static List<PsdGarment> Collect(PsdDocument doc)
        {
            return Collect(doc, false);
        }

        /// <summary>
        /// 图层组名末尾：+2 强制双层配对，+1 强制单层；无 1/2 后缀则跟 eachLayer（所选导入模式）。
        /// </summary>
        public static List<PsdGarment> Collect(PsdDocument doc, bool eachLayer)
        {
            Mismatches.Clear();
            var root = new Bucket();
            var stack = new Stack<Bucket>();
            stack.Push(root);

            for (int i = 0; i < doc.Layers.Count; i++)
            {
                PsdLayerInfo layer = doc.Layers[i];
                if (layer.IsGroupEnd)
                {
                    var child = new Bucket();
                    stack.Peek().Children.Add(child);
                    stack.Push(child);
                    continue;
                }

                if (layer.IsGroup)
                {
                    if (stack.Count > 1)
                    {
                        Bucket closed = stack.Pop();
                        closed.Name = layer.Name;
                    }
                    continue;
                }

                // 空图层和全透明层也留在序列里，避免后面的填色/线稿错开一格。组文件夹仍然只当分类。
                stack.Peek().Leaves.Add(layer);
            }

            var garments = new List<PsdGarment>();
            Walk(root, null, garments, eachLayer);
            garments.Reverse();
            return garments;
        }

        static void Walk(Bucket bucket, List<string> outer, List<PsdGarment> garments, bool eachLayer)
        {
            var names = new List<string>();
            // 组名「眼睛2」「眼睛1」进 Tag 时用前缀「眼睛」。
            string tagGroup = TagGroupName(bucket.Name);
            if (!string.IsNullOrEmpty(tagGroup))
                names.Add(tagGroup);
            if (outer != null)
                names.AddRange(outer);

            for (int i = 0; i < bucket.Children.Count; i++)
                Walk(bucket.Children[i], names, garments, eachLayer);

            // +2 双层，+1 单层，其它跟当前导入模式。
            bool pair = ResolvePairMode(bucket.Name, eachLayer);
            if (pair)
                PairFlat(bucket.Leaves, names, garments);
            else
                EachFlat(bucket.Leaves, names, garments);
        }

        static void EachFlat(List<PsdLayerInfo> leaves, List<string> groupNames, List<PsdGarment> garments)
        {
            for (int i = 0; i < leaves.Count; i++)
            {
                var garment = new PsdGarment();
                if (groupNames != null)
                    garment.GroupNames.AddRange(groupNames);
                if (garment.GroupNames.Count > 0)
                    garment.GroupName = garment.GroupNames[0];
                garment.Fills.Add(leaves[i]);
                garments.Add(garment);
            }
        }

        /// <summary>这一组内部结算。上色和线稿按名字对齐，多出来的层不把后面的组带偏。</summary>
        static void PairFlat(List<PsdLayerInfo> leaves, List<string> groupNames, List<PsdGarment> garments)
        {
            if (leaves == null || leaves.Count == 0)
                return;

            for (int i = 0; i < leaves.Count;)
            {
                PsdLayerInfo fill = leaves[i];
                PsdLayerInfo line = i + 1 < leaves.Count ? leaves[i + 1] : null;
                if (line != null && LayersMatch(fill, line))
                {
                    AddGarment(groupNames, garments, fill, line);
                    i += 2;
                    continue;
                }

                AddGarment(groupNames, garments, fill, null);
                Mismatches.Add(fill != null && fill.Name != null ? fill.Name : "");
                i += 1;
            }
        }

        static bool LayersMatch(PsdLayerInfo fill, PsdLayerInfo line)
        {
            bool fillNamed = TryRole(fill != null ? fill.Name : null, out bool fillIsColor, out int fillNumber);
            bool lineNamed = TryRole(line != null ? line.Name : null, out bool lineIsColor, out int lineNumber);
            if (fillNamed && lineNamed)
            {
                if (!fillIsColor || lineIsColor)
                    return false;
                if (fillNumber >= 0 || lineNumber >= 0)
                    return fillNumber == lineNumber;
                return true;
            }

            return !fillNamed && !lineNamed;
        }

        /// <summary>
        /// 组名 +2 → 双层；+1 → 单层；无 1/2 后缀 → 跟所选模式（eachLayer true=单层）。
        /// </summary>
        static bool ResolvePairMode(string groupName, bool eachLayer)
        {
            if (TryBaseAndNumber(groupName, out _, out int number))
            {
                if (number == 2)
                    return true;
                if (number == 1)
                    return false;
            }

            return !eachLayer;
        }

        /// <summary>Tag 用组名前缀：眼睛2 / 眼睛1 → 眼睛；其它原样。</summary>
        static string TagGroupName(string groupName)
        {
            if (string.IsNullOrEmpty(groupName))
                return groupName;
            if (TryBaseAndNumber(groupName, out string basename, out int number)
                && (number == 1 || number == 2))
                return basename;
            return groupName;
        }

        /// <summary>「眼睛2」→ 前缀「眼睛」、数字 2。纯数字或无末尾数字则失败。</summary>
        static bool TryBaseAndNumber(string name, out string basename, out int number)
        {
            basename = null;
            number = -1;
            if (string.IsNullOrEmpty(name))
                return false;

            name = name.Trim();
            int end = name.Length;
            int i = end - 1;
            while (i >= 0 && name[i] >= '0' && name[i] <= '9')
                i--;
            if (i < 0 || i == end - 1)
                return false;

            basename = name.Substring(0, i + 1).TrimEnd();
            if (string.IsNullOrEmpty(basename))
                return false;
            return int.TryParse(name.Substring(i + 1), out number);
        }

        static bool TryRole(string name, out bool fill, out int number)
        {
            fill = false;
            number = -1;
            if (string.IsNullOrEmpty(name))
                return false;

            int color = name.LastIndexOf("上色", StringComparison.Ordinal);
            int ink = name.LastIndexOf("线稿", StringComparison.Ordinal);
            if (color < 0 && ink < 0)
                color = name.LastIndexOf("填色", StringComparison.Ordinal);

            if (color < 0 && ink < 0)
                return false;

            int at;
            if (ink > color)
            {
                fill = false;
                at = ink + 2;
            }
            else
            {
                fill = true;
                at = color + 2;
            }

            number = LeadingNumber(name.Substring(at));
            return true;
        }

        static int LeadingNumber(string text)
        {
            if (string.IsNullOrEmpty(text))
                return -1;

            int i = 0;
            while (i < text.Length && text[i] == ' ')
                i++;
            int start = i;
            while (i < text.Length && text[i] >= '0' && text[i] <= '9')
                i++;
            if (i == start)
                return -1;
            return int.TryParse(text.Substring(start, i - start), out int value) ? value : -1;
        }

        static void AddGarment(List<string> groupNames, List<PsdGarment> garments, PsdLayerInfo fill, PsdLayerInfo line)
        {
            var garment = new PsdGarment();
            if (groupNames != null)
                garment.GroupNames.AddRange(groupNames);
            if (garment.GroupNames.Count > 0)
                garment.GroupName = garment.GroupNames[0];
            if (fill != null)
                garment.Fills.Add(fill);
            if (line != null)
                garment.Outlines.Add(line);
            garments.Add(garment);
        }
    }

    public static class PsdPixels
    {
        /// <summary>不透明像素的包围盒；right/bottom 与 PSD 一样是开区间。</summary>
        public static bool ContentBounds(byte[] rgba, int width, int height, out int x, out int y, out int right, out int bottom)
        {
            x = y = right = bottom = 0;
            if (rgba == null || width <= 0 || height <= 0)
                return false;
            int minX = width;
            int minY = height;
            int maxX = -1;
            int maxY = -1;
            for (int row = 0; row < height; row++)
            {
                int rowStart = row * width * 4;
                for (int col = 0; col < width; col++)
                {
                    if (rgba[rowStart + col * 4 + 3] == 0)
                        continue;
                    if (col < minX) minX = col;
                    if (col > maxX) maxX = col;
                    if (row < minY) minY = row;
                    if (row > maxY) maxY = row;
                }
            }

            if (maxX < minX || maxY < minY)
                return false;

            x = minX;
            y = minY;
            right = maxX + 1;
            bottom = maxY + 1;
            return true;
        }

        public static bool Crop(byte[] rgba, int width, int height, out byte[] cropped, out int x, out int y, out int cropWidth, out int cropHeight)
        {
            cropped = null;
            x = y = cropWidth = cropHeight = 0;
            if (!ContentBounds(rgba, width, height, out x, out y, out int right, out int bottom))
                return false;

            cropWidth = right - x;
            cropHeight = bottom - y;
            cropped = new byte[cropWidth * cropHeight * 4];
            for (int row = 0; row < cropHeight; row++)
            {
                Buffer.BlockCopy(
                    rgba,
                    ((y + row) * width + x) * 4,
                    cropped,
                    row * cropWidth * 4,
                    cropWidth * 4);
            }

            return true;
        }
    }
}
