using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Import
{
    /// <summary>
    /// 读 Resources/DressUp/Templates 里的多套模板表，并和玩家的 PSD 比对。
    /// </summary>
    public static class TemplateLibrary
    {
        public static IEnumerator Match(PsdDocument doc, List<TemplateSheet> found)
        {
            if (doc == null || found == null)
                yield break;

            TextAsset[] assets = Resources.LoadAll<TextAsset>("DressUp/Templates");
            if (assets == null || assets.Length == 0)
                yield break;

            var sheets = new List<TemplateSheet>(assets.Length);
            for (int i = 0; i < assets.Length; i++)
            {
                if (assets[i] == null || string.IsNullOrEmpty(assets[i].text))
                    continue;
                sheets.Add(TemplateSheet.Parse(assets[i].name, assets[i].text));
            }

            if (sheets.Count == 0)
                yield break;

            List<PsdLayerInfo> player = TemplateSheet.PlayerLayers(doc);
            yield return null;
            TemplateSheet chosen = TemplateSheet.Choose(sheets, doc, player, new uint[player.Count], null);
            if (chosen != null)
                found.Add(chosen);
        }
    }
}
