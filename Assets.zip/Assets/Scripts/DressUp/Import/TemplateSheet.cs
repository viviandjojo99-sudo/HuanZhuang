using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace DressUp.Import
{
    /// <summary>
    /// 一套已分组模板的图层对照。只记编号、分组、填色/线稿和像素指纹，不存图片。
    /// </summary>
    public sealed class TemplateRow
    {
        public int Number;
        public string[] Groups = Array.Empty<string>();
        public bool Line;
        public int Pair;
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
        public uint Fingerprint;
    }

    public sealed class TemplateScore
    {
        public string Name;
        public int NumberHits;
        public int PrintHits;
        public int TemplateRows;
    }

    public sealed class TemplateSheet
    {
        public const int MinNumberHits = 80;

        public string Name;
        public readonly List<TemplateRow> Rows = new List<TemplateRow>();
        readonly Dictionary<int, List<int>> byNumber = new Dictionary<int, List<int>>();

        public static TemplateSheet Build(string name, PsdDocument doc)
        {
            var sheet = new TemplateSheet { Name = name };
            List<PsdGarment> garments = PsdGroups.Collect(doc, false);
            for (int g = 0; g < garments.Count; g++)
            {
                PsdGarment garment = garments[g];
                if (garment.GroupNames.Count == 0)
                    continue;
                AddRows(sheet, doc, garment.Fills, garment.GroupNames, false, g);
                AddRows(sheet, doc, garment.Outlines, garment.GroupNames, true, g);
            }

            sheet.Index();
            return sheet;
        }

        public static TemplateSheet Parse(string name, string text)
        {
            var sheet = new TemplateSheet { Name = name };
            if (string.IsNullOrEmpty(text))
            {
                sheet.Index();
                return sheet;
            }

            string[] lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim().TrimStart('\uFEFF');
                if (line.Length == 0 || line[0] == '#')
                    continue;
                string[] bits = line.Split('\t');
                if (bits.Length < 9)
                    continue;
                if (!int.TryParse(bits[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out int number))
                    continue;
                if (!int.TryParse(bits[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out int pair))
                    continue;
                if (!int.TryParse(bits[4], NumberStyles.Integer, CultureInfo.InvariantCulture, out int left))
                    continue;
                if (!int.TryParse(bits[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out int top))
                    continue;
                if (!int.TryParse(bits[6], NumberStyles.Integer, CultureInfo.InvariantCulture, out int right))
                    continue;
                if (!int.TryParse(bits[7], NumberStyles.Integer, CultureInfo.InvariantCulture, out int bottom))
                    continue;
                if (!uint.TryParse(bits[8], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out uint print))
                    continue;
                string[] groups = bits[1].Split('|');
                sheet.Rows.Add(new TemplateRow
                {
                    Number = number,
                    Groups = groups,
                    Line = bits[2] == "L",
                    Pair = pair,
                    Left = left,
                    Top = top,
                    Right = right,
                    Bottom = bottom,
                    Fingerprint = print
                });
            }

            sheet.Index();
            return sheet;
        }

        public string ToText()
        {
            var text = new StringBuilder();
            text.Append("# number\tgroups\trole\tpair\tleft\ttop\tright\tbottom\tfingerprint\n");
            for (int i = 0; i < Rows.Count; i++)
            {
                TemplateRow row = Rows[i];
                text.Append(row.Number.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(string.Join("|", row.Groups));
                text.Append('\t');
                text.Append(row.Line ? "L" : "F");
                text.Append('\t');
                text.Append(row.Pair.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(row.Left.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(row.Top.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(row.Right.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(row.Bottom.ToString(CultureInfo.InvariantCulture));
                text.Append('\t');
                text.Append(row.Fingerprint.ToString("X8", CultureInfo.InvariantCulture));
                text.Append('\n');
            }

            return text.ToString();
        }

        public static List<PsdLayerInfo> PlayerLayers(PsdDocument doc)
        {
            var layers = new List<PsdLayerInfo>();
            if (doc == null)
                return layers;
            for (int i = 0; i < doc.Layers.Count; i++)
            {
                PsdLayerInfo layer = doc.Layers[i];
                if (layer.IsGroup || layer.IsGroupEnd)
                    continue;
                if (!TryLayerNumber(layer.Name, out _))
                    continue;
                layers.Add(layer);
            }

            return layers;
        }

        public static uint Fingerprint(PsdDocument doc, PsdLayerInfo layer)
        {
            if (doc == null || layer == null || !layer.HasPixels)
                return 0;
            byte[] rgba = doc.ReadRgba(layer);
            if (rgba == null || rgba.Length < 4)
                return 0;

            int pixels = rgba.Length / 4;
            uint hash = 2166136261;
            hash = Mix(hash, (uint)layer.Width);
            hash = Mix(hash, (uint)layer.Height);
            hash = Mix(hash, (uint)pixels);
            int stride = pixels / 512;
            if (stride < 1)
                stride = 1;
            for (int i = 0; i < pixels; i += stride)
            {
                int o = i * 4;
                hash = Mix(hash, rgba[o]);
                hash = Mix(hash, rgba[o + 1]);
                hash = Mix(hash, rgba[o + 2]);
                hash = Mix(hash, rgba[o + 3]);
            }

            return hash == 0 ? 1u : hash;
        }

        public static TemplateSheet Choose(
            IList<TemplateSheet> sheets,
            IList<PsdLayerInfo> player,
            uint[] prints,
            List<TemplateScore> report)
        {
            return Choose(sheets, null, player, prints, report);
        }

        public static TemplateSheet Choose(
            IList<TemplateSheet> sheets,
            PsdDocument doc,
            IList<PsdLayerInfo> player,
            uint[] prints,
            List<TemplateScore> report)
        {
            if (sheets == null || player == null || prints == null || player.Count != prints.Length)
                return null;

            var ranked = new List<TemplateScore>();
            var rankedSheets = new List<TemplateSheet>();
            int bestNumbers = 0;
            for (int s = 0; s < sheets.Count; s++)
            {
                TemplateSheet sheet = sheets[s];
                if (sheet == null)
                    continue;
                var used = new HashSet<int>();
                int numbers = 0;
                int matchedPrints = 0;
                for (int i = 0; i < player.Count; i++)
                {
                    int row = sheet.FindRow(doc, player[i], used);
                    if (row < 0)
                        continue;
                    used.Add(row);
                    numbers++;
                    if (prints[i] == sheet.Rows[row].Fingerprint)
                        matchedPrints++;
                }

                var score = new TemplateScore
                {
                    Name = sheet.Name,
                    NumberHits = numbers,
                    PrintHits = matchedPrints,
                    TemplateRows = sheet.Rows.Count
                };
                if (report != null)
                    report.Add(score);
                if (numbers < MinNumberHits)
                    continue;
                ranked.Add(score);
                rankedSheets.Add(sheet);
            }

            if (ranked.Count == 0)
                return null;

            TemplateSheet bestSheet = null;
            bestNumbers = 0;
            int secondNumbers = 0;
            for (int i = 0; i < ranked.Count; i++)
            {
                int numbers = ranked[i].NumberHits;
                if (numbers > bestNumbers)
                {
                    secondNumbers = bestNumbers;
                    bestNumbers = numbers;
                    bestSheet = rankedSheets[i];
                }
                else if (numbers > secondNumbers)
                {
                    secondNumbers = numbers;
                }
            }

            int lead = Math.Max(12, bestNumbers / 40);
            if (bestSheet != null && bestNumbers >= secondNumbers + lead)
                return bestSheet;

            // 并列最高分时：指纹多的优先，再优先编号更大的新模板（2 优于 1）。
            int bestPrintHits = -1;
            int bestName = int.MinValue;
            bestSheet = null;
            for (int i = 0; i < ranked.Count; i++)
            {
                if (ranked[i].NumberHits != bestNumbers)
                    continue;
                int printHits = ranked[i].PrintHits;
                int nameOrder = 0;
                int.TryParse(ranked[i].Name, out nameOrder);
                if (bestSheet == null
                    || printHits > bestPrintHits
                    || (printHits == bestPrintHits && nameOrder > bestName))
                {
                    bestSheet = rankedSheets[i];
                    bestPrintHits = printHits;
                    bestName = nameOrder;
                }
            }

            return bestSheet;
        }

        public List<PsdGarment> Rebuild(PsdDocument doc)
        {
            List<PsdLayerInfo> player = PlayerLayers(doc);
            var garments = new Dictionary<int, PsdGarment>();
            var order = new List<int>();
            var used = new HashSet<int>();
            for (int i = 0; i < player.Count; i++)
            {
                int index = FindRow(doc, player[i], used);
                if (index < 0)
                    continue;
                used.Add(index);
                TemplateRow row = Rows[index];
                if (!garments.TryGetValue(row.Pair, out PsdGarment garment))
                {
                    garment = new PsdGarment();
                    if (row.Groups != null)
                    {
                        for (int g = 0; g < row.Groups.Length; g++)
                        {
                            if (!string.IsNullOrEmpty(row.Groups[g]))
                                garment.GroupNames.Add(row.Groups[g]);
                        }
                    }

                    if (garment.GroupNames.Count > 0)
                        garment.GroupName = garment.GroupNames[0];
                    garments.Add(row.Pair, garment);
                    order.Add(row.Pair);
                }

                if (row.Line)
                    garment.Outlines.Add(player[i]);
                else
                    garment.Fills.Add(player[i]);
            }

            var list = new List<PsdGarment>(order.Count);
            for (int i = order.Count - 1; i >= 0; i--)
                list.Add(garments[order[i]]);
            return list;
        }

        /// <summary>
        /// 扁平导出常把每层写成整画布包围盒；对模板比对时改用透明度内容盒。
        /// </summary>
        public static void MatchBounds(PsdDocument doc, PsdLayerInfo layer, out int left, out int top, out int right, out int bottom)
        {
            left = layer != null ? layer.Left : 0;
            top = layer != null ? layer.Top : 0;
            right = layer != null ? layer.Right : 0;
            bottom = layer != null ? layer.Bottom : 0;
            if (doc == null || layer == null || !layer.HasPixels)
                return;
            if (layer.Left > 1 || layer.Top > 1
                || layer.Right < doc.Width - 1 || layer.Bottom < doc.Height - 1)
                return;

            byte[] rgba = doc.ReadRgba(layer);
            if (rgba == null)
                return;
            if (!PsdPixels.ContentBounds(rgba, layer.Width, layer.Height, out int x, out int y, out int contentRight, out int contentBottom))
            {
                left = top = right = bottom = 0;
                return;
            }

            left = layer.Left + x;
            top = layer.Top + y;
            right = layer.Left + contentRight;
            bottom = layer.Top + contentBottom;
        }

        public static bool TryLayerNumber(string name, out int number)
        {
            number = 0;
            if (string.IsNullOrEmpty(name))
                return false;
            int end = name.Length;
            while (end > 0 && char.IsWhiteSpace(name[end - 1]))
                end--;
            int start = end;
            while (start > 0 && name[start - 1] >= '0' && name[start - 1] <= '9')
                start--;
            if (start == end)
                return false;
            return int.TryParse(name.Substring(start, end - start), NumberStyles.Integer, CultureInfo.InvariantCulture, out number);
        }

        int FindRow(PsdDocument doc, PsdLayerInfo layer, HashSet<int> used)
        {
            if (layer == null || !TryLayerNumber(layer.Name, out int number))
                return -1;
            if (!byNumber.TryGetValue(number, out List<int> hits))
                return -1;

            int available = 0;
            int only = -1;
            for (int i = 0; i < hits.Count; i++)
            {
                int index = hits[i];
                if (used != null && used.Contains(index))
                    continue;
                available++;
                only = index;
            }

            if (available == 0)
                return -1;
            if (available == 1)
                return only;

            MatchBounds(doc, layer, out int left, out int top, out int right, out int bottom);
            int best = -1;
            int bestDist = int.MaxValue;
            for (int i = 0; i < hits.Count; i++)
            {
                int index = hits[i];
                if (used != null && used.Contains(index))
                    continue;
                TemplateRow row = Rows[index];
                int dist = Math.Abs(row.Left - left)
                    + Math.Abs(row.Top - top)
                    + Math.Abs(row.Right - right)
                    + Math.Abs(row.Bottom - bottom);
                if (dist < bestDist)
                {
                    bestDist = dist;
                    best = index;
                }
            }

            if (best < 0)
                return -1;
            if (bestDist <= 8)
                return best;
            return -1;
        }

        void Index()
        {
            byNumber.Clear();
            for (int i = 0; i < Rows.Count; i++)
            {
                int number = Rows[i].Number;
                if (!byNumber.TryGetValue(number, out List<int> hits))
                {
                    hits = new List<int>();
                    byNumber.Add(number, hits);
                }

                hits.Add(i);
            }
        }

        static void AddRows(TemplateSheet sheet, PsdDocument doc, List<PsdLayerInfo> layers, List<string> groups, bool line, int pair)
        {
            if (layers == null)
                return;
            var names = new List<string>();
            for (int i = 0; i < groups.Count; i++)
            {
                if (!string.IsNullOrEmpty(groups[i]))
                    names.Add(groups[i].Replace("|", "").Replace("\t", ""));
            }

            if (names.Count == 0)
                return;
            for (int i = 0; i < layers.Count; i++)
            {
                PsdLayerInfo layer = layers[i];
                if (!TryLayerNumber(layer.Name, out int number))
                    continue;
                sheet.Rows.Add(new TemplateRow
                {
                    Number = number,
                    Groups = names.ToArray(),
                    Line = line,
                    Pair = pair,
                    Left = layer.Left,
                    Top = layer.Top,
                    Right = layer.Right,
                    Bottom = layer.Bottom,
                    Fingerprint = Fingerprint(doc, layer)
                });
            }
        }

        static uint Mix(uint hash, uint value)
        {
            return (hash ^ value) * 16777619u;
        }
    }
}
