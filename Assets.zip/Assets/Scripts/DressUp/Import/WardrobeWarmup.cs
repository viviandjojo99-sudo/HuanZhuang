using System.Collections.Generic;
using DressUp.Data;
using UnityEngine;

namespace DressUp.Import
{
    /// <summary>
    /// 预热已关闭：改回用到再加载。空闲预热曾和随机抢主线程，色相模式也会被拖卡。
    /// 保留空壳 API，避免旧调用编译失败。
    /// </summary>
    public class WardrobeWarmup : MonoBehaviour
    {
        public static WardrobeWarmup Instance { get; private set; }

        public static WardrobeWarmup Ensure()
        {
            if (Instance != null)
                return Instance;
            ImportedWardrobe host = ImportedWardrobe.Ensure();
            Instance = host.GetComponent<WardrobeWarmup>();
            if (Instance == null)
                Instance = host.gameObject.AddComponent<WardrobeWarmup>();
            return Instance;
        }

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
                return;
            }

            Instance = this;
            // 清掉此前 sticky，恢复 LoadPage 可卸载。
            ImportedSave.ClearStickyResidents();
        }

        void OnDestroy()
        {
            if (Instance == this)
                Instance = null;
        }

        public static void WarmAfterImport(IList<ClothingItem> justImported = null)
        {
            // 已关闭，不再预热。
        }

        public void ScheduleIdleWarmup()
        {
            // 已关闭，不再预热。
        }
    }
}
