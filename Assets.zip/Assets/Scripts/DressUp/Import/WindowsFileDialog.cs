using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace DressUp.Import
{
    public static class WindowsFileDialog
    {
        const int Explorer = 0x00080000;
        const int FileMustExist = 0x00001000;
        const int PathMustExist = 0x00000800;
        const int NoChangeDir = 0x00000008;

        public static string OpenSingle(string title, string filter)
        {
            List<string> files = Open(title, filter, false);
            return files.Count > 0 ? files[0] : null;
        }

        public static List<string> Open(string title, string filter, bool multi)
        {
            var result = new List<string>();
            int size = 65536;
            IntPtr buffer = Marshal.AllocHGlobal(size * 2);
            try
            {
                for (int i = 0; i < size * 2; i++)
                    Marshal.WriteByte(buffer, i, 0);

                var ofn = new OpenFileName
                {
                    lStructSize = Marshal.SizeOf<OpenFileName>(),
                    hwndOwner = GetActiveWindow(),
                    lpstrFilter = filter,
                    lpstrFile = buffer,
                    nMaxFile = size,
                    lpstrTitle = title,
                    Flags = Explorer | FileMustExist | PathMustExist | NoChangeDir,
                    lpstrDefExt = "psd"
                };

                if (!GetOpenFileNameW(ref ofn))
                    return result;

                string packed = Marshal.PtrToStringUni(buffer) ?? "";
                if (!multi)
                {
                    if (packed.Length > 0)
                        result.Add(packed);
                    return result;
                }

                var parts = new List<string>();
                int index = 0;
                while (index < size)
                {
                    string piece = Marshal.PtrToStringUni(IntPtr.Add(buffer, index * 2));
                    if (string.IsNullOrEmpty(piece))
                        break;
                    parts.Add(piece);
                    index += piece.Length + 1;
                }

                if (parts.Count == 1)
                    result.Add(parts[0]);
                else if (parts.Count > 1)
                {
                    string dir = parts[0];
                    for (int i = 1; i < parts.Count; i++)
                        result.Add(System.IO.Path.Combine(dir, parts[i]));
                }
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }

            return result;
        }

        [DllImport("comdlg32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern bool GetOpenFileNameW(ref OpenFileName ofn);

        [DllImport("user32.dll")]
        static extern IntPtr GetActiveWindow();

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        struct OpenFileName
        {
            public int lStructSize;
            public IntPtr hwndOwner;
            public IntPtr hInstance;
            public string lpstrFilter;
            public string lpstrCustomFilter;
            public int nMaxCustFilter;
            public int nFilterIndex;
            public IntPtr lpstrFile;
            public int nMaxFile;
            public IntPtr lpstrFileTitle;
            public int nMaxFileTitle;
            public IntPtr lpstrInitialDir;
            public string lpstrTitle;
            public int Flags;
            public short nFileOffset;
            public short nFileExtension;
            public string lpstrDefExt;
            public IntPtr lCustData;
            public IntPtr lpfnHook;
            public string lpTemplateName;
            public IntPtr pvReserved;
            public int dwReserved;
            public int FlagsEx;
        }
    }
}
