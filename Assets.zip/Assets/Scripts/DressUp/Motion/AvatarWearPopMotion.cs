using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Motion
{
    /// <summary>
    /// 穿戴图层 pop：scale 1.2 → 1。
    /// 同一部件的 S/B 用 PlayGroup 共用一个弹簧，避免各弹各的撕缝，也比整层父节点（大画布）好看。
    /// </summary>
    public class AvatarWearPopMotion : MonoBehaviour
    {
        [SerializeField] float startScale = 1.2f;
        [SerializeField] float stiffness = 0.16f;
        [SerializeField] float damping = 0.78f;

        class PopState
        {
            public readonly List<RectTransform> Rects = new List<RectTransform>(4);
            public DressUpSpring Spring;
            public bool Animating;
            public int GroupId;
        }

        readonly Dictionary<int, PopState> groups = new Dictionary<int, PopState>();
        readonly Dictionary<RectTransform, int> rectToGroup = new Dictionary<RectTransform, int>();
        readonly List<int> removeBuffer = new List<int>();
        int nextGroupId = 1;

        public void Play(RectTransform layer)
        {
            if (layer == null)
                return;
            partScratch.Clear();
            partScratch.Add(layer);
            PlayGroup(partScratch);
        }

        public void Play(Transform layer)
        {
            if (layer is RectTransform rt)
                Play(rt);
            else if (layer != null)
                Play(layer.GetComponent<RectTransform>());
        }

        readonly List<RectTransform> partScratch = new List<RectTransform>(4);

        /// <summary>同一部件的多个零件（S+B）共用一个缩放弹簧。</summary>
        public void PlayGroup(List<RectTransform> rects)
        {
            if (rects == null || rects.Count == 0)
                return;

            // 清掉这些 Rect 上旧的独立/分组动画，避免叠两套 scale。
            for (int i = 0; i < rects.Count; i++)
            {
                RectTransform rt = rects[i];
                if (rt == null)
                    continue;
                if (rectToGroup.TryGetValue(rt, out int oldId) && groups.TryGetValue(oldId, out PopState old))
                {
                    DetachRect(old, rt);
                    if (old.Rects.Count == 0)
                        groups.Remove(oldId);
                }
            }

            int id = nextGroupId++;
            var state = new PopState
            {
                Spring = new DressUpSpring(startScale),
                Animating = true,
                GroupId = id
            };
            state.Spring.Value = startScale;
            state.Spring.Velocity = 0f;
            state.Spring.Target = 1f;

            Vector3 start = new Vector3(startScale, startScale, 1f);
            for (int i = 0; i < rects.Count; i++)
            {
                RectTransform rt = rects[i];
                if (rt == null)
                    continue;
                state.Rects.Add(rt);
                rectToGroup[rt] = id;
                rt.localScale = start;
            }

            if (state.Rects.Count == 0)
                return;
            groups[id] = state;
        }

        static void DetachRect(PopState state, RectTransform rt)
        {
            if (state == null || rt == null)
                return;
            for (int i = state.Rects.Count - 1; i >= 0; i--)
            {
                if (state.Rects[i] == rt)
                    state.Rects.RemoveAt(i);
            }

            rt.localScale = Vector3.one;
        }

        void Update()
        {
            if (groups.Count == 0)
                return;

            removeBuffer.Clear();
            foreach (KeyValuePair<int, PopState> pair in groups)
            {
                PopState state = pair.Value;
                if (state == null || !state.Animating || state.Rects.Count == 0)
                {
                    removeBuffer.Add(pair.Key);
                    continue;
                }

                state.Spring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);
                float s = state.Spring.Value;
                Vector3 scale = new Vector3(s, s, 1f);
                for (int i = state.Rects.Count - 1; i >= 0; i--)
                {
                    RectTransform rt = state.Rects[i];
                    if (rt == null)
                    {
                        state.Rects.RemoveAt(i);
                        continue;
                    }

                    rt.localScale = scale;
                }

                if (state.Rects.Count == 0 || state.Spring.IsSettledTight())
                {
                    for (int i = 0; i < state.Rects.Count; i++)
                    {
                        RectTransform rt = state.Rects[i];
                        if (rt != null)
                            rt.localScale = Vector3.one;
                    }

                    state.Animating = false;
                    removeBuffer.Add(pair.Key);
                }
            }

            for (int i = 0; i < removeBuffer.Count; i++)
            {
                int id = removeBuffer[i];
                if (!groups.TryGetValue(id, out PopState state))
                    continue;
                for (int r = 0; r < state.Rects.Count; r++)
                {
                    RectTransform rt = state.Rects[r];
                    if (rt != null)
                        rectToGroup.Remove(rt);
                }

                groups.Remove(id);
            }
        }
    }
}
