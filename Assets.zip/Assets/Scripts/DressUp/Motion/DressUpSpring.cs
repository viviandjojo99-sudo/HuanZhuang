namespace DressUp.Motion
{
    /// <summary>
    /// RMMZ WardrobeSpring 同款 1D 阻尼弹簧（按 60FPS 步进，与插件手感一致）。
    /// </summary>
    public class DressUpSpring
    {
        public const float ReferenceFps = 60f;

        public float Value;
        public float Velocity;
        public float Target;

        float accumulator;

        public DressUpSpring(float value = 0f)
        {
            Value = value;
            Target = value;
            Velocity = 0f;
        }

        public void Reset(float value)
        {
            Value = value;
            Target = value;
            Velocity = 0f;
            accumulator = 0f;
        }

        public void Update(float stiffness, float damping)
        {
            Velocity += (Target - Value) * stiffness;
            Velocity *= damping;
            Value += Velocity;
        }

        /// <summary>按真实时间换算成 60FPS 步数，避免高刷屏滑入过快。</summary>
        public void UpdateFixed60(float unscaledDeltaTime, float stiffness, float damping, int maxSteps = 5)
        {
            accumulator += unscaledDeltaTime;
            float step = 1f / ReferenceFps;
            int guard = maxSteps;
            while (accumulator >= step && guard-- > 0)
            {
                Update(stiffness, damping);
                accumulator -= step;
            }

            // 防止卡顿堆积导致一次跳太多
            if (accumulator > step * 2f)
                accumulator = 0f;
        }

        public bool IsSettled(float posEpsilon = 0.5f, float velEpsilon = 0.05f)
        {
            return System.Math.Abs(Target - Value) < posEpsilon
                   && System.Math.Abs(Velocity) < velEpsilon;
        }

        public bool IsSettledTight()
            => IsSettled(0.002f, 0.002f);
    }
}
