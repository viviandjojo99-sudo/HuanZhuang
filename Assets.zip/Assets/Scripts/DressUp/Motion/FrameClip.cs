using UnityEngine;

namespace DressUp.Motion
{
    /// <summary>一段逐帧动画。frames 顺序即播放顺序。</summary>
    [CreateAssetMenu(fileName = "FrameClip", menuName = "DressUp/Frame Clip")]
    public class FrameClip : ScriptableObject
    {
        [SerializeField] Sprite[] frames = System.Array.Empty<Sprite>();
        [SerializeField] float framesPerSecond = 8f;
        [SerializeField] bool loop;

        public Sprite[] Frames => frames;
        public float FramesPerSecond => Mathf.Max(0.01f, framesPerSecond);
        public bool Loop => loop;
        public int FrameCount => frames == null ? 0 : frames.Length;

        public Sprite GetFrame(int index)
        {
            if (frames == null || frames.Length == 0)
                return null;
            if (index < 0 || index >= frames.Length)
                return null;
            return frames[index];
        }

        public void AssignFrames(Sprite[] sprites, float fps, bool loopClip)
        {
            frames = sprites ?? System.Array.Empty<Sprite>();
            framesPerSecond = Mathf.Max(0.01f, fps);
            loop = loopClip;
        }
    }
}
