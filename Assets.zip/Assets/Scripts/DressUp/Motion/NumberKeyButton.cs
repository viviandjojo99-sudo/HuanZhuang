using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DressUp.Motion
{
    /// <summary>
    /// 按下时把高度收到 90。数字键松开还原。分类键松手不回弹。
    /// </summary>
    public class NumberKeyButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        const float PressedHeight = 90f;
        const float ContentDrop = 10f;

        RectTransform rect;
        Image[] images;
        Color[] restColors;
        RectTransform[] content;
        Vector2[] contentRest;
        float restHeight;
        bool down;
        bool stayDown;
        bool gray = true;
        bool shiftContent;
        NumberKeyButton[] group;

        void Awake()
        {
            rect = transform as RectTransform;
            restHeight = rect != null ? rect.sizeDelta.y : PressedHeight;
            images = GetComponentsInChildren<Image>(true);
            restColors = new Color[images.Length];
            for (int i = 0; i < images.Length; i++)
                restColors[i] = images[i] != null ? images[i].color : Color.white;
        }

        public void SetStayDown(bool value)
        {
            stayDown = value;
        }

        public void SetGray(bool value)
        {
            gray = value;
        }

        public void SetShiftContent(bool value)
        {
            shiftContent = value;
        }

        void Start()
        {
            CaptureContent();
        }

        public void SetGroup(NumberKeyButton[] peers)
        {
            group = peers;
        }

        public void Release()
        {
            down = false;
            SetHeight(restHeight);
            RestoreColor();
            RestoreContent();
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (stayDown && group != null)
            {
                for (int i = 0; i < group.Length; i++)
                {
                    if (group[i] != null && group[i] != this)
                        group[i].Release();
                }
            }

            down = true;
            SetHeight(PressedHeight);
            if (stayDown && gray)
                Gray();
            DropContent();
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            if (!down || stayDown)
                return;
            down = false;
            SetHeight(restHeight);
        }

        void OnDisable()
        {
            if (stayDown)
                return;
            down = false;
            SetHeight(restHeight);
        }

        void Gray()
        {
            if (images == null || restColors == null)
                return;
            int count = Mathf.Min(images.Length, restColors.Length);
            for (int i = 0; i < count; i++)
            {
                if (images[i] == null)
                    continue;
                Color color = restColors[i];
                color.r *= 0.55f;
                color.g *= 0.55f;
                color.b *= 0.55f;
                images[i].color = color;
            }
        }

        void RestoreColor()
        {
            if (images == null || restColors == null)
                return;
            int count = Mathf.Min(images.Length, restColors.Length);
            for (int i = 0; i < count; i++)
            {
                if (images[i] != null)
                    images[i].color = restColors[i];
            }
        }

        void CaptureContent()
        {
            int count = 0;
            for (int i = 0; i < transform.childCount; i++)
            {
                string name = transform.GetChild(i).name;
                if (name == "Icon" || name == "Text (TMP)")
                    count++;
            }

            content = new RectTransform[count];
            contentRest = new Vector2[count];
            int index = 0;
            for (int i = 0; i < transform.childCount; i++)
            {
                Transform child = transform.GetChild(i);
                if (child.name != "Icon" && child.name != "Text (TMP)")
                    continue;
                RectTransform childRect = child as RectTransform;
                if (childRect == null)
                    continue;
                content[index] = childRect;
                contentRest[index] = childRect.anchoredPosition;
                index++;
            }
        }

        void DropContent()
        {
            if (!shiftContent || content == null)
                return;
            for (int i = 0; i < content.Length; i++)
            {
                if (content[i] == null)
                    continue;
                Vector2 position = contentRest[i];
                position.y -= ContentDrop;
                content[i].anchoredPosition = position;
            }
        }

        void RestoreContent()
        {
            if (content == null)
                return;
            for (int i = 0; i < content.Length; i++)
            {
                if (content[i] != null)
                    content[i].anchoredPosition = contentRest[i];
            }
        }

        void SetHeight(float height)
        {
            if (rect == null)
                return;
            Vector2 size = rect.sizeDelta;
            size.y = height;
            rect.sizeDelta = size;
        }
    }
}
