using System;
using System.Collections.Generic;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Wardrobe;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace DressUp.Motion
{
    /// <summary>
    /// KEY：兑换码。数字不限位数，点键盘最后一个键提交。
    /// </summary>
    public class PasscodePrompt : MonoBehaviour
    {
        public const string ResourcePath = "DressUp/PasscodeConfig";
        const string NumberButtonRes = "Passcode/NumberButton";
        const string BarSpriteRes = "Passcode/Jindu";
        const string PadSpriteRes = "Passcode/Pad";
        const string FontPath = "Assets/Fonts/ChillRoundM SDF.asset";
        const string Placeholder = "请输入兑换码";
        static readonly Color PlaceholderColor = new Color(0.44f, 0.25f, 0.15f, 0.45f);
        static readonly Color DigitColor = new Color(0.44f, 0.25f, 0.15f, 1f);

        static readonly string[] KeyLabels =
        {
            "1", "2", "3",
            "4", "5", "6",
            "7", "8", "9",
            "←", "0", "√"
        };

        [SerializeField] PasscodeConfig config;

        GameObject dialog;
        TMP_Text label;
        Button keyButton;
        string code = "";
        bool open;

        public event Action Unlocked;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Ensure()
        {
            if (FindAnyObjectByType<PasscodePrompt>(FindObjectsInactive.Include) != null)
                return;
            new GameObject(nameof(PasscodePrompt)).AddComponent<PasscodePrompt>();
        }

        void Start()
        {
            if (config == null)
                config = Resources.Load<PasscodeConfig>(ResourcePath);

            ResolveUi();
            if (dialog == null || keyButton == null)
                BuildUiIfMissing();

            if (keyButton != null)
                keyButton.onClick.AddListener(Open);

            if (dialog == null)
            {
                Debug.LogWarning("[Passcode] 数字键盘创建失败。", this);
                return;
            }

            dialog.SetActive(false);
            Transform bar = dialog.transform.Find("Image");
            label = bar != null ? bar.GetComponentInChildren<TMP_Text>(true) : null;
            TMP_FontAsset font = LoadFont();
            if (label != null)
            {
                label.raycastTarget = false;
                if (font != null)
                    label.font = font;
            }

            WireKeys(dialog, font);
            ShowCode();
            if (dialog.GetComponent<DialogDimmer>() == null)
            {
                var dimmer = dialog.AddComponent<DialogDimmer>();
                dimmer.Prompt = this;
            }
        }

        void OnDestroy()
        {
            if (keyButton != null)
                keyButton.onClick.RemoveListener(Open);
        }

        void ResolveUi()
        {
            Transform[] all = FindObjectsByType<Transform>(FindObjectsInactive.Include);
            for (int i = 0; i < all.Length; i++)
            {
                if (all[i].name != "Key")
                    continue;
                Button button = all[i].GetComponent<Button>();
                if (button != null)
                {
                    keyButton = button;
                    continue;
                }

                dialog = all[i].gameObject;
            }
        }

        void BuildUiIfMissing()
        {
            Canvas canvas = FindAnyObjectByType<Canvas>();
            if (canvas == null)
                return;

            Sprite barSprite = Resources.Load<Sprite>(BarSpriteRes);
            Sprite padSprite = Resources.Load<Sprite>(PadSpriteRes);
            TMP_FontAsset font = LoadFont();
            GameObject numberPrefab = Resources.Load<GameObject>(NumberButtonRes);

            if (keyButton == null)
                keyButton = CreateKeyButton(canvas.transform, font);

            if (dialog == null)
                dialog = CreateDialog(canvas.transform, barSprite, padSprite, numberPrefab, font);
        }

        static Button CreateKeyButton(Transform parent, TMP_FontAsset font)
        {
            var go = new GameObject("Key", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.anchoredPosition = new Vector2(-40f, -40f);
            rt.sizeDelta = new Vector2(120f, 72f);

            Image image = go.GetComponent<Image>();
            image.color = new Color(0.96f, 0.78f, 0.55f, 1f);
            image.raycastTarget = true;
            Button button = go.GetComponent<Button>();
            button.targetGraphic = image;

            var textGo = new GameObject("Label", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textGo.transform.SetParent(go.transform, false);
            var tr = textGo.GetComponent<RectTransform>();
            tr.anchorMin = Vector2.zero;
            tr.anchorMax = Vector2.one;
            tr.offsetMin = Vector2.zero;
            tr.offsetMax = Vector2.zero;
            var tmp = textGo.GetComponent<TextMeshProUGUI>();
            tmp.text = "KEY";
            tmp.fontSize = 36;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.color = new Color(0.35f, 0.2f, 0.12f, 1f);
            tmp.raycastTarget = false;
            if (font != null)
                tmp.font = font;

            return button;
        }

        static GameObject CreateDialog(
            Transform canvas,
            Sprite barSprite,
            Sprite padSprite,
            GameObject numberPrefab,
            TMP_FontAsset font)
        {
            var dialog = new GameObject("Key", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            dialog.transform.SetParent(canvas, false);
            var dialogRt = dialog.GetComponent<RectTransform>();
            dialogRt.anchorMin = Vector2.zero;
            dialogRt.anchorMax = Vector2.one;
            dialogRt.offsetMin = Vector2.zero;
            dialogRt.offsetMax = Vector2.zero;

            Image dim = dialog.GetComponent<Image>();
            dim.color = new Color(0f, 0f, 0f, 0.7f);
            dim.raycastTarget = true;

            var bar = new GameObject("Image", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            bar.transform.SetParent(dialog.transform, false);
            var barRt = bar.GetComponent<RectTransform>();
            barRt.anchorMin = barRt.anchorMax = new Vector2(0.5f, 0.5f);
            barRt.anchoredPosition = new Vector2(0f, 296f);
            barRt.sizeDelta = new Vector2(460f, 80f);
            Image barImg = bar.GetComponent<Image>();
            barImg.sprite = barSprite;
            barImg.color = new Color(0.996f, 0.937f, 0.91f, 1f);

            var labelGo = new GameObject("Code", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            labelGo.transform.SetParent(bar.transform, false);
            var labelRt = labelGo.GetComponent<RectTransform>();
            labelRt.anchorMin = Vector2.zero;
            labelRt.anchorMax = Vector2.one;
            labelRt.offsetMin = new Vector2(24f, 8f);
            labelRt.offsetMax = new Vector2(-24f, -8f);
            var tmp = labelGo.GetComponent<TextMeshProUGUI>();
            tmp.text = "";
            tmp.fontSize = 48;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.color = DigitColor;
            tmp.raycastTarget = false;
            if (font != null)
                tmp.font = font;

            var pad = new GameObject("BG", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            pad.transform.SetParent(dialog.transform, false);
            var padRt = pad.GetComponent<RectTransform>();
            padRt.anchorMin = padRt.anchorMax = new Vector2(0.5f, 0.5f);
            padRt.anchoredPosition = new Vector2(0f, -63f);
            padRt.sizeDelta = new Vector2(460f, 545f);
            Image padImg = pad.GetComponent<Image>();
            padImg.sprite = padSprite;

            var grid = pad.AddComponent<GridLayoutGroup>();
            grid.cellSize = new Vector2(100f, 100f);
            grid.spacing = new Vector2(24f, 24f);
            grid.padding = new RectOffset(40, 40, 40, 40);
            grid.childAlignment = TextAnchor.MiddleCenter;
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = 3;

            for (int i = 0; i < KeyLabels.Length; i++)
            {
                GameObject btn = numberPrefab != null
                    ? Instantiate(numberPrefab, pad.transform)
                    : CreateFallbackNumberButton(pad.transform, KeyLabels[i], font);
                btn.name = i == 0 ? "NumberButton" : $"NumberButton ({i})";
                TMP_Text caption = btn.GetComponentInChildren<TMP_Text>(true);
                if (caption != null)
                {
                    caption.text = KeyLabels[i];
                    if (font != null)
                        caption.font = font;
                }
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(padRt);
            UnityEngine.Object.Destroy(grid);
            dialog.SetActive(false);
            return dialog;
        }

        static GameObject CreateFallbackNumberButton(Transform parent, string mark, TMP_FontAsset font)
        {
            var go = new GameObject("NumberButton", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            Image img = go.GetComponent<Image>();
            img.color = new Color(0.73f, 0.73f, 0.73f, 1f);
            go.GetComponent<Button>().targetGraphic = img;

            var textGo = new GameObject("Text", typeof(RectTransform), typeof(CanvasRenderer), typeof(TextMeshProUGUI));
            textGo.transform.SetParent(go.transform, false);
            var tr = textGo.GetComponent<RectTransform>();
            tr.anchorMin = Vector2.zero;
            tr.anchorMax = Vector2.one;
            tr.offsetMin = Vector2.zero;
            tr.offsetMax = Vector2.zero;
            var tmp = textGo.GetComponent<TextMeshProUGUI>();
            tmp.text = mark;
            tmp.fontSize = 50;
            tmp.alignment = TextAlignmentOptions.Center;
            tmp.color = new Color(0.44f, 0.25f, 0.15f, 1f);
            if (font != null)
                tmp.font = font;
            return go;
        }

        static TMP_FontAsset LoadFont()
        {
#if UNITY_EDITOR
            TMP_FontAsset editorFont = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(FontPath);
            if (editorFont != null)
                return editorFont;
#endif
            TMP_Text[] texts = FindObjectsByType<TMP_Text>(FindObjectsInactive.Include);
            for (int i = 0; i < texts.Length; i++)
            {
                if (texts[i] != null && texts[i].font != null
                    && texts[i].font.name.IndexOf("ChillRoundM", StringComparison.OrdinalIgnoreCase) >= 0)
                    return texts[i].font;
            }

            return TMP_Settings.defaultFontAsset;
        }

        public void Open()
        {
            if (dialog == null)
                return;
            open = true;
            code = "";
            ShowCode();
            dialog.SetActive(true);
            dialog.transform.SetAsLastSibling();
        }

        public void Close()
        {
            open = false;
            if (dialog != null)
                dialog.SetActive(false);
        }

        void WireKeys(GameObject root, TMP_FontAsset font)
        {
            Button[] buttons = root.GetComponentsInChildren<Button>(true);
            var keys = new List<Button>();
            for (int i = 0; i < buttons.Length; i++)
            {
                Button button = buttons[i];
                if (button == null || !button.name.StartsWith("NumberButton"))
                    continue;
                keys.Add(button);
            }

            keys.Sort((a, b) => a.transform.GetSiblingIndex().CompareTo(b.transform.GetSiblingIndex()));
            for (int i = 0; i < keys.Count; i++)
            {
                Button button = keys[i];
                GridLayoutGroup grid = button.GetComponentInParent<GridLayoutGroup>();
                if (grid != null)
                {
                    LayoutRebuilder.ForceRebuildLayoutImmediate(grid.GetComponent<RectTransform>());
                    Destroy(grid);
                }

                if (button.GetComponent<NumberKeyButton>() == null)
                    button.gameObject.AddComponent<NumberKeyButton>();

                TMP_Text caption = button.GetComponentInChildren<TMP_Text>(true);
                if (caption != null && font != null)
                    caption.font = font;
                string mark = caption != null ? caption.text.Trim() : "";
                bool submit = i == keys.Count - 1;
                button.onClick.AddListener(() => Press(mark, submit));
            }
        }

        void Press(string mark, bool submit)
        {
            if (!open)
                return;

            if (submit)
            {
                Commit();
                return;
            }

            if (mark == "←" || mark == "删" || mark == "删除")
            {
                if (code.Length > 0)
                    code = code.Substring(0, code.Length - 1);
                ShowCode();
                return;
            }

            if (mark.Length != 1 || !char.IsDigit(mark[0]))
                return;

            code += mark;
            ShowCode();
            DressUpAudio.Instance?.PlayPopup();
        }

        void Commit()
        {
            if (!open)
                return;
            if (config == null || !config.IsValid(code))
            {
                code = "";
                ShowCode();
                return;
            }

            string templateId = config.ResolveTemplateId(code);
            config.RememberUnlock(templateId);
            open = false;
            if (dialog != null)
                dialog.SetActive(false);

            ApplyTemplateUnlock(templateId);
            Unlocked?.Invoke();
        }

        void ApplyTemplateUnlock(string templateId)
        {
            ActiveAvatarBinder binder = FindAnyObjectByType<ActiveAvatarBinder>();
            if (binder != null)
                binder.SelectByTemplateId(templateId);
            else
                FindAnyObjectByType<WardrobeController>()?.RebuildPlots();
        }

        void ShowCode()
        {
            if (label == null)
                return;
            if (string.IsNullOrEmpty(code))
            {
                label.text = Placeholder;
                label.color = PlaceholderColor;
                return;
            }

            label.text = code;
            label.color = DigitColor;
        }

        class DialogDimmer : MonoBehaviour, IPointerClickHandler
        {
            public PasscodePrompt Prompt;

            public void OnPointerClick(PointerEventData eventData)
            {
                if (eventData.pointerPressRaycast.gameObject == gameObject)
                    Prompt?.Close();
            }
        }
    }
}
