using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace DressUp.Motion
{
    /// <summary>
    /// 全场景星星闪烁（Art/SY HuanZhaung 帧），参考 project2 CareStarSparkles。
    /// 随机时间/位置/大小；颜色只在黑（明度最低）与白（明度最高）之间随机。
    /// </summary>
    public class StarSparkles : MonoBehaviour
    {
        const string ClipResourcePath = "DressUp/StarSparkle";
        const string ArtFolder = "Assets/Art/SY";
        const int PoolSize = 3;
        const float MaxSize = 100f;
        const float MinSize = 36f;
        const float SpawnIntervalMin = 0.35f;
        const float SpawnIntervalMax = 1.1f;
        const float FramesPerSecond = 15f;

        static readonly Color[] StarTints =
        {
            Color.white,
            Color.black,
        };

        static StarSparkles instance;

        FrameClip clip;
        RectTransform root;
        readonly List<StarSlot> pool = new List<StarSlot>(PoolSize);
        bool running;
        Coroutine loop;

        class StarSlot
        {
            public GameObject Go;
            public RectTransform Rect;
            public Image Image;
            public UiFramePlayer Player;
            public bool Busy;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (FindAnyObjectByType<StarSparkles>(FindObjectsInactive.Include) != null)
                return;
            new GameObject(nameof(StarSparkles)).AddComponent<StarSparkles>();
        }

        void Awake()
        {
            instance = this;
            clip = Resources.Load<FrameClip>(ClipResourcePath);
#if UNITY_EDITOR
            if (clip == null || clip.FrameCount == 0)
                clip = BuildClipFromArtFolder();
#endif
        }

        void Start() => Begin();

        public static void StartSparkles()
        {
            if (instance == null)
                return;
            instance.Begin();
        }

        public static void StopSparkles()
        {
            if (instance == null)
                return;
            instance.End();
        }

        void Begin()
        {
            if (clip == null || clip.FrameCount == 0)
            {
                Debug.LogWarning("[StarSparkles] 缺少帧动画 Resources/DressUp/StarSparkle，或 Art/SY/HuanZhaung*。", this);
                return;
            }

            EnsurePool();
            running = true;
            if (root != null)
            {
                root.gameObject.SetActive(true);
                root.SetAsLastSibling();
            }

            if (loop != null)
                StopCoroutine(loop);
            loop = StartCoroutine(SpawnLoop());
        }

        void End()
        {
            running = false;
            if (loop != null)
            {
                StopCoroutine(loop);
                loop = null;
            }

            for (int i = 0; i < pool.Count; i++)
            {
                StarSlot s = pool[i];
                s.Busy = false;
                s.Player?.Stop(true);
                if (s.Go != null)
                    s.Go.SetActive(false);
            }
        }

        IEnumerator SpawnLoop()
        {
            while (running)
            {
                int busy = CountBusy();
                int want = Random.Range(2, 4);
                while (busy < want && running)
                {
                    if (!TrySpawnOne())
                        break;
                    busy++;
                    yield return new WaitForSecondsRealtime(Random.Range(0.05f, 0.2f));
                }

                yield return new WaitForSecondsRealtime(Random.Range(SpawnIntervalMin, SpawnIntervalMax));
            }
        }

        bool TrySpawnOne()
        {
            StarSlot slot = null;
            for (int i = 0; i < pool.Count; i++)
            {
                if (!pool[i].Busy)
                {
                    slot = pool[i];
                    break;
                }
            }

            if (slot == null || clip == null || root == null)
                return false;

            float size = Random.Range(MinSize, MaxSize);
            float x = Random.Range(-480f, 480f);
            float y = Random.Range(-860f, 860f);

            slot.Busy = true;
            slot.Go.SetActive(true);
            slot.Rect.SetAsLastSibling();
            slot.Rect.anchoredPosition = new Vector2(x, y);
            slot.Rect.sizeDelta = new Vector2(size, size);
            slot.Rect.localScale = Vector3.one;
            slot.Image.preserveAspect = true;
            slot.Image.raycastTarget = false;
            slot.Image.color = StarTints[Random.Range(0, StarTints.Length)];

            StarSlot captured = slot;
            slot.Player.Play(clip, () =>
            {
                captured.Busy = false;
                captured.Player.Stop(true);
                if (captured.Go != null)
                    captured.Go.SetActive(false);
            }, false);

            return true;
        }

        int CountBusy()
        {
            int n = 0;
            for (int i = 0; i < pool.Count; i++)
            {
                if (pool[i].Busy)
                    n++;
            }

            return n;
        }

        void EnsurePool()
        {
            if (root != null && pool.Count == PoolSize)
            {
                root.gameObject.SetActive(true);
                return;
            }

            Transform parent = GameObject.Find("Canvas")?.transform;
            if (parent == null)
                parent = transform;

            GameObject rootGo = new GameObject("StarSparkles", typeof(RectTransform));
            root = rootGo.transform as RectTransform;
            root.SetParent(parent, false);
            root.anchorMin = new Vector2(0.5f, 0.5f);
            root.anchorMax = new Vector2(0.5f, 0.5f);
            root.pivot = new Vector2(0.5f, 0.5f);
            root.anchoredPosition = Vector2.zero;
            root.sizeDelta = new Vector2(1080f, 1920f);
            root.SetAsLastSibling();

            pool.Clear();
            for (int i = 0; i < PoolSize; i++)
            {
                GameObject go = new GameObject($"Star_{i}", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
                RectTransform rt = go.transform as RectTransform;
                rt.SetParent(root, false);
                rt.anchorMin = new Vector2(0.5f, 0.5f);
                rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.pivot = new Vector2(0.5f, 0.5f);

                Image img = go.GetComponent<Image>();
                img.raycastTarget = false;
                img.preserveAspect = true;

                UiFramePlayer player = go.AddComponent<UiFramePlayer>();
                go.SetActive(false);

                pool.Add(new StarSlot
                {
                    Go = go,
                    Rect = rt,
                    Image = img,
                    Player = player,
                });
            }
        }

#if UNITY_EDITOR
        /// <summary>编辑器下从 Art/SY 的 HuanZhaung* 倒序拼一段 clip（对齐 project2 17→1）。</summary>
        static FrameClip BuildClipFromArtFolder()
        {
            string[] guids = AssetDatabase.FindAssets("HuanZhaung t:Texture2D", new[] { ArtFolder });
            var numbered = new List<(int num, Sprite sprite)>();
            for (int i = 0; i < guids.Length; i++)
            {
                string path = AssetDatabase.GUIDToAssetPath(guids[i]);
                string name = System.IO.Path.GetFileNameWithoutExtension(path);
                if (!name.StartsWith("HuanZhaung", System.StringComparison.OrdinalIgnoreCase))
                    continue;

                string digits = name.Substring("HuanZhaung".Length);
                if (!int.TryParse(digits, out int num))
                    continue;

                EnsureSpriteSingle(path);
                Sprite sprite = LoadLargestSprite(path);
                if (sprite != null)
                    numbered.Add((num, sprite));
            }

            if (numbered.Count == 0)
                return null;

            numbered.Sort((a, b) => b.num.CompareTo(a.num)); // 大→小，倒放
            var frames = new Sprite[numbered.Count];
            for (int i = 0; i < numbered.Count; i++)
                frames[i] = numbered[i].sprite;

            FrameClip runtime = ScriptableObject.CreateInstance<FrameClip>();
            runtime.AssignFrames(frames, FramesPerSecond, false);
            return runtime;
        }

        static void EnsureSpriteSingle(string path)
        {
            TextureImporter importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null)
                return;

            bool changed = false;
            if (importer.textureType != TextureImporterType.Sprite)
            {
                importer.textureType = TextureImporterType.Sprite;
                changed = true;
            }

            if (importer.spriteImportMode != SpriteImportMode.Single)
            {
                importer.spriteImportMode = SpriteImportMode.Single;
                changed = true;
            }

            if (changed)
                importer.SaveAndReimport();
        }

        static Sprite LoadLargestSprite(string path)
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(path);
            Sprite best = null;
            float bestArea = -1f;
            for (int i = 0; i < assets.Length; i++)
            {
                Sprite sprite = assets[i] as Sprite;
                if (sprite == null)
                    continue;
                float area = sprite.rect.width * sprite.rect.height;
                if (area > bestArea)
                {
                    best = sprite;
                    bestArea = area;
                }
            }

            return best;
        }
#endif
    }
}
