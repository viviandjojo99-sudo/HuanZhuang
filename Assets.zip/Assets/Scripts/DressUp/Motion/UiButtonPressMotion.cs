using UnityEngine;
using UnityEngine.EventSystems;

namespace DressUp.Motion
{
    /// <summary>
    /// RMMZ 按压弹簧。颜色请用 Button/Toggle 的 Color Tint 在 Inspector 配，这里只做缩放。
    /// 停稳后不再每帧改 scale，避免衣柜格子拖垮 Canvas。
    /// </summary>
    public class UiButtonPressMotion : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        [SerializeField] Transform scaleTarget;
        [SerializeField] float pressScale = 0.9f;
        [SerializeField] float stiffness = 0.35f;
        [SerializeField] float damping = 0.72f;

        readonly DressUpSpring spring = new DressUpSpring(1f);
        bool pressed;
        bool animating;

        void Awake()
        {
            if (scaleTarget == null)
                scaleTarget = transform;
            spring.Reset(1f);
            animating = false;
        }

        void OnEnable()
        {
            if (scaleTarget == null)
                scaleTarget = transform;
        }

        void Update()
        {
            if (!animating && !pressed)
                return;

            spring.Target = pressed ? pressScale : 1f;
            spring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);
            if (scaleTarget == null)
                return;

            float s = spring.Value;
            scaleTarget.localScale = new Vector3(s, s, 1f);

            if (!pressed && spring.IsSettledTight())
            {
                spring.Reset(1f);
                scaleTarget.localScale = Vector3.one;
                animating = false;
            }
        }

        /// <summary>代码触发一次按压缩放（如 S0 清空）。</summary>
        public void Pulse()
        {
            animating = true;
            spring.Value = pressScale;
            spring.Velocity = 0f;
            spring.Target = pressed ? pressScale : 1f;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            pressed = true;
            animating = true;
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            pressed = false;
            animating = true;
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            pressed = false;
            animating = true;
        }
    }
}
