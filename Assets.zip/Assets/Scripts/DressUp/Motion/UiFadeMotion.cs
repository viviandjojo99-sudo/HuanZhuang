using System.Collections;
using UnityEngine;

namespace DressUp.Motion
{
    /// <summary>
    /// CanvasGroup 线性淡入淡出（约 12 帧 / 0.2s）。
    /// </summary>
    public class UiFadeMotion : MonoBehaviour
    {
        [SerializeField] CanvasGroup canvasGroup;
        [SerializeField] float duration = 0.2f;
        [SerializeField] bool startHidden;

        Coroutine anim;
        bool visible;
        bool snappedByOwner;

        public bool IsVisible => visible;
        public CanvasGroup Group => canvasGroup;

        public float Duration
        {
            get => duration;
            set => duration = Mathf.Max(0.01f, value);
        }

        void Awake()
        {
            EnsureGroup();
            if (snappedByOwner)
                return;
            if (startHidden)
                SnapHidden();
            else
                SnapShown();
        }

        public void SetCanvasGroup(CanvasGroup group)
        {
            canvasGroup = group;
            EnsureGroup();
        }

        public void FadeIn()
        {
            EnsureGroup();
            StopAnim();
            visible = true;
            canvasGroup.blocksRaycasts = true;
            canvasGroup.interactable = true;
            if (!isActiveAndEnabled || !gameObject.activeInHierarchy)
            {
                canvasGroup.alpha = 1f;
                return;
            }

            StartFade(1f);
        }

        public void FadeOut()
        {
            EnsureGroup();
            StopAnim();
            visible = false;
            // 一开始就关掉交互，避免淡出过程中还能拖 BAR
            canvasGroup.blocksRaycasts = false;
            canvasGroup.interactable = false;
            StartFade(0f);
        }

        public void SnapShown()
        {
            EnsureGroup();
            StopAnim();
            snappedByOwner = true;
            visible = true;
            canvasGroup.alpha = 1f;
            canvasGroup.blocksRaycasts = true;
            canvasGroup.interactable = true;
        }

        public void SnapHidden()
        {
            EnsureGroup();
            StopAnim();
            snappedByOwner = true;
            visible = false;
            canvasGroup.alpha = 0f;
            canvasGroup.blocksRaycasts = false;
            canvasGroup.interactable = false;
        }

        void StartFade(float target)
        {
            StopAnim();
            if (!isActiveAndEnabled)
            {
                canvasGroup.alpha = target;
                if (target <= 0.01f)
                {
                    canvasGroup.blocksRaycasts = false;
                    canvasGroup.interactable = false;
                }
                return;
            }

            anim = StartCoroutine(FadeRoutine(target));
        }

        IEnumerator FadeRoutine(float target)
        {
            float from = canvasGroup.alpha;
            float t = 0f;
            float dur = Mathf.Max(0.01f, duration);
            while (t < dur)
            {
                t += Time.unscaledDeltaTime;
                canvasGroup.alpha = Mathf.Lerp(from, target, Mathf.Clamp01(t / dur));
                yield return null;
            }

            canvasGroup.alpha = target;
            if (target <= 0.01f)
            {
                canvasGroup.blocksRaycasts = false;
                canvasGroup.interactable = false;
            }

            anim = null;
        }

        void StopAnim()
        {
            if (anim == null)
                return;
            StopCoroutine(anim);
            anim = null;
        }

        void EnsureGroup()
        {
            if (canvasGroup == null)
                canvasGroup = GetComponent<CanvasGroup>();
            if (canvasGroup == null)
                canvasGroup = gameObject.AddComponent<CanvasGroup>();
        }
    }
}
