using System;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Motion
{
    /// <summary>在 UI Image 上按 FrameClip 换图。</summary>
    public class UiFramePlayer : MonoBehaviour
    {
        [SerializeField] Image target;
        [SerializeField] FrameClip clip;

        Action finished;
        int index;
        float timer;
        bool playing;
        bool loopOverride;
        bool useLoopOverride;

        public bool IsPlaying => playing;

        void Awake()
        {
            if (target == null)
                target = GetComponent<Image>();
            HideImage();
        }

        public void Play(FrameClip next, Action onFinished, bool? loop)
        {
            if (next != null)
                clip = next;

            useLoopOverride = loop.HasValue;
            loopOverride = loop ?? false;
            finished = onFinished;
            index = 0;
            timer = 0f;
            playing = clip != null && clip.FrameCount > 0;
            Apply(0);

            if (!playing)
                InvokeFinished();
        }

        bool ShouldLoop => useLoopOverride ? loopOverride : (clip != null && clip.Loop);

        public void Stop(bool clearSprite)
        {
            playing = false;
            finished = null;
            if (clearSprite)
                HideImage();
        }

        void Update()
        {
            if (!playing || clip == null)
                return;

            timer += Time.unscaledDeltaTime;
            float frameTime = 1f / clip.FramesPerSecond;
            while (playing && timer >= frameTime)
            {
                timer -= frameTime;
                index++;
                if (index >= clip.FrameCount)
                {
                    if (ShouldLoop)
                    {
                        index = 0;
                    }
                    else
                    {
                        index = clip.FrameCount - 1;
                        Apply(index);
                        playing = false;
                        InvokeFinished();
                        return;
                    }
                }

                Apply(index);
            }
        }

        void Apply(int frameIndex)
        {
            if (target == null)
                target = GetComponent<Image>();
            if (target == null || clip == null)
                return;

            Sprite sprite = clip.GetFrame(frameIndex);
            if (sprite == null)
            {
                HideImage();
                return;
            }

            target.sprite = sprite;
            Color c = target.color;
            c.a = 1f;
            target.color = c;
            target.enabled = true;
        }

        void HideImage()
        {
            if (target == null)
                target = GetComponent<Image>();
            if (target == null)
                return;
            target.sprite = null;
            Color c = target.color;
            c.a = 0f;
            target.color = c;
            target.enabled = false;
        }

        void InvokeFinished()
        {
            Action callback = finished;
            finished = null;
            callback?.Invoke();
        }
    }
}
