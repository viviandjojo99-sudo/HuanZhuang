using UnityEngine;

namespace DressUp.Motion
{
    public enum UiSlideFrom
    {
        Left = 0,
        Right = 1
    }

    /// <summary>
    /// 水平弹簧滑入 / 滑出。刚度 0.2、阻尼 0.7：较快到位，只轻弹一下。
    /// 可用距离偏移，或指定关闭时的绝对 anchored X（如 Maleta 关闭停在 -420）。
    /// 停稳后不再每帧写 anchoredPosition。
    /// </summary>
    public class UiSlideMotion : MonoBehaviour
    {
        [SerializeField] RectTransform target;
        [SerializeField] UiSlideFrom slideFrom = UiSlideFrom.Left;
        [SerializeField] float slideDistance = 280f;
        [SerializeField] bool useAbsoluteClosedX;
        [SerializeField] float closedAnchoredX = -420f;
        [SerializeField] float stiffness = 0.2f;
        [SerializeField] float damping = 0.7f;

        readonly DressUpSpring spring = new DressUpSpring();
        Vector2 restAnchored;
        bool restCaptured;
        bool animating;
        float lastApplied = float.NaN;

        public float SlideDistance
        {
            get => slideDistance;
            set => slideDistance = Mathf.Max(0f, value);
        }

        public UiSlideFrom SlideFrom
        {
            get => slideFrom;
            set => slideFrom = value;
        }

        public bool UseAbsoluteClosedX
        {
            get => useAbsoluteClosedX;
            set => useAbsoluteClosedX = value;
        }

        public float ClosedAnchoredX
        {
            get => closedAnchoredX;
            set => closedAnchoredX = value;
        }

        float ClosedOffset
        {
            get
            {
                if (useAbsoluteClosedX)
                    return closedAnchoredX - restAnchored.x;
                return slideFrom == UiSlideFrom.Right ? slideDistance : -slideDistance;
            }
        }

        void Awake()
        {
            if (target == null)
                target = transform as RectTransform;
        }

        public void SetTarget(RectTransform rect) => target = rect;

        public void CaptureRestFromCurrent()
        {
            if (target == null)
                target = transform as RectTransform;
            if (target == null)
                return;

            restAnchored = target.anchoredPosition;
            restCaptured = true;
        }

        public void Open()
        {
            EnsureRest();
            spring.Target = 0f;
            animating = true;
        }

        public void Close()
        {
            EnsureRest();
            spring.Target = ClosedOffset;
            animating = true;
        }

        public void SnapOpen()
        {
            EnsureRest();
            spring.Reset(0f);
            animating = false;
            lastApplied = float.NaN;
            Apply(0f);
            lastApplied = 0f;
        }

        public void SnapClosed()
        {
            EnsureRest();
            float closed = ClosedOffset;
            spring.Reset(closed);
            animating = false;
            lastApplied = float.NaN;
            Apply(closed);
            lastApplied = closed;
        }

        void Update()
        {
            if (target == null || !restCaptured || !animating)
                return;

            if (!spring.IsSettled())
                spring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);

            float offset = VisualOffset(spring.Value);
            if (!float.IsNaN(lastApplied) && Mathf.Abs(lastApplied - offset) < 0.01f && spring.IsSettled())
            {
                spring.Reset(spring.Target);
                offset = VisualOffset(spring.Value);
                Apply(offset);
                lastApplied = offset;
                animating = false;
                return;
            }

            Apply(offset);
            lastApplied = offset;
        }

        void EnsureRest()
        {
            if (!restCaptured)
                CaptureRestFromCurrent();
        }

        /// <summary>
        /// 弹簧仍按原来的软度越过展开点。显示时把超过 0 的那段翻到左边，X 不会大于展开位置。
        /// </summary>
        float VisualOffset(float offset)
        {
            if (useAbsoluteClosedX && closedAnchoredX < restAnchored.x && offset > 0f)
                return -offset;
            return offset;
        }

        void Apply(float offsetX)
        {
            if (target == null)
                return;
            Vector2 p = restAnchored;
            p.x = restAnchored.x + offsetX;
            target.anchoredPosition = p;
        }
    }
}
