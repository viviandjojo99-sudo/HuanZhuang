using System;
using System.Collections;
using System.Collections.Generic;
using DressUp.Wardrobe;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Motion
{
    /// <summary>
    /// Tag 列整体水平滑动 + 子项从上往下错峰。
    /// 展开停在 shownX（默认 100），收起停在 hiddenX（默认 0）。
    /// TagA 收起：100→0（往左）；TagB 展开：0→100（往右）。
    /// </summary>
    [DisallowMultipleComponent]
    public class UiTagColumnStaggerMotion : MonoBehaviour
    {
        [SerializeField] float shownX = 100f;
        [SerializeField] float hiddenX = 0f;
        [SerializeField] float staggerDelay = 0.04f;
        [SerializeField] float stiffness = 0.28f;
        [SerializeField] float damping = 0.72f;
        [SerializeField] float childNudge = 24f;

        readonly DressUpSpring rootSpring = new DressUpSpring();
        readonly List<ChildSlot> children = new List<ChildSlot>();
        RectTransform root;
        LayoutGroup layoutGroup;
        bool layoutWasEnabled = true;
        Coroutine running;
        bool shown = true;
        bool driving;
        float rootY;

        sealed class ChildSlot
        {
            public RectTransform Rt;
            public CanvasGroup Group;
            public UiTagSelectMotion SelectMotion;
            public readonly DressUpSpring Spring = new DressUpSpring();
            public float RestLocalX;
        }

        public bool IsShown => shown;

        public float StaggerDelay
        {
            get => staggerDelay;
            set => staggerDelay = Mathf.Max(0f, value);
        }

        /// <summary>兼容旧字段：距离 = |shownX - hiddenX|。</summary>
        public float SlideDistance
        {
            get => Mathf.Abs(shownX - hiddenX);
            set
            {
                float d = Mathf.Max(0f, value);
                if (shownX >= hiddenX)
                    hiddenX = shownX - d;
                else
                    hiddenX = shownX + d;
            }
        }

        public float ShownX
        {
            get => shownX;
            set => shownX = value;
        }

        public float HiddenX
        {
            get => hiddenX;
            set => hiddenX = value;
        }

        void Awake()
        {
            root = transform as RectTransform;
            layoutGroup = GetComponent<LayoutGroup>();
            if (root != null)
                rootY = root.anchoredPosition.y;
        }

        public void RebuildSlots()
        {
            children.Clear();
            for (int i = 0; i < transform.childCount; i++)
            {
                var rt = transform.GetChild(i) as RectTransform;
                if (rt == null || !rt.gameObject.activeSelf)
                    continue;

                var slot = new ChildSlot { Rt = rt };
                slot.Group = rt.GetComponent<CanvasGroup>() ?? rt.gameObject.AddComponent<CanvasGroup>();
                slot.SelectMotion = rt.GetComponent<UiTagSelectMotion>();
                slot.RestLocalX = rt.anchoredPosition.x;
                children.Add(slot);
            }
        }

        public void SnapShown()
        {
            StopRunning();
            EnsureRoot();
            gameObject.SetActive(true);
            RebuildSlots();
            driving = false;
            shown = true;
            rootSpring.Reset(shownX);
            ApplyRoot(shownX);
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                c.Spring.Reset(0f);
                ApplyChild(c, 0f);
                SetChildInteractable(c, true);
                SetSelectEnabled(c, true);
            }
        }

        public void SnapHidden()
        {
            StopRunning();
            EnsureRoot();
            RebuildSlots();
            driving = false;
            shown = false;
            rootSpring.Reset(hiddenX);
            ApplyRoot(hiddenX);
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                c.Spring.Reset(0f);
                ApplyChild(c, 0f);
                SetChildInteractable(c, false);
                SetSelectEnabled(c, false);
            }
        }

        public void PlayHide(Action onComplete = null)
        {
            StopRunning();
            EnsureRoot();
            gameObject.SetActive(true);
            SetLayoutEnabled(true);
            Canvas.ForceUpdateCanvases();
            RebuildSlots();
            CaptureChildRest();
            SetLayoutEnabled(false);
            driving = true;
            shown = false;
            SetAllSelectEnabled(false);
            rootSpring.Reset(root.anchoredPosition.x);
            rootSpring.Target = hiddenX;
            running = StartCoroutine(CoStagger(hide: true, onComplete));
        }

        public void PlayShow(Action onComplete = null)
        {
            StopRunning();
            EnsureRoot();
            gameObject.SetActive(true);
            SetLayoutEnabled(true);
            Canvas.ForceUpdateCanvases();
            RebuildSlots();
            CaptureChildRest();
            SetLayoutEnabled(false);
            driving = true;
            shown = true;
            SetAllSelectEnabled(false);

            ApplyRoot(hiddenX);
            rootSpring.Reset(hiddenX);
            rootSpring.Target = shownX;

            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                // 从左侧一点挪到布局位，配合列往右弹
                c.Spring.Reset(-childNudge);
                ApplyChild(c, -childNudge);
                SetChildInteractable(c, false);
            }

            running = StartCoroutine(CoStagger(hide: false, onComplete));
        }

        IEnumerator CoStagger(bool hide, Action onComplete)
        {
            float childTarget = 0f;
            float childStart = hide ? 0f : -childNudge;

            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                if (c.Rt == null || !c.Rt.gameObject.activeSelf)
                    continue;

                if (hide)
                {
                    c.Spring.Reset(0f);
                    // 往左错开一点再跟列一起收
                    c.Spring.Target = -childNudge;
                }
                else
                {
                    c.Spring.Reset(childStart);
                    c.Spring.Target = childTarget;
                    SetChildInteractable(c, true);
                }

                if (staggerDelay > 0f)
                    yield return new WaitForSecondsRealtime(staggerDelay);
            }

            float guard = 1.0f;
            while (guard > 0f && (!rootSpring.IsSettled(1f, 0.08f) || !ChildrenSettled()))
            {
                guard -= Time.unscaledDeltaTime;
                yield return null;
            }

            rootSpring.Reset(hide ? hiddenX : shownX);
            ApplyRoot(rootSpring.Value);
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                c.Spring.Reset(0f);
                ApplyChild(c, 0f);
                SetChildInteractable(c, !hide);
                SetSelectEnabled(c, !hide);
            }

            driving = false;
            shown = !hide;
            if (hide)
                gameObject.SetActive(false);
            else
                SetLayoutEnabled(true);

            running = null;
            onComplete?.Invoke();
        }

        void SetLayoutEnabled(bool on)
        {
            if (layoutGroup == null)
                layoutGroup = GetComponent<LayoutGroup>();
            if (layoutGroup == null)
                return;
            if (on)
                layoutGroup.enabled = layoutWasEnabled;
            else
            {
                layoutWasEnabled = layoutGroup.enabled;
                layoutGroup.enabled = false;
            }
        }

        void Update()
        {
            if (!driving || root == null)
                return;

            rootSpring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                if (c.Rt == null || !c.Rt.gameObject.activeInHierarchy)
                    continue;
                if (!c.Spring.IsSettled())
                    c.Spring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);
            }
        }

        void LateUpdate()
        {
            if (!driving || root == null)
                return;

            ApplyRoot(rootSpring.Value);
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                if (c.Rt == null || !c.Rt.gameObject.activeInHierarchy)
                    continue;
                ApplyChild(c, c.Spring.Value);
            }
        }

        void CaptureChildRest()
        {
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                if (c.Rt != null)
                    c.RestLocalX = c.Rt.anchoredPosition.x;
            }
        }

        void EnsureRoot()
        {
            if (root == null)
                root = transform as RectTransform;
            if (root != null)
                rootY = root.anchoredPosition.y;
        }

        void ApplyRoot(float x)
        {
            if (root == null)
                return;
            Vector2 p = root.anchoredPosition;
            p.x = x;
            p.y = rootY;
            root.anchoredPosition = p;
        }

        static void ApplyChild(ChildSlot c, float nudgeX)
        {
            if (c.Rt == null)
                return;
            Vector2 p = c.Rt.anchoredPosition;
            p.x = c.RestLocalX + nudgeX;
            c.Rt.anchoredPosition = p;
        }

        bool ChildrenSettled()
        {
            for (int i = 0; i < children.Count; i++)
            {
                ChildSlot c = children[i];
                if (c.Rt == null || !c.Rt.gameObject.activeSelf)
                    continue;
                if (!c.Spring.IsSettled(1f, 0.08f))
                    return false;
            }

            return true;
        }

        void StopRunning()
        {
            if (running == null)
                return;
            StopCoroutine(running);
            running = null;
        }

        void SetAllSelectEnabled(bool on)
        {
            for (int i = 0; i < children.Count; i++)
                SetSelectEnabled(children[i], on);
        }

        static void SetChildInteractable(ChildSlot c, bool on)
        {
            if (c.Group != null)
                c.Group.blocksRaycasts = on;
        }

        static void SetSelectEnabled(ChildSlot c, bool on)
        {
            if (c == null)
                return;
            if (c.SelectMotion == null && c.Rt != null)
                c.SelectMotion = c.Rt.GetComponent<UiTagSelectMotion>();
            if (c.SelectMotion == null)
                return;
            if (!on)
                c.SelectMotion.SetSelected(false);
            c.SelectMotion.enabled = on;
        }
    }
}
