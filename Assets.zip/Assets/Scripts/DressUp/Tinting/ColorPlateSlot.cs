using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Tinting
{
    /// <summary>
    /// 只点 Plate。
    /// 空：三个色点从 BAR Handle 中心飞入 COLOR，然后 COLOR 变成该色。
    /// 已存：三个色点从 COLOR 飞到三根 Handle 该去的位置，然后 BAR 和衣服变成该色，COLOR 变白。
    /// 淡入淡出跟着父级 ChangeColor。
    /// </summary>
    public class ColorPlateSlot : MonoBehaviour
    {
        static readonly Color EmptyColor = Color.white;
        static Sprite dotSprite;

        [SerializeField] Button plateButton;
        [SerializeField] Image colorSwatch;
        [SerializeField] LayerColorController bars;
        [SerializeField] float flyDuration = 0.42f;

        bool hasColor;
        bool flying;
        readonly List<Scrollbar> barList = new List<Scrollbar>(3);

        void Awake()
        {
            CanvasGroup ownGroup = GetComponent<CanvasGroup>();
            if (ownGroup != null)
                Destroy(ownGroup);

            if (colorSwatch == null)
                colorSwatch = FindSwatch();

            if (colorSwatch != null)
            {
                colorSwatch.raycastTarget = false;
                colorSwatch.color = EmptyColor;
                Button swatchButton = colorSwatch.GetComponent<Button>();
                if (swatchButton != null)
                    Destroy(swatchButton);
            }

            if (plateButton == null)
                plateButton = GetComponent<Button>();
            if (plateButton == null)
                plateButton = gameObject.AddComponent<Button>();

            Image plateImage = GetComponent<Image>();
            if (plateImage != null)
            {
                plateImage.color = Color.white;
                plateButton.targetGraphic = plateImage;
            }

            plateButton.transition = Selectable.Transition.None;
            ColorBlock colors = plateButton.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = Color.white;
            colors.pressedColor = Color.white;
            colors.selectedColor = Color.white;
            colors.disabledColor = Color.white;
            colors.colorMultiplier = 1f;
            plateButton.colors = colors;
            plateButton.onClick.AddListener(OnPlateClicked);

            if (bars == null)
                bars = FindAnyObjectByType<LayerColorController>();

            hasColor = false;
        }

        void OnDestroy()
        {
            if (plateButton != null)
                plateButton.onClick.RemoveListener(OnPlateClicked);
        }

        Image FindSwatch()
        {
            Transform named = transform.Find("COLOR");
            if (named != null)
            {
                Image namedImage = named.GetComponent<Image>();
                if (namedImage != null)
                    return namedImage;
            }

            Image[] images = GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
            {
                if (images[i] != null && images[i].gameObject != gameObject)
                    return images[i];
            }

            return null;
        }

        void OnPlateClicked()
        {
            if (flying)
                return;

            if (bars == null)
                bars = FindAnyObjectByType<LayerColorController>();
            if (bars == null || colorSwatch == null)
                return;

            bars.CollectBars(barList);
            if (barList.Count == 0)
                return;

            if (!hasColor)
                StartCoroutine(StoreRoutine());
            else
                StartCoroutine(ApplyRoutine());
        }

        IEnumerator StoreRoutine()
        {
            flying = true;
            Color stored = bars.BarColor;
            stored.a = 1f;

            Vector3 swatch = colorSwatch.rectTransform.TransformPoint(colorSwatch.rectTransform.rect.center);
            var from = new Vector3[barList.Count];
            var to = new Vector3[barList.Count];
            for (int i = 0; i < barList.Count; i++)
            {
                from[i] = LayerColorController.HandleCenter(barList[i]);
                to[i] = swatch;
            }

            yield return FlyDots(from, to, stored);
            colorSwatch.color = stored;
            hasColor = true;
            flying = false;
        }

        IEnumerator ApplyRoutine()
        {
            flying = true;
            Color stored = colorSwatch.color;
            stored.a = 1f;
            Color.RGBToHSV(stored, out float h, out float s, out float v);
            float[] values = { h, s, v };

            Vector3 swatch = colorSwatch.rectTransform.TransformPoint(colorSwatch.rectTransform.rect.center);
            var from = new Vector3[barList.Count];
            var to = new Vector3[barList.Count];
            for (int i = 0; i < barList.Count; i++)
            {
                from[i] = swatch;
                float value = i < values.Length ? values[i] : barList[i].value;
                to[i] = LayerColorController.PredictHandleCenter(barList[i], value);
            }

            colorSwatch.color = EmptyColor;
            yield return FlyDots(from, to, stored);
            bars.SetBarColor(stored);
            hasColor = false;
            flying = false;
        }

        IEnumerator FlyDots(Vector3[] fromWorld, Vector3[] toWorld, Color color)
        {
            Canvas canvas = colorSwatch.canvas;
            if (canvas == null)
                yield break;

            RectTransform layer = canvas.rootCanvas.transform as RectTransform;
            Camera cam = canvas.rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay
                ? null
                : canvas.rootCanvas.worldCamera;

            int count = Mathf.Min(fromWorld.Length, toWorld.Length);
            var dots = new RectTransform[count];
            var from = new Vector2[count];
            var to = new Vector2[count];
            for (int i = 0; i < count; i++)
            {
                from[i] = WorldToLocal(layer, cam, fromWorld[i]);
                to[i] = WorldToLocal(layer, cam, toWorld[i]);
                dots[i] = CreateDot(layer, color);
                dots[i].anchoredPosition = from[i];
            }

            float duration = Mathf.Max(0.05f, flyDuration);
            float t = 0f;
            while (t < duration)
            {
                t += Time.unscaledDeltaTime;
                float u = Mathf.Clamp01(t / duration);
                float eased = u * u * (3f - 2f * u);
                for (int i = 0; i < count; i++)
                {
                    Vector2 a = from[i];
                    Vector2 b = to[i];
                    Vector2 dir = b - a;
                    Vector2 side = dir.sqrMagnitude > 0.01f
                        ? new Vector2(-dir.y, dir.x).normalized
                        : Vector2.up;
                    float arc = Mathf.Sin(eased * Mathf.PI) * (18f + i * 10f);
                    dots[i].anchoredPosition = Vector2.Lerp(a, b, eased) + side * arc;
                }

                yield return null;
            }

            for (int i = 0; i < count; i++)
            {
                if (dots[i] != null)
                    Destroy(dots[i].gameObject);
            }
        }

        static Vector2 WorldToLocal(RectTransform layer, Camera cam, Vector3 world)
        {
            Vector2 screen = RectTransformUtility.WorldToScreenPoint(cam, world);
            RectTransformUtility.ScreenPointToLocalPointInRectangle(layer, screen, cam, out Vector2 local);
            return local;
        }

        static RectTransform CreateDot(RectTransform parent, Color color)
        {
            var go = new GameObject("ColorDot", typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            go.transform.SetAsLastSibling();
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.sizeDelta = new Vector2(22f, 22f);
            Image image = go.GetComponent<Image>();
            image.sprite = DotSprite();
            image.color = color;
            image.raycastTarget = false;
            return rect;
        }

        static Sprite DotSprite()
        {
            if (dotSprite != null)
                return dotSprite;

            const int size = 32;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            float radius = size * 0.5f;
            var pixels = new Color[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dist = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(radius, radius));
                    float alpha = Mathf.Clamp01(radius - 1.2f - dist);
                    pixels[y * size + x] = new Color(1f, 1f, 1f, alpha);
                }
            }

            tex.SetPixels(pixels);
            tex.Apply();
            dotSprite = Sprite.Create(tex, new Rect(0f, 0f, size, size), new Vector2(0.5f, 0.5f), size);
            return dotSprite;
        }
    }
}
