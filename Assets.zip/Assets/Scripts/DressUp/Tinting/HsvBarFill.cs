using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Tinting
{
    /// <summary>沿滑条长度写下渐变位置。横条用宽度，竖条用高度。</summary>
    [RequireComponent(typeof(Image))]
    public class HsvBarFill : BaseMeshEffect
    {
        public override void ModifyMesh(VertexHelper vh)
        {
            if (!IsActive() || vh.currentVertCount == 0)
                return;

            Rect rect = graphic.rectTransform.rect;
            bool horizontal = rect.width >= rect.height;
            float span = horizontal ? rect.width : rect.height;
            if (span < 1f)
                return;

            var vert = new UIVertex();
            for (int i = 0; i < vh.currentVertCount; i++)
            {
                vh.PopulateUIVertex(ref vert, i);
                float along = horizontal ? vert.position.x - rect.xMin : vert.position.y - rect.yMin;
                vert.uv1 = new Vector4(Mathf.Clamp01(along / span), 0f, 0f, 0f);
                vh.SetUIVertex(vert, i);
            }
        }
    }
}
