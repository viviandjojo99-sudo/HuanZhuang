using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Tinting
{
    /// <summary>
    /// Scrollbar 保存时会把 Handle 锚点改成轨道百分比，像素尺寸会叠上去被撑飞。
    /// 这里在它改完之后把锚点收成一个点，尺寸锁回指定像素。
    /// </summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    public class PinnedBarHandle : MonoBehaviour
    {
        public Vector2 size = new Vector2(80f, 80f);
        public Vector2 offset;

        RectTransform rect;
        Scrollbar bar;
        bool applying;
        bool queued;

        void OnEnable() => Apply();

        void LateUpdate() => Apply();

        void OnValidate()
        {
#if UNITY_EDITOR
            if (queued)
                return;
            queued = true;
            UnityEditor.EditorApplication.delayCall += () =>
            {
                queued = false;
                if (this != null)
                    Apply();
            };
#else
            Apply();
#endif
        }

        public void Apply()
        {
            if (applying)
                return;
            if (rect == null)
                rect = transform as RectTransform;
            if (rect == null)
                return;
            if (bar == null)
                bar = GetComponentInParent<Scrollbar>();
            if (bar == null || bar.handleRect != rect)
                return;

            float portion = Mathf.Clamp(bar.size, 0f, 0.99f);
            float span = Mathf.Max(0.0001f, 1f - portion);
            bool vertical = bar.direction == Scrollbar.Direction.BottomToTop
                || bar.direction == Scrollbar.Direction.TopToBottom;
            bool reverse = bar.direction == Scrollbar.Direction.RightToLeft
                || bar.direction == Scrollbar.Direction.TopToBottom;
            float value = reverse ? 1f - bar.value : bar.value;
            float center = Mathf.Clamp01(value * span + portion * 0.5f);
            Vector2 anchor = vertical ? new Vector2(0.5f, center) : new Vector2(center, 0.5f);

            applying = true;
            rect.anchorMin = anchor;
            rect.anchorMax = anchor;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.sizeDelta = size;
            rect.anchoredPosition = offset;
            if (rect.localScale.z == 0f)
                rect.localScale = new Vector3(rect.localScale.x, rect.localScale.y, 1f);
            applying = false;
        }

#if UNITY_EDITOR
        [UnityEditor.InitializeOnLoadMethod]
        static void KeepSizeOnSave()
        {
            UnityEditor.SceneManagement.EditorSceneManager.sceneSaving -= BeforeSave;
            UnityEditor.SceneManagement.EditorSceneManager.sceneSaving += BeforeSave;
        }

        static void BeforeSave(UnityEngine.SceneManagement.Scene scene, string path)
        {
            PinnedBarHandle[] pins = Object.FindObjectsByType<PinnedBarHandle>(
                FindObjectsInactive.Include, FindObjectsSortMode.None);
            for (int i = 0; i < pins.Length; i++)
            {
                if (pins[i] != null)
                    pins[i].Apply();
            }
        }
#endif
    }
}
