using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Tinting
{
    /// <summary>
    /// Image.color 只能把图画到原色。再往上的明度用这个提亮，把像素往白色靠。
    /// 按 lift/曲线档位共用材质，避免每张 Image 一份 Material 打散合批。
    /// </summary>
    public static class SpriteBrighten
    {
        const string ShaderName = "DressUp/UI-Lift";
        const int LiftSteps = 40;

        static readonly Dictionary<int, Material> Shared = new Dictionary<int, Material>();
        static Shader cachedShader;

        public static void Set(Image image, float lift)
        {
            int mode = TintStyle.Curve ? TintStyle.CurveMode : TintStyle.Hue;
            Set(image, lift, mode, TintStyle.GradKind, TintStyle.GradientEnd);
        }

        public static void Set(Image image, float lift, bool curve)
        {
            Set(image, lift, curve ? TintStyle.CurveMode : TintStyle.Hue, TintStyle.GradNone, Color.white);
        }

        public static void Set(Image image, float lift, int mode, int grad, Color gradEnd, bool keepValue = false)
        {
            if (image == null)
                return;

            mode = mode == TintStyle.CurveMode ? TintStyle.CurveMode : TintStyle.Hue;
            grad = Mathf.Clamp(grad, TintStyle.GradNone, TintStyle.GradVertical);
            bool plain = mode == TintStyle.Hue && grad == TintStyle.GradNone && !keepValue;
            if (!image.TryGetComponent(out LiftMaterial link))
            {
                if (plain && lift <= 0.001f)
                    return;
                link = image.gameObject.AddComponent<LiftMaterial>();
            }

            if (plain && lift <= 0.001f)
            {
                link.Clear();
                return;
            }

            link.Apply(lift, mode, grad, gradEnd, keepValue);
        }

        public static float Get(Image image)
        {
            if (image == null)
                return 0f;
            return image.TryGetComponent(out LiftMaterial link) ? link.Lift : 0f;
        }

        static Material SharedMaterial(float lift, int mode, int grad, Color gradEnd, bool keepValue)
        {
            int step = Mathf.Clamp(Mathf.RoundToInt(Mathf.Clamp01(lift) * LiftSteps), 0, LiftSteps);
            int key = mode * 41 + step;
            key = key * 5 + grad;
            key = key * 2 + (keepValue ? 1 : 0);

            if (grad != TintStyle.GradNone)
            {
                unchecked
                {
                    key = (key * 397) ^ ColorKey(gradEnd);
                }
            }

            if (Shared.TryGetValue(key, out Material existing) && existing != null)
                return existing;

            if (cachedShader == null)
            {
                cachedShader = Resources.Load<Shader>("DressUp/UI-Lift");
                if (cachedShader == null)
                    cachedShader = Shader.Find(ShaderName);
            }

            if (cachedShader == null)
            {
                Debug.LogWarning("[SpriteBrighten] 找不到 DressUp/UI-Lift。");
                return null;
            }

            var material = new Material(cachedShader) { hideFlags = HideFlags.HideAndDontSave };
            material.SetFloat("_Lift", step / (float)LiftSteps);
            material.SetFloat("_Curve", mode == TintStyle.CurveMode ? 1f : 0f);
            material.SetFloat("_Grad", grad);
            material.SetFloat("_KeepValue", keepValue ? 1f : 0f);
            material.SetFloat("_TintMode", mode);
            if (grad != TintStyle.GradNone)
                material.SetColor("_GradEnd", gradEnd);
            Shared[key] = material;
            return material;
        }

        static int StepOf(float lift) =>
            Mathf.Clamp(Mathf.RoundToInt(Mathf.Clamp01(lift) * LiftSteps), 0, LiftSteps);

        static int ColorKey(Color color)
        {
            return (Mathf.RoundToInt(color.r * 255f) << 16)
                | (Mathf.RoundToInt(color.g * 255f) << 8)
                | Mathf.RoundToInt(color.b * 255f);
        }

        static bool SameColor(Color a, Color b)
        {
            return Mathf.Abs(a.r - b.r) < 0.004f
                && Mathf.Abs(a.g - b.g) < 0.004f
                && Mathf.Abs(a.b - b.b) < 0.004f;
        }

        sealed class LiftMaterial : MonoBehaviour
        {
            Image image;
            float lift;
            int mode = -1;
            int step = -1;
            int grad = -1;
            Color gradEnd;

            public float Lift => lift;

            void Awake() => image = GetComponent<Image>();

            int keepValue = -1;
            int styleStamp = -1;

            public void Apply(float value, int nextMode, int nextGrad, Color end, bool nextKeepValue)
            {
                float next = Mathf.Clamp01(value);
                int nextStep = StepOf(next);

                bool sameGrad = nextGrad == TintStyle.GradNone
                    ? grad == TintStyle.GradNone
                    : grad == nextGrad && SameColor(gradEnd, end);
                int keep = nextKeepValue ? 1 : 0;
                int stamp = TintStyle.MaterialStamp();
                if (mode == nextMode && step == nextStep && sameGrad
                    && keepValue == keep
                    && styleStamp == stamp
                    && image != null && image.material != null)
                {
                    lift = next;
                    return;
                }

                lift = next;
                mode = nextMode;
                step = nextStep;
                grad = nextGrad;
                gradEnd = end;
                keepValue = keep;
                styleStamp = stamp;
                if (image == null)
                    image = GetComponent<Image>();
                if (image == null)
                    return;

                Material material = SharedMaterial(lift, mode, grad, gradEnd, keepValue == 1);
                if (material == null)
                    return;
                if (image.material != material)
                    image.material = material;
            }

            public void Clear()
            {
                lift = 0f;
                mode = TintStyle.Hue;
                step = -1;
                grad = TintStyle.GradNone;
                gradEnd = Color.white;
                keepValue = -1;
                styleStamp = -1;
                if (image == null)
                    image = GetComponent<Image>();
                if (image != null)
                    image.material = null;
            }
        }
    }

    /// <summary>0 色相，1 曲线。渐变：0 关，1 明暗，2 上下。</summary>
    public static class TintStyle
    {
        public const int Hue = 0;
        public const int CurveMode = 1;
        public const int GradNone = 0;
        public const int GradLuma = 1;
        public const int GradVertical = 2;
        public const int EditStart = 0;
        public const int EditEnd = 1;
        public const string Key = "DressUp.TintCurve";
        const string StartKey = "DressUp.GradStart";
        const string EndKey = "DressUp.GradEnd";
        const string EditKey = "DressUp.GradEditEnd";
        const string KindKey = "DressUp.GradKind";
        const string OriginalKey = "DressUp.GradOriginal";

        static int cached = -1;
        static int gradKind = -1;
        static int editingEnd = -1;
        static bool colorsLoaded;
        static bool holdingOriginal;
        static bool originalChecked;
        static Color gradientStart;
        static Color gradientEnd;

        public static event System.Action Changed;

        public static int MaterialStamp()
        {
            return Mode;
        }

        public static int Mode
        {
            get
            {
                EnsureMode();
                return cached;
            }
        }

        public static bool Curve => Mode == CurveMode;

        public static int GradKind
        {
            get
            {
                EnsureGrad();
                return gradKind;
            }
        }

        public static bool TwoColor => GradKind != GradNone;

        /// <summary>渐变已打开，但色点还停在原色，先不改图。</summary>
        public static bool GradientAtOriginal
        {
            get
            {
                EnsureOriginal();
                return TwoColor && holdingOriginal;
            }
        }

        public static int EditPoint
        {
            get
            {
                if (editingEnd < 0)
                    editingEnd = PlayerPrefs.GetInt(EditKey, EditStart) == EditEnd ? EditEnd : EditStart;
                return editingEnd;
            }
            set
            {
                int next = value == EditEnd ? EditEnd : EditStart;
                if (editingEnd == next)
                    return;
                editingEnd = next;
                PlayerPrefs.SetInt(EditKey, next);
                Changed?.Invoke();
            }
        }

        public static bool EditingEnd
        {
            get => EditPoint == EditEnd;
            set => EditPoint = value ? EditEnd : EditStart;
        }

        public static Color GradientStart
        {
            get
            {
                EnsureColors();
                return gradientStart;
            }
        }

        public static Color GradientEnd
        {
            get
            {
                EnsureColors();
                return gradientEnd;
            }
        }

        public static void SetCurve(bool curve) => SetMode(curve ? CurveMode : Hue);

        public static void SetMode(int mode)
        {
            mode = mode == CurveMode ? CurveMode : Hue;
            EnsureMode();
            if (cached == mode)
                return;
            cached = mode;
            PlayerPrefs.SetInt(Key, cached);
            PlayerPrefs.Save();
            Changed?.Invoke();
        }

        public static void SetGradKind(int kind)
        {
            kind = Mathf.Clamp(kind, GradNone, GradVertical);
            EnsureGrad();
            if (gradKind == kind)
                return;
            gradKind = kind;
            PlayerPrefs.SetInt(KindKey, gradKind);
            PlayerPrefs.Save();
            Changed?.Invoke();
        }

        public static void HoldOriginal() => SetOriginalHeld(true);

        public static void ReleaseOriginal() => SetOriginalHeld(false);

        /// <summary>记下当前衣服颜色当原色，仍然先不铺渐变。</summary>
        public static void RememberOriginalColor(Color color)
        {
            SetOriginalHeld(true);
            SetGradient(color, color, false, true);
        }

        public static void SetGradientStart(Color color) => SetGradient(color, GradientEnd, false);

        public static void SetGradientEnd(Color color) => SetGradient(GradientStart, color, true);

        public static void SetGradientPair(Color start, Color end) => SetGradient(start, end, true);

        /// <summary>清除按钮用：关掉曲线和双色，起止色回到白。</summary>
        public static void ClearTintSettings()
        {
            EnsureMode();
            EnsureGrad();
            EnsureColors();
            bool changed = cached != Hue || gradKind != GradNone || editingEnd != EditStart
                || !Approximately(gradientStart, Color.white)
                || !Approximately(gradientEnd, Color.white);
            cached = Hue;
            gradKind = GradNone;
            editingEnd = EditStart;
            gradientStart = Color.white;
            gradientEnd = Color.white;
            SetOriginalHeld(false);
            PlayerPrefs.SetInt(Key, Hue);
            PlayerPrefs.SetInt(KindKey, GradNone);
            PlayerPrefs.SetInt(EditKey, EditStart);
            SaveColor(StartKey, Color.white);
            SaveColor(EndKey, Color.white);
            PlayerPrefs.Save();
            if (changed)
                Changed?.Invoke();
        }

        static void SetGradient(Color start, Color end, bool keepEditingEnd, bool keepOriginal = false)
        {
            EnsureColors();
            start.a = 1f;
            end.a = 1f;
            bool same = Approximately(gradientStart, start) && Approximately(gradientEnd, end);
            gradientStart = start;
            gradientEnd = end;
            if (!keepOriginal)
                SetOriginalHeld(false);
            SaveColor(StartKey, start);
            SaveColor(EndKey, end);
            if (!keepEditingEnd && editingEnd != EditStart)
            {
                editingEnd = EditStart;
                PlayerPrefs.SetInt(EditKey, EditStart);
            }

            if (!same)
                Changed?.Invoke();
        }

        static void EnsureMode()
        {
            if (cached >= 0)
                return;
            cached = PlayerPrefs.GetInt(Key, Hue) == CurveMode ? CurveMode : Hue;
        }

        static void EnsureGrad()
        {
            if (gradKind >= 0)
                return;
            gradKind = Mathf.Clamp(PlayerPrefs.GetInt(KindKey, GradNone), GradNone, GradVertical);
        }

        static void EnsureOriginal()
        {
            if (originalChecked)
                return;
            originalChecked = true;
            EnsureColors();
            if (PlayerPrefs.HasKey(OriginalKey))
                holdingOriginal = PlayerPrefs.GetInt(OriginalKey, 0) == 1;
            else
                holdingOriginal = IsNearWhite(gradientStart);
        }

        static void SetOriginalHeld(bool held)
        {
            EnsureOriginal();
            holdingOriginal = held;
            PlayerPrefs.SetInt(OriginalKey, held ? 1 : 0);
        }

        static bool IsNearWhite(Color color)
        {
            return color.r > 0.96f && color.g > 0.96f && color.b > 0.96f;
        }

        static void EnsureColors()
        {
            if (colorsLoaded)
                return;
            colorsLoaded = true;
            if (!TryLoadColor(StartKey, out gradientStart))
                gradientStart = Color.HSVToRGB(0.02f, 0.65f, 0.95f);
            if (!TryLoadColor(EndKey, out gradientEnd))
                gradientEnd = Color.HSVToRGB(0.55f, 0.55f, 1f);
            gradientStart.a = 1f;
            gradientEnd.a = 1f;
        }

        static bool Approximately(Color a, Color b)
        {
            return Mathf.Abs(a.r - b.r) < 0.004f
                && Mathf.Abs(a.g - b.g) < 0.004f
                && Mathf.Abs(a.b - b.b) < 0.004f;
        }

        static void SaveColor(string key, Color color)
        {
            int pack = (Mathf.RoundToInt(color.r * 255f) << 16)
                | (Mathf.RoundToInt(color.g * 255f) << 8)
                | Mathf.RoundToInt(color.b * 255f);
            PlayerPrefs.SetInt(key, pack);
        }

        static bool TryLoadColor(string key, out Color color)
        {
            color = Color.white;
            if (!PlayerPrefs.HasKey(key))
                return false;
            int pack = PlayerPrefs.GetInt(key, 0);
            color = new Color(((pack >> 16) & 255) / 255f, ((pack >> 8) & 255) / 255f, (pack & 255) / 255f, 1f);
            return true;
        }
    }
}
