using System;
using System.Collections;
using DressUp.Audio;
using DressUp.Data;
using DressUp.Motion;
using DressUp.Tinting;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// 穿着显示 Select，未穿关掉。缩略图保持导入原色，不跟身上染色。
    /// Button 保持 None，避免 Color Tint 改格子底图。
    /// </summary>
    public class ClothingPlotView : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
    {
        const float DefaultPicSize = 160f;

        [SerializeField] Image picImage;
        [SerializeField] Image plotImage;
        [SerializeField] Button button;
        [SerializeField] GameObject selectMark;

        Vector2 prefabPicSize = new Vector2(DefaultPicSize, DefaultPicSize);
        bool capturedPrefabSize;

        const float HoldSeconds = 1.4f;

        ClothingItem item;
        bool isEmptySlot;
        bool holding;
        bool armed;
        bool deleting;
        bool swallowRelease;
        float holdStart;
        Action<ClothingItem> onItemClicked;
        Action onEmptyClicked;
        Action<ClothingItem> onDeleted;
        UiButtonPressMotion pressMotion;
        GameObject deleteObject;
        RectTransform deleteRect;
        Vector2 deleteRestPosition;
        Vector3 deleteRestScale = Vector3.one;
        bool deleteRestCaptured;
        static ClothingPlotView armedView;

        public ClothingItem Item => item;
        public bool IsEmptySlot => isEmptySlot;

        void Awake() => EnsureRefs();

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(HandleClick);
        }

        public void Bind(ClothingItem clothingItem, Action<ClothingItem> clicked, bool zoomThumbnail = true, float thumbScale = 0.65f, Action<ClothingItem> deleted = null)
        {
            EnsureRefs();
            isEmptySlot = false;
            item = clothingItem;
            onItemClicked = clicked;
            onEmptyClicked = null;
            onDeleted = deleted;
            Calm();

            if (picImage == null)
                return;

            Sprite source = clothingItem != null ? clothingItem.sprite : null;
            picImage.sprite = zoomThumbnail && source != null
                ? SpriteThumbnailUtil.GetZoomedContentSprite(source)
                : source;
            picImage.enabled = picImage.sprite != null;
            picImage.preserveAspect = true;
            picImage.raycastTarget = false;

            if (button != null)
                button.interactable = true;
            if (pressMotion != null)
                pressMotion.enabled = true;

            ApplyPicLayout(Mathf.Clamp(thumbScale, 0.2f, 1f));
            SetWorn(false);
            ShowImportLook();
        }

        public void BindEmpty(Action cleared)
        {
            EnsureRefs();
            isEmptySlot = true;
            item = null;
            onItemClicked = null;
            onEmptyClicked = cleared;

            if (picImage != null)
                picImage.raycastTarget = false;
            onDeleted = null;
            Calm();

            if (button != null)
                button.interactable = true;
            if (pressMotion != null)
                pressMotion.enabled = true;

            ApplyPicLayout(1f);
            SetWorn(false);
        }

        /// <summary>穿着显示 Select。可同时有多件穿着。</summary>
        public void SetWorn(bool worn)
        {
            EnsureRefs();

            if (selectMark == null)
            {
                Transform mark = transform.Find("Select");
                if (mark != null)
                    selectMark = mark.gameObject;
            }

            if (selectMark != null)
                selectMark.SetActive(worn && !isEmptySlot);
        }

        /// <summary>衣柜缩略图保持导入原样，不跟身上染色，少挂提亮材质。</summary>
        public void ShowImportLook()
        {
            EnsureRefs();
            if (picImage == null)
                return;
            picImage.color = Color.white;
            SpriteBrighten.Set(picImage, 0f, TintStyle.Hue, TintStyle.GradNone, Color.white);
        }

        public void PlayClickFeedback() => pressMotion?.Pulse();

        public void OnPointerDown(PointerEventData eventData)
        {
            if (deleting || isEmptySlot || item == null || eventData.button != PointerEventData.InputButton.Left)
                return;
            holding = true;
            holdStart = Time.unscaledTime;
        }

        public void OnPointerUp(PointerEventData eventData) => holding = false;

        public void OnPointerExit(PointerEventData eventData)
        {
            if (!armed)
                holding = false;
        }

        void Update()
        {
            if (!holding && !armed)
                return;

            if (holding && !armed && !deleting && Time.unscaledTime - holdStart >= HoldSeconds)
                Arm();

            if (!armed || deleting)
                return;

            float wave = Mathf.Sin(Time.unscaledTime * 28f);
            float angle = wave * 4.5f;
            float scale = 1f + Mathf.Sin(Time.unscaledTime * 18f) * 0.025f;
            transform.localRotation = Quaternion.Euler(0f, 0f, angle);
            transform.localScale = new Vector3(scale, scale, 1f);
            HoldDeleteStill(angle, scale);
        }

        void HoldDeleteStill(float angle, float scale)
        {
            if (deleteRect == null)
                return;

            float safe = Mathf.Max(0.01f, scale);
            Quaternion upright = Quaternion.Euler(0f, 0f, -angle);
            deleteRect.localRotation = upright;
            deleteRect.localScale = new Vector3(deleteRestScale.x / safe, deleteRestScale.y / safe, deleteRestScale.z);
            Vector3 home = new Vector3(deleteRestPosition.x / safe, deleteRestPosition.y / safe, 0f);
            deleteRect.anchoredPosition = upright * home;
        }

        void OnDisable()
        {
            if (!deleting)
                Calm();
        }

        void ApplyPicLayout(float scale)
        {
            if (picImage == null)
                return;

            RectTransform rt = picImage.rectTransform;
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = prefabPicSize;
            rt.localScale = new Vector3(scale, scale, 1f);
        }

        void HandleClick()
        {
            if (deleting)
                return;
            if (swallowRelease)
            {
                swallowRelease = false;
                return;
            }

            if (armed)
            {
                Calm();
                return;
            }

            if (isEmptySlot)
                onEmptyClicked?.Invoke();
            else if (item != null)
                onItemClicked?.Invoke(item);
        }

        void Arm()
        {
            holding = false;
            if (armedView != null && armedView != this)
                armedView.Calm();

            armed = true;
            swallowRelease = true;
            armedView = this;
            if (pressMotion != null)
                pressMotion.enabled = false;
            transform.localScale = Vector3.one;
            if (deleteObject != null)
                deleteObject.SetActive(true);
        }

        void Calm()
        {
            holding = false;
            armed = false;
            swallowRelease = false;
            if (armedView == this)
                armedView = null;
            if (deleteObject != null)
                deleteObject.SetActive(false);
            transform.localRotation = Quaternion.identity;
            transform.localScale = Vector3.one;
            if (deleteRect != null)
            {
                deleteRect.localRotation = Quaternion.identity;
                deleteRect.localScale = deleteRestScale;
                deleteRect.anchoredPosition = deleteRestPosition;
            }
            if (pressMotion != null && !deleting)
                pressMotion.enabled = true;
        }

        void DeleteClicked()
        {
            if (deleting || isEmptySlot || item == null)
                return;

            deleting = true;
            holding = false;
            armed = false;
            if (armedView == this)
                armedView = null;
            if (deleteObject != null)
                deleteObject.SetActive(false);
            if (button != null)
                button.interactable = false;
            if (pressMotion != null)
                pressMotion.enabled = false;
            DressUpAudio.Instance?.PlayDelete();
            onDeleted?.Invoke(item);
            StartCoroutine(PopAway());
        }

        IEnumerator PopAway()
        {
            var springX = new DressUpSpring(1f);
            var springY = new DressUpSpring(1f);
            springX.Target = 1.16f;
            springY.Target = 0.82f;
            float time = 0f;
            while (time < 0.11f)
            {
                time += Time.unscaledDeltaTime;
                springX.UpdateFixed60(Time.unscaledDeltaTime, 0.62f, 0.55f);
                springY.UpdateFixed60(Time.unscaledDeltaTime, 0.62f, 0.55f);
                transform.localScale = new Vector3(springX.Value, springY.Value, 1f);
                yield return null;
            }

            springX.Target = 0.82f;
            springY.Target = 1.18f;
            springX.Velocity = -2f;
            springY.Velocity = 3f;
            time = 0f;
            while (time < 0.14f)
            {
                time += Time.unscaledDeltaTime;
                springX.UpdateFixed60(Time.unscaledDeltaTime, 0.5f, 0.58f);
                springY.UpdateFixed60(Time.unscaledDeltaTime, 0.5f, 0.58f);
                transform.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(time * 46f) * 6f);
                transform.localScale = new Vector3(springX.Value, springY.Value, 1f);
                yield return null;
            }

            springX.Target = 0f;
            springY.Target = 0f;
            springX.Velocity = 4.5f;
            springY.Velocity = -2.5f;
            time = 0f;
            while (time < 0.36f)
            {
                time += Time.unscaledDeltaTime;
                springX.UpdateFixed60(Time.unscaledDeltaTime, 0.38f, 0.62f);
                springY.UpdateFixed60(Time.unscaledDeltaTime, 0.38f, 0.62f);
                float wobble = Mathf.Sin(time * 34f) * (1f - time / 0.36f) * 9f;
                transform.localRotation = Quaternion.Euler(0f, 0f, wobble);
                transform.localScale = new Vector3(Mathf.Max(0f, springX.Value), Mathf.Max(0f, springY.Value), 1f);
                yield return null;
            }

            Destroy(gameObject);
        }

        void EnsureRefs()
        {
            if (plotImage == null)
                plotImage = GetComponent<Image>();

            if (picImage == null)
            {
                Transform pic = transform.Find("Pic");
                if (pic != null)
                    picImage = pic.GetComponent<Image>();
            }

            if (picImage != null)
            {
                picImage.raycastTarget = false;
                if (!capturedPrefabSize)
                {
                    Vector2 size = picImage.rectTransform.sizeDelta;
                    prefabPicSize = size.x >= 1f && size.y >= 1f
                        ? size
                        : new Vector2(DefaultPicSize, DefaultPicSize);
                    capturedPrefabSize = true;
                }
            }

            if (button == null)
                button = GetComponent<Button>();
            if (button == null)
                button = gameObject.AddComponent<Button>();

            if (plotImage != null)
            {
                plotImage.raycastTarget = true;
                button.targetGraphic = plotImage;
            }

            // Color Tint 会把没被 Select 的格子刷回 Normal（亮），穿着暗色会被盖掉
            button.transition = Selectable.Transition.None;

            pressMotion = GetComponent<UiButtonPressMotion>()
                          ?? gameObject.AddComponent<UiButtonPressMotion>();

            button.onClick.RemoveListener(HandleClick);
            button.onClick.AddListener(HandleClick);

            if (deleteObject == null)
            {
                Transform delete = transform.Find("delete");
                if (delete != null)
                    deleteObject = delete.gameObject;
            }

            if (deleteObject != null)
            {
                if (deleteRect == null)
                    deleteRect = deleteObject.transform as RectTransform;
                if (!deleteRestCaptured && deleteRect != null && !armed)
                {
                    deleteRestPosition = deleteRect.anchoredPosition;
                    deleteRestScale = deleteRect.localScale;
                    deleteRestCaptured = true;
                }

                Image icon = deleteObject.GetComponent<Image>();
                Button deleteButton = deleteObject.GetComponent<Button>();
                if (deleteButton == null)
                    deleteButton = deleteObject.AddComponent<Button>();
                deleteButton.transition = Selectable.Transition.None;
                deleteButton.targetGraphic = icon;
                deleteButton.onClick.RemoveListener(DeleteClicked);
                deleteButton.onClick.AddListener(DeleteClicked);
                Image[] icons = deleteObject.GetComponentsInChildren<Image>(true);
                for (int i = 0; i < icons.Length; i++)
                {
                    if (icons[i] != null && icons[i].gameObject != deleteObject)
                        icons[i].raycastTarget = false;
                }

                if (!armed)
                    deleteObject.SetActive(false);
            }
        }
    }
}
