using System.Collections.Generic;
using UnityEngine;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// 衣柜缩略图：从 SINGLE 大图中裁出不透明内容，放大显示。
    /// 穿戴仍用原图。不要求源贴图开启 Read/Write。
    /// </summary>
    public static class SpriteThumbnailUtil
    {
        static readonly Dictionary<Sprite, Sprite> Cache = new Dictionary<Sprite, Sprite>();

        public static Sprite GetZoomedContentSprite(Sprite source, byte alphaThreshold = 12)
        {
            if (source == null || source.texture == null)
                return null;

            if (Cache.TryGetValue(source, out Sprite cached) && cached != null)
                return cached;

            if (!TryFindOpaqueTextureRect(source, alphaThreshold, out Rect opaqueRect))
            {
                Cache[source] = source;
                return source;
            }

            float pad = 2f;
            opaqueRect.xMax = Mathf.Min(source.texture.width, opaqueRect.xMax + pad);
            opaqueRect.yMax = Mathf.Min(source.texture.height, opaqueRect.yMax + pad);
            opaqueRect.xMin = Mathf.Max(0f, opaqueRect.xMin - pad);
            opaqueRect.yMin = Mathf.Max(0f, opaqueRect.yMin - pad);

            if (opaqueRect.width < 1f || opaqueRect.height < 1f)
            {
                Cache[source] = source;
                return source;
            }

            Sprite zoomed = Sprite.Create(
                source.texture,
                opaqueRect,
                new Vector2(0.5f, 0.5f),
                source.pixelsPerUnit,
                0,
                SpriteMeshType.FullRect);

            zoomed.name = source.name + "_WardrobeThumb";
            Cache[source] = zoomed;
            return zoomed;
        }

        public static void ClearCache()
        {
            foreach (KeyValuePair<Sprite, Sprite> pair in Cache)
            {
                if (pair.Value != null && pair.Value != pair.Key &&
                    pair.Value.name != null && pair.Value.name.EndsWith("_WardrobeThumb"))
                    Object.Destroy(pair.Value);
            }

            Cache.Clear();
        }

        static bool TryFindOpaqueTextureRect(Sprite source, byte alphaThreshold, out Rect result)
        {
            result = default;
            Texture2D tex = source.texture;
            Rect spriteRect = source.textureRect;

            int texW = tex.width;
            int texH = tex.height;
            int x0 = Mathf.Clamp(Mathf.FloorToInt(spriteRect.x), 0, texW - 1);
            int y0 = Mathf.Clamp(Mathf.FloorToInt(spriteRect.y), 0, texH - 1);
            int x1 = Mathf.Clamp(Mathf.CeilToInt(spriteRect.xMax), 1, texW);
            int y1 = Mathf.Clamp(Mathf.CeilToInt(spriteRect.yMax), 1, texH);

            RenderTexture rt = RenderTexture.GetTemporary(texW, texH, 0, RenderTextureFormat.ARGB32);
            RenderTexture prev = RenderTexture.active;
            Graphics.Blit(tex, rt);
            RenderTexture.active = rt;

            var readable = new Texture2D(texW, texH, TextureFormat.RGBA32, false, false);
            readable.ReadPixels(new Rect(0, 0, texW, texH), 0, 0);
            readable.Apply(false, false);

            RenderTexture.active = prev;
            RenderTexture.ReleaseTemporary(rt);

            Color32[] pixels = readable.GetPixels32();
            Object.Destroy(readable);

            int minX = x1;
            int minY = y1;
            int maxX = x0 - 1;
            int maxY = y0 - 1;

            for (int y = y0; y < y1; y++)
            {
                int row = y * texW;
                for (int x = x0; x < x1; x++)
                {
                    if (pixels[row + x].a <= alphaThreshold)
                        continue;

                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                }
            }

            if (maxX < minX || maxY < minY)
                return false;

            result = new Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
            return true;
        }
    }
}
