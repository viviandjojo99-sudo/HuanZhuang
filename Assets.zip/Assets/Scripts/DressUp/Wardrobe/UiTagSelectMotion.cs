using DressUp.Motion;
using UnityEngine;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// Tag 选中：往右弹 20px。按压缩放复用 UiButtonPressMotion（挂在同一物体上）。
    /// 停稳后不再每帧改位置。
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class UiTagSelectMotion : MonoBehaviour
    {
        [SerializeField] float selectOffsetX = 20f;
        [SerializeField] float stiffness = 0.35f;
        [SerializeField] float damping = 0.72f;

        readonly DressUpSpring offsetSpring = new DressUpSpring(0f);

        RectTransform rt;
        Vector2 layoutAnchored;
        bool layoutCaptured;
        bool selected;
        bool animating;
        float appliedOffset;

        public bool Selected => selected;

        void Awake()
        {
            rt = transform as RectTransform;
            if (GetComponent<UiButtonPressMotion>() == null)
                gameObject.AddComponent<UiButtonPressMotion>();
        }

        public void SetSelected(bool value)
        {
            if (selected == value && !animating)
            {
                offsetSpring.Target = selected ? selectOffsetX : 0f;
                return;
            }

            selected = value;
            offsetSpring.Target = selected ? selectOffsetX : 0f;
            animating = true;
        }

        void Update()
        {
            if (!animating)
                return;

            offsetSpring.Target = selected ? selectOffsetX : 0f;
            offsetSpring.UpdateFixed60(Time.unscaledDeltaTime, stiffness, damping);
            if (offsetSpring.IsSettled(0.5f, 0.05f))
            {
                offsetSpring.Reset(offsetSpring.Target);
                animating = false;
            }
        }

        void LateUpdate()
        {
            if (rt == null)
                return;

            Vector2 current = rt.anchoredPosition;
            float cleanX = current.x - appliedOffset;

            if (!animating && !selected && Mathf.Abs(appliedOffset) < 0.01f)
            {
                layoutAnchored = new Vector2(cleanX, current.y);
                layoutCaptured = true;
                return;
            }

            if (!animating && selected && Mathf.Abs(appliedOffset - selectOffsetX) < 0.01f)
            {
                // 选中停稳：只在 layout 被外部改过时重写一次
                float want = cleanX + selectOffsetX;
                if (Mathf.Abs(current.x - want) < 0.01f)
                {
                    layoutAnchored = new Vector2(cleanX, current.y);
                    layoutCaptured = true;
                    return;
                }
            }

            if (!layoutCaptured)
            {
                layoutAnchored = new Vector2(cleanX, current.y);
                layoutCaptured = true;
            }
            else
                layoutAnchored = new Vector2(cleanX, current.y);

            appliedOffset = offsetSpring.Value;
            rt.anchoredPosition = new Vector2(layoutAnchored.x + appliedOffset, layoutAnchored.y);
        }
    }
}
