using System.Collections;
using System.Collections.Generic;
using DressUp.Actions;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Import;
using DressUp.Tinting;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Wardrobe
{
    public class WardrobeController : MonoBehaviour
    {
        [Header("当前角色（一般由 DressUpBinder 自动切换）")]
        [SerializeField] BodyAvatar targetAvatar;
        [SerializeField] ClothingCatalog catalog;

        [Header("衣柜格子")]
        [SerializeField] GameObject plotPrefab;
        [SerializeField] bool insertEmptySlotFirst = true;
        [SerializeField] bool zoomThumbnails = true;
        [Range(0.2f, 1f)]
        [SerializeField] float thumbnailScale = 0.65f;
        [Tooltip("留空 = 打开衣柜不预选分类，等玩家点 Tag")]
        [SerializeField] string defaultCategory = "";

        [Header("染色")]
        [SerializeField] LayerColorController colorController;

        [Header("高级（可留空）")]
        [SerializeField] Transform contentRoot;
        [SerializeField] WardrobeTagNavigator tagNavigator;

        readonly List<GameObject> spawned = new List<GameObject>();
        readonly List<ClothingPlotView> plotViews = new List<ClothingPlotView>();
        readonly List<ClothingPlotView> plotPool = new List<ClothingPlotView>();
        readonly List<string> tintLinkedScratch = new List<string>();
        readonly List<string> tintWornIdsScratch = new List<string>();
        ClothingPlotView emptyView;
        string currentCategory;
        string lastLoadedCategory;
        string tintItemId;
        string tintLinkCacheKey;
        bool tintLinkCacheTogether;
        bool hierarchyResolved;

        LayerColorController hookedColor;

        public BodyAvatar TargetAvatar => targetAvatar;
        public ClothingCatalog Catalog => catalog;

        public bool CategoryHasSlots(string category)
        {
            if (catalog == null || string.IsNullOrEmpty(category))
                return false;
            if (category == WardrobeTagNavigator.BackCategory || category == "返回")
                return true;

            if (catalog.HasChildTags(category))
            {
                List<WardrobeTagDef> children = catalog.GetChildTags(category);
                for (int i = 0; i < children.Count; i++)
                {
                    WardrobeTagDef child = children[i];
                    if (child != null && CategoryHasSlots(child.tagName))
                        return true;
                }

                return false;
            }

            List<ClothingItem> items = ImportedWardrobe.MergeTag(catalog, category);
            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                if (ImportedSave.HasPicture(item))
                    return true;
            }

            return false;
        }

        public void RefreshTagButtons()
        {
            if (tagNavigator != null)
                tagNavigator.RefreshTagButtons();
        }

        void Awake()
        {
            EnsureHierarchy();
            LockMaletaScrollVerticalOnly();
            EnsureTagNavigator();
            BindTags();
            if (colorController == null)
                colorController = FindAnyObjectByType<LayerColorController>();
            HookColorEvents();
        }

        void EnsureTagNavigator()
        {
            if (tagNavigator == null)
                tagNavigator = GetComponent<WardrobeTagNavigator>()
                               ?? GetComponentInChildren<WardrobeTagNavigator>(true);
            if (tagNavigator == null)
                tagNavigator = gameObject.AddComponent<WardrobeTagNavigator>();
        }

        /// <summary>
        /// Maleta 衣柜只允许竖滑。场景被 Tools 重绑定或 Unity 默认勾回 Horizontal 时在此强制关掉。
        /// </summary>
        void LockMaletaScrollVerticalOnly()
        {
            ScrollRect scroll = GetComponentInChildren<ScrollRect>(true);
            if (scroll == null)
                return;

            scroll.horizontal = false;
            scroll.horizontalScrollbar = null;

            if (contentRoot == null)
                return;

            var fitter = contentRoot.GetComponent<ContentSizeFitter>();
            if (fitter != null)
                fitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
        }

        IEnumerator Start()
        {
            // 清空穿着只由 ActiveAvatarBinder 负责，这里不再 ClearClothes，避免把已实现功能冲掉
            yield return null;
            if (!string.IsNullOrEmpty(defaultCategory))
                ShowCategory(defaultCategory, allowDrillDown: false);
            else
            {
                // 场景里可能残留旧 Plot；无默认分类时清成空柜，等玩家点 Tag
                ClearSpawnedPlotsOnly();
                currentCategory = null;
                RefreshTagSelectionVisuals();
            }

            RefreshTagButtons();
        }

        void OnDestroy()
        {
            if (hookedColor != null)
            {
                hookedColor.PlayerTintApplied -= OnPlayerTintApplied;
                hookedColor.PlayerGradientEndApplied -= OnGradientEndApplied;
            }
            UnbindTags();
            SpriteThumbnailUtil.ClearCache();
        }

        public void SetTargetAvatar(BodyAvatar avatar)
        {
            targetAvatar = avatar;
            tintItemId = null;
            InvalidateTintLinkCache();
            RefreshSelectionVisuals();
            RestoreTintIfStillSelected();
        }

        public void SetColorController(LayerColorController controller)
        {
            colorController = controller;
            HookColorEvents();
        }

        /// <summary>Clear / 外部改装后刷新穿着暗色；染色选中若已脱掉则关掉 BAR。</summary>
        public void RefreshSelection()
        {
            RefreshSelectionVisuals();
            RestoreTintIfStillSelected();
        }

        public void SetCatalog(ClothingCatalog nextCatalog)
        {
            catalog = nextCatalog;
            if (tagNavigator != null)
                tagNavigator.ResetToRootImmediate();
            // 切模板后旧 category 往往无效，清空格子等玩家点 Tag
            ClearCategoryView();
        }

        public void ClearCategoryView()
        {
            currentCategory = null;
            tintItemId = null;
            InvalidateTintLinkCache();
            ClearSpawnedPlotsOnly();
            RefreshTagSelectionVisuals();
        }

        /// <summary>关掉当前页的预览。身上穿着的留下，其余导入图卸掉。</summary>
        public void ParkPage()
        {
            ClearCategoryView();
            ImportedSave.LoadPage(catalog, null, targetAvatar);
        }

        public void RebindAllTags()
        {
            UnbindTags();
            BindTags();
        }

        public void ShowCategory(string category) => ShowCategory(category, allowDrillDown: true);

        public void ShowCategory(string category, bool allowDrillDown)
        {
            // 二级切换动画中：忽略一切 Tag 点击
            if (tagNavigator != null && tagNavigator.IsBusy)
                return;

            // 导航消费（进/出二级、误点父级）：由 Navigator 负责，这里不再用父级名刷空格子
            if (allowDrillDown && tagNavigator != null && tagNavigator.TryHandleTagClick(category))
                return;

            // 启动时选中有二级的一级：只高亮，不进二级、不刷空集
            if (!allowDrillDown && catalog != null && catalog.HasChildTags(category))
            {
                currentCategory = category;
                RefreshTagSelectionVisuals();
                ClearSpawnedPlotsOnly();
                return;
            }

            bool switched = !string.IsNullOrEmpty(currentCategory)
                            && !string.Equals(currentCategory, category, System.StringComparison.OrdinalIgnoreCase);
            currentCategory = category;
            RefreshTagSelectionVisuals();
            if (switched)
                ClearTintIfNotWorn();
            RebuildPlots();
        }

        void ClearSpawnedPlotsOnly()
        {
            EnsureHierarchy();
            ParkActivePlots();
            if (emptyView != null)
                emptyView.gameObject.SetActive(false);
            // 场景里常残留 Plot / Plot (1) 等占位格；旧逻辑是 Destroy，复用后也必须收进池并藏起来。
            HarvestContentChildren();
        }

        void HarvestContentChildren()
        {
            if (contentRoot == null)
                return;

            for (int i = contentRoot.childCount - 1; i >= 0; i--)
            {
                Transform child = contentRoot.GetChild(i);
                if (child == null)
                    continue;

                ClothingPlotView view = child.GetComponent<ClothingPlotView>();
                if (view == null)
                {
                    if (Application.isPlaying)
                        Destroy(child.gameObject);
                    else
                        DestroyImmediate(child.gameObject);
                    continue;
                }

                if (view == emptyView)
                {
                    view.gameObject.SetActive(false);
                    continue;
                }

                if (plotViews.Contains(view))
                    continue;

                ParkPlot(view);
            }
        }

        void RefreshTagSelectionVisuals()
        {
            WardrobeTag[] tags = GetComponentsInChildren<WardrobeTag>(true);
            for (int i = 0; i < tags.Length; i++)
            {
                if (tags[i] == null)
                    continue;
                if (tags[i].Category == WardrobeTagNavigator.BackCategory || tags[i].Category == "返回")
                {
                    tags[i].SetSelectedVisual(false);
                    continue;
                }

                bool on = !string.IsNullOrEmpty(currentCategory)
                          && CategoriesMatch(tags[i].Category, currentCategory);
                tags[i].SetSelectedVisual(on);
            }
        }

        bool CategoriesMatch(string a, string b)
        {
            if (string.Equals(a, b, System.StringComparison.OrdinalIgnoreCase))
                return true;
            if (catalog == null)
                return false;
            string ra = catalog.ResolveTagName(a);
            string rb = catalog.ResolveTagName(b);
            return string.Equals(ra, rb, System.StringComparison.OrdinalIgnoreCase);
        }

        public void RebuildPlots()
        {
            EnsureHierarchy();

            if (contentRoot == null || plotPrefab == null || catalog == null)
            {
                Debug.LogWarning("[WardrobeController] 缺少 Content / Plot 预制体 / Catalog。", this);
                return;
            }

            ImportedSave.LoadPage(catalog, currentCategory, targetAvatar);
            lastLoadedCategory = currentCategory;

            List<ClothingItem> items = ImportedWardrobe.MergeTag(catalog, currentCategory);
            for (int i = items.Count - 1; i >= 0; i--)
            {
                ClothingItem item = items[i];
                if (!ImportedSave.HasPicture(item))
                    items.RemoveAt(i);
            }

            HarvestContentChildren();

            var reusable = new List<ClothingPlotView>(plotViews.Count + plotPool.Count);
            for (int i = 0; i < plotViews.Count; i++)
            {
                if (plotViews[i] != null)
                    reusable.Add(plotViews[i]);
            }

            for (int i = 0; i < plotPool.Count; i++)
            {
                if (plotPool[i] != null && !reusable.Contains(plotPool[i]))
                    reusable.Add(plotPool[i]);
            }

            plotViews.Clear();
            plotPool.Clear();
            spawned.Clear();

            if (items.Count == 0)
            {
                if (emptyView != null)
                    emptyView.gameObject.SetActive(false);
                for (int i = 0; i < reusable.Count; i++)
                    ParkPlot(reusable[i]);
                RefreshSelectionVisuals();
                RestoreTintIfStillSelected();
                return;
            }

            if (insertEmptySlotFirst)
                EnsureEmptySlot();
            else if (emptyView != null)
                emptyView.gameObject.SetActive(false);

            int poolIndex = 0;
            for (int i = 0; i < items.Count; i++)
            {
                ClothingItem item = items[i];
                ClothingPlotView view;
                if (poolIndex < reusable.Count)
                {
                    view = reusable[poolIndex++];
                    view.gameObject.SetActive(true);
                }
                else
                {
                    GameObject go = Instantiate(plotPrefab, contentRoot);
                    view = go.GetComponent<ClothingPlotView>() ?? go.AddComponent<ClothingPlotView>();
                }

                view.gameObject.name = $"Plot_{item.itemId}";
                view.transform.SetParent(contentRoot, false);
                view.Bind(item, OnPlotClicked, zoomThumbnails, thumbnailScale, OnPlotDeleted);
                plotViews.Add(view);
                spawned.Add(view.gameObject);
            }

            for (int i = poolIndex; i < reusable.Count; i++)
                ParkPlot(reusable[i]);

            if (insertEmptySlotFirst && emptyView != null)
                emptyView.transform.SetAsFirstSibling();

            RefreshSelectionVisuals();
            RestoreTintIfStillSelected();
        }

        void EnsureEmptySlot()
        {
            if (emptyView == null)
            {
                GameObject go = Instantiate(plotPrefab, contentRoot);
                go.name = "Plot_Empty";
                emptyView = go.GetComponent<ClothingPlotView>() ?? go.AddComponent<ClothingPlotView>();
            }

            emptyView.gameObject.SetActive(true);
            emptyView.gameObject.name = "Plot_Empty";
            emptyView.BindEmpty(OnEmptySlotClicked);
            emptyView.transform.SetAsFirstSibling();
            spawned.Add(emptyView.gameObject);
        }

        void ParkActivePlots()
        {
            for (int i = 0; i < plotViews.Count; i++)
                ParkPlot(plotViews[i]);
            plotViews.Clear();
            spawned.Clear();
        }

        void ParkPlot(ClothingPlotView view)
        {
            if (view == null)
                return;
            view.gameObject.SetActive(false);
            if (!plotPool.Contains(view))
                plotPool.Add(view);
        }

        void OnPlotDeleted(ClothingItem item)
        {
            if (item == null)
                return;

            if (targetAvatar != null && targetAvatar.IsWearing(item))
                targetAvatar.ToggleEquip(item);
            if (tintItemId == item.itemId)
                ClearTintIfNotWorn();

            ImportedSave.DeleteOne(item);
            DressUpAudio.Instance?.PlayPopup();
            for (int i = plotViews.Count - 1; i >= 0; i--)
            {
                ClothingPlotView view = plotViews[i];
                if (view == null || view.Item != item)
                    continue;
                spawned.Remove(view.gameObject);
                plotViews.RemoveAt(i);
                ParkPlot(view);
            }

            RefreshSelectionVisuals();
            RefreshTagButtons();
        }

        void OnPlotClicked(ClothingItem item)
        {
            if (targetAvatar == null)
            {
                Debug.LogWarning("[WardrobeController] 当前没有角色。", this);
                return;
            }

            DressUpAudio.Instance?.PlayPopup();

            bool wasWearing = targetAvatar.IsWearing(item);
            bool equipped = targetAvatar.ToggleEquip(item);
            bool unequipped = wasWearing && item != null && !targetAvatar.IsWearing(item);
            if (!equipped && !unequipped && item != null)
            {
                // Toggle 想穿上却失败（常见：图层名对不上当前角色）
                if (!targetAvatar.TryGetLayer(item.layerName, out _))
                {
                    Debug.LogWarning(
                        $"[WardrobeController] 无法穿上「{item.itemId}」：角色「{targetAvatar.CharacterId}」没有图层「{item.layerName}」。",
                        this);
                }
            }

            ClothingPlotView clicked = FindView(item);
            clicked?.PlayClickFeedback();

            RefreshSelectionVisuals();

            if (equipped && item != null)
            {
                // 刚穿上的这件 = 染色选中，BAR 只跟它
                tintItemId = item.itemId;
                InvalidateTintLinkCache();
                ApplyTintSelection(item.layerName);
            }
            else if (unequipped)
            {
                // 脱掉任意一件都收起调色，避免玩家不知道颜色会填到哪件还穿着的衣服上
                ClearTintIfNotWorn();
            }
        }

        /// <summary>开柜时只恢复「已经选中的那件」，没有选中就保持 BAR 隐藏。不改衣服上已经调过的颜色。</summary>
        public void SyncTintPanel() => RestoreTintIfStillSelected();

        void OnEmptySlotClicked()
        {
            if (targetAvatar == null || catalog == null)
                return;

            WardrobeTagDef tag = catalog.FindTag(currentCategory);
            if (tag?.layers == null || tag.layers.Count == 0)
            {
                Debug.LogWarning($"[WardrobeController] Tag「{currentCategory}」没有配置图层。", this);
                return;
            }

            DressUpAudio.Instance?.PlayPopup();
            emptyView?.PlayClickFeedback();
            targetAvatar.ClearLayers(tag.layers);
            RefreshSelectionVisuals();
            ClearTintIfNotWorn();
        }

        void ClearTintIfNotWorn()
        {
            tintItemId = null;
            InvalidateTintLinkCache();
            EnsureColorController();
            colorController?.ClearTintTarget();
        }

        /// <summary>只认玩家点过、现在仍穿着的那一件。没有就淡出 BAR。</summary>
        void RestoreTintIfStillSelected()
        {
            EnsureColorController();
            if (colorController == null)
                return;

            ClothingItem tint = string.IsNullOrEmpty(tintItemId) ? null : catalog?.Find(tintItemId);
            if (tint == null || targetAvatar == null || !targetAvatar.IsWearing(tint))
            {
                tintItemId = null;
                InvalidateTintLinkCache();
                colorController.ClearTintTarget();
                return;
            }

            ApplyTintSelection(tint.layerName);
        }

        void ApplyTintSelection(string layerName)
        {
            EnsureColorController();
            if (colorController == null || targetAvatar == null)
                return;

            // 只把「这件衣服所在图层的 Image」交给染色条
            if (!targetAvatar.TryGetLayer(layerName, out UnityEngine.UI.Image layerImage) || layerImage == null)
            {
                Debug.LogWarning($"[WardrobeController] 找不到图层「{layerName}」的 Image，染色条无法显示。", this);
                return;
            }

            colorController.SetTintTarget(layerImage, true);
            // 再催一次显示，防止被其它初始化里的 Hide 盖掉
            colorController.ShowPanel();
        }

        void HookColorEvents()
        {
            EnsureColorController();
            if (hookedColor == colorController)
                return;

            if (hookedColor != null)
            {
                hookedColor.PlayerTintApplied -= OnPlayerTintApplied;
                hookedColor.PlayerGradientEndApplied -= OnGradientEndApplied;
            }

            hookedColor = colorController;
            if (hookedColor != null)
            {
                hookedColor.PlayerTintApplied += OnPlayerTintApplied;
                hookedColor.PlayerGradientEndApplied += OnGradientEndApplied;
            }
        }

        void OnGradientEndApplied(Color end)
        {
            if (targetAvatar == null || string.IsNullOrEmpty(tintItemId))
                return;

            ClothingItem tinted = catalog?.Find(tintItemId) ?? ImportedWardrobe.Find(null, tintItemId);
            bool together = ResolveTintLinked(tinted, tintLinkedScratch);
            if (!together)
            {
                if (tinted != null && !string.IsNullOrEmpty(tinted.layerName))
                    targetAvatar.SetLayerGradientEnd(tinted.layerName, end);
                return;
            }

            for (int i = 0; i < tintLinkedScratch.Count; i++)
                targetAvatar.SetLayerGradientEnd(tintLinkedScratch[i], end);
        }

        void OnPlayerTintApplied(Color color, float lift)
        {
            if (targetAvatar == null || string.IsNullOrEmpty(tintItemId))
                return;

            targetAvatar.RememberChosenColor(tintItemId, color, lift);
            ClothingItem tinted = catalog?.Find(tintItemId) ?? ImportedWardrobe.Find(null, tintItemId);
            bool together = ResolveTintLinked(tinted, tintLinkedScratch);

            if (!together)
            {
                if (tinted != null && !string.IsNullOrEmpty(tinted.layerName))
                    targetAvatar.SetLayerColor(tinted.layerName, color, lift);
                return;
            }

            tintWornIdsScratch.Clear();
            for (int i = 0; i < tintLinkedScratch.Count; i++)
            {
                string layer = tintLinkedScratch[i];
                if (!targetAvatar.TryGetWearOnLayer(layer, out EquippedSlot worn) || worn == null)
                    continue;
                // 拖色条连刷多层时只在最后记一次存档脏标记。
                targetAvatar.SetLayerColor(layer, color, lift, noteSave: false);
                int before = tintWornIdsScratch.Count;
                targetAvatar.CollectWornItemIds(layer, tintWornIdsScratch);
                for (int n = before; n < tintWornIdsScratch.Count; n++)
                    targetAvatar.RememberChosenColor(tintWornIdsScratch[n], color, lift);
            }

            ImportedSave.NoteOutfitChanged();
        }

        bool ResolveTintLinked(ClothingItem tinted, List<string> linked)
        {
            RandomSettingsPanel settings = RandomSettingsPanel.Current;
            if (settings == null || tinted == null)
            {
                tintLinkCacheKey = null;
                tintLinkCacheTogether = false;
                linked.Clear();
                return false;
            }

            // 拖色条只认「同时变色」；勾选变化编进 key，关设置后再拖立刻按新方案。
            string layerName = tinted.layerName;
            string key = "L|" + (tintItemId ?? string.Empty) + "|" + (layerName ?? string.Empty) + "|" + settings.TintLinkMask;

            // 同选中项 + 同勾选方案连续拖动：复用上次联动层列表。
            if (key == tintLinkCacheKey)
                return tintLinkCacheTogether && tintLinkedScratch.Count > 0;

            tintLinkCacheKey = key;
            tintLinkCacheTogether = settings.CollectLinked(layerName, catalog, linked);
            return tintLinkCacheTogether;
        }

        void InvalidateTintLinkCache()
        {
            tintLinkCacheKey = null;
            tintLinkCacheTogether = false;
            tintLinkedScratch.Clear();
        }

        void EnsureColorController()
        {
            if (colorController == null)
                colorController = FindAnyObjectByType<LayerColorController>();
        }

        void RefreshSelectionVisuals()
        {
            for (int i = 0; i < plotViews.Count; i++)
            {
                ClothingPlotView view = plotViews[i];
                if (view == null || view.Item == null)
                    continue;

                bool worn = targetAvatar != null && targetAvatar.IsWearing(view.Item);
                view.SetWorn(worn);
            }
        }

        ClothingPlotView FindView(ClothingItem item)
        {
            for (int i = 0; i < plotViews.Count; i++)
            {
                if (plotViews[i] != null && plotViews[i].Item == item)
                    return plotViews[i];
            }

            return null;
        }

        void EnsureHierarchy()
        {
            if (hierarchyResolved && contentRoot != null)
                return;

            if (contentRoot == null)
                contentRoot = FindClothesContent(transform);

            hierarchyResolved = true;
        }

        void BindTags()
        {
            WardrobeTag[] tags = GetComponentsInChildren<WardrobeTag>(true);
            for (int i = 0; i < tags.Length; i++)
            {
                tags[i].OnSelected.RemoveListener(OnTagClicked);
                tags[i].OnSelected.AddListener(OnTagClicked);
            }
        }

        void UnbindTags()
        {
            WardrobeTag[] tags = GetComponentsInChildren<WardrobeTag>(true);
            for (int i = 0; i < tags.Length; i++)
            {
                if (tags[i] != null)
                    tags[i].OnSelected.RemoveListener(OnTagClicked);
            }
        }

        void OnTagClicked(string category) => ShowCategory(category, allowDrillDown: true);

        void ClearSpawned()
        {
            ParkActivePlots();
            if (emptyView != null)
                emptyView.gameObject.SetActive(false);
        }

        public static Transform FindClothesContent(Transform maletaRoot)
        {
            if (maletaRoot == null)
                return null;

            Transform[] all = maletaRoot.GetComponentsInChildren<Transform>(true);
            Transform best = null;
            int bestScore = -1;

            for (int i = 0; i < all.Length; i++)
            {
                Transform t = all[i];
                if (t.name != "Content")
                    continue;

                int plotScore = 0;
                for (int c = 0; c < t.childCount; c++)
                {
                    if (t.GetChild(c).name.StartsWith("Plot"))
                        plotScore += 2;
                }

                bool underScroll = t.GetComponentInParent<UnityEngine.UI.ScrollRect>() != null;
                int score = plotScore + (underScroll ? 10 : 0) + t.childCount;

                if (score > bestScore)
                {
                    bestScore = score;
                    best = t;
                }
            }

            return best;
        }
    }
}
