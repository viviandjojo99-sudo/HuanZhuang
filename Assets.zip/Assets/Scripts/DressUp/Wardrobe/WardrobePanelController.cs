using DressUp.Actions;
using DressUp.Audio;
using DressUp.Motion;
using DressUp.Tinting;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// ButtonCloth：Maleta 从左滑入；Button 组从右往左滑入并淡入。
    /// Save 确认：Maleta / Button 滑回，CHANGECOLOR 淡出。
    /// </summary>
    public class WardrobePanelController : MonoBehaviour
    {
        [Header("Maleta（收起 X=-420，展开 X=-5；滑动不得超过展开位置）")]
        [SerializeField] RectTransform maletaRoot;
        [SerializeField] UiSlideMotion maletaSlide;
        [SerializeField] float maletaClosedAnchoredX = -420f;

        [Header("操作按钮 Button（从右往左滑入）")]
        [SerializeField] RectTransform actionButtonsRoot;
        [SerializeField] CanvasGroup actionButtonsGroup;
        [SerializeField] UiSlideMotion actionButtonsSlide;
        [SerializeField] UiFadeMotion actionButtonsFade;
        [SerializeField] float actionButtonsSlideDistance = 220f;

        [Header("染色 BAR")]
        [SerializeField] LayerColorController colorController;

        [Header("按钮")]
        [SerializeField] Button openButton;
        [SerializeField] AvatarSaveButton confirmSaveButton;

        [SerializeField] bool startClosed = true;

        bool open;
        bool maletaRestCaptured;
        bool actionRestCaptured;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void EnsureInScene()
        {
            if (Object.FindAnyObjectByType<WardrobePanelController>() != null)
                return;

            GameObject maleta = GameObject.Find("Maleta");
            if (maleta == null)
                return;

            maleta.AddComponent<WardrobePanelController>();
        }

        void Awake()
        {
            if (maletaRoot == null)
            {
                GameObject maleta = GameObject.Find("Maleta");
                if (maleta != null)
                    maletaRoot = maleta.transform as RectTransform;
            }

            EnsureMaletaSlide();
            EnsureActionButtons();
            EnsureColor();

            if (openButton == null)
            {
                GameObject cloth = GameObject.Find("UI_CLOTH");
                if (cloth == null)
                    cloth = GameObject.Find("ButtonCloth");
                if (cloth != null)
                    openButton = cloth.GetComponent<Button>();
            }

            if (confirmSaveButton == null)
                confirmSaveButton = FindAnyObjectByType<AvatarSaveButton>();

            EnsurePress(openButton);
            EnsurePress(confirmSaveButton != null ? confirmSaveButton.GetComponent<Button>() : null);

            if (actionButtonsRoot != null)
            {
                Button[] buttons = actionButtonsRoot.GetComponentsInChildren<Button>(true);
                for (int i = 0; i < buttons.Length; i++)
                    EnsurePress(buttons[i]);
            }
        }

        void Start()
        {
            if (openButton != null)
            {
                openButton.onClick.RemoveListener(Toggle);
                openButton.onClick.AddListener(Toggle);
            }

            if (confirmSaveButton != null)
                confirmSaveButton.Saved += CloseAfterConfirm;

            if (startClosed)
                SnapClosed();
            else
                SnapOpen();
        }

        void OnDestroy()
        {
            if (openButton != null)
            {
                openButton.onClick.RemoveListener(Toggle);
            }
            if (confirmSaveButton != null)
                confirmSaveButton.Saved -= CloseAfterConfirm;
        }

        public void Toggle()
        {
            DressUpAudio.Instance?.PlayKey();
            if (open)
                Close();
            else
                Open();
        }

        public void Open()
        {
            open = true;

            EnsureMaletaSlide();
            maletaSlide?.Open();

            EnsureActionButtons();
            if (actionButtonsSlide != null)
            {
                actionButtonsSlide.SlideDistance = actionButtonsSlideDistance;
                actionButtonsSlide.SlideFrom = UiSlideFrom.Right;
                actionButtonsSlide.Open();
            }

            actionButtonsFade?.FadeIn();

            // 开柜：若身上已有穿着，恢复染色条（不丢已实现的 BAR）
            var wardrobe = FindAnyObjectByType<WardrobeController>();
            wardrobe?.SyncTintPanel();
        }

        public void Close()
        {
            open = false;
            maletaSlide?.Close();
            actionButtonsSlide?.Close();
            actionButtonsFade?.FadeOut();

            // Save/关柜：只淡出 BAR，不清空 tint 目标，下次开柜可恢复
            EnsureColor();
            colorController?.HidePanel();
        }

        void CloseAfterConfirm() => Close();

        void SnapClosed()
        {
            open = false;

            EnsureMaletaSlide();
            maletaSlide?.SnapClosed();

            EnsureActionButtons();
            if (actionButtonsSlide != null)
            {
                actionButtonsSlide.SlideDistance = actionButtonsSlideDistance;
                actionButtonsSlide.SlideFrom = UiSlideFrom.Right;
                actionButtonsSlide.SnapClosed();
            }

            actionButtonsFade?.SnapHidden();

            EnsureColor();
            // 开局直接藏，不要 FadeOut 协程占着，否则随后点 Plot 的 FadeIn 可能被干扰
            colorController?.SnapHidden();
        }

        void SnapOpen()
        {
            open = true;
            maletaSlide?.SnapOpen();
            actionButtonsSlide?.SnapOpen();
            actionButtonsFade?.SnapShown();
        }

        void EnsureMaletaSlide()
        {
            if (maletaRoot == null)
                return;

            if (maletaSlide == null)
                maletaSlide = maletaRoot.GetComponent<UiSlideMotion>() ?? maletaRoot.gameObject.AddComponent<UiSlideMotion>();

            maletaSlide.SetTarget(maletaRoot);
            maletaSlide.SlideFrom = UiSlideFrom.Left;
            // 弹簧手感沿用原先参数；关闭时停在绝对 X=-420（不是“移动 420”）
            maletaSlide.UseAbsoluteClosedX = true;
            maletaSlide.ClosedAnchoredX = maletaClosedAnchoredX;
            if (!maletaRestCaptured)
            {
                maletaSlide.CaptureRestFromCurrent();
                maletaRestCaptured = true;
            }
        }

        void EnsureActionButtons()
        {
            if (actionButtonsRoot == null)
            {
                // Button 挂在 Canvas 下，不是 Maleta 子物体
                GameObject buttonGo = GameObject.Find("Button");
                if (buttonGo != null)
                    actionButtonsRoot = buttonGo.transform as RectTransform;
            }

            if (actionButtonsRoot == null)
                return;

            if (actionButtonsGroup == null)
            {
                actionButtonsGroup = actionButtonsRoot.GetComponent<CanvasGroup>();
                if (actionButtonsGroup == null)
                    actionButtonsGroup = actionButtonsRoot.gameObject.AddComponent<CanvasGroup>();
            }

            if (actionButtonsFade == null)
                actionButtonsFade = actionButtonsRoot.GetComponent<UiFadeMotion>()
                                    ?? actionButtonsRoot.gameObject.AddComponent<UiFadeMotion>();
            actionButtonsFade.SetCanvasGroup(actionButtonsGroup);
            actionButtonsFade.Duration = 0.28f;

            if (actionButtonsSlide == null)
                actionButtonsSlide = actionButtonsRoot.GetComponent<UiSlideMotion>()
                                    ?? actionButtonsRoot.gameObject.AddComponent<UiSlideMotion>();
            actionButtonsSlide.SetTarget(actionButtonsRoot);
            actionButtonsSlide.SlideFrom = UiSlideFrom.Right;
            actionButtonsSlide.SlideDistance = actionButtonsSlideDistance;
            if (!actionRestCaptured)
            {
                actionButtonsSlide.CaptureRestFromCurrent();
                actionRestCaptured = true;
            }
        }

        void EnsureColor()
        {
            if (colorController == null)
                colorController = FindAnyObjectByType<LayerColorController>();
        }

        static void EnsurePress(Button button)
        {
            if (button == null)
                return;
            if (button.GetComponent<UiButtonPressMotion>() == null)
                button.gameObject.AddComponent<UiButtonPressMotion>();
            button.transition = Selectable.Transition.None;
        }
    }
}
