using DressUp.Motion;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// 挂在衣柜 Tag 上，在 Inspector 填写类别字符串。
    /// 按压用 UiButtonPressMotion；选中位移用 UiTagSelectMotion（+20px）。
    /// </summary>
    [RequireComponent(typeof(Button))]
    public class WardrobeTag : MonoBehaviour
    {
        [SerializeField] string category = "Hair";
        [SerializeField] UnityEvent<string> onSelected = new UnityEvent<string>();

        Button button;
        UiTagSelectMotion selectMotion;

        public string Category => category;
        public UnityEvent<string> OnSelected => onSelected;

        void Awake()
        {
            button = GetComponent<Button>();
            // Tag 颜色若要改，用 Button Color Tint；位移仍走 selectMotion
            if (GetComponent<UiButtonPressMotion>() == null)
                gameObject.AddComponent<UiButtonPressMotion>();
            button.onClick.AddListener(NotifySelected);
            selectMotion = GetComponent<UiTagSelectMotion>() ?? gameObject.AddComponent<UiTagSelectMotion>();
        }

        void OnDestroy()
        {
            if (button != null)
                button.onClick.RemoveListener(NotifySelected);
        }

        public void NotifySelected()
        {
            onSelected?.Invoke(category);
        }

        public void SetCategory(string value)
        {
            category = value;
        }

        public void SetSelectedVisual(bool selected)
        {
            if (selectMotion == null)
                selectMotion = GetComponent<UiTagSelectMotion>() ?? gameObject.AddComponent<UiTagSelectMotion>();
            selectMotion.SetSelected(selected);
        }
    }
}
