using System.Collections.Generic;
using DressUp.Audio;
using DressUp.Avatar;
using DressUp.Data;
using DressUp.Motion;
using UnityEngine;
using UnityEngine.UI;

namespace DressUp.Wardrobe
{
    /// <summary>
    /// TagA（一级）↔ TagB / TagC（二级）。
    /// 头发 → TagB；其它饰品 → TagC。动效与返回逻辑相同。
    /// </summary>
    public class WardrobeTagNavigator : MonoBehaviour
    {
        public const string BackCategory = "__back__";

        [SerializeField] Transform tag1Root;
        [SerializeField] Transform tag2Root;
        [SerializeField] Transform tag3Root;
        [SerializeField] WardrobeController wardrobe;
        [SerializeField] float staggerDelay = 0.04f;
        [SerializeField] float shownX = 100f;
        [SerializeField] float hiddenX = 0f;

        UiTagColumnStaggerMotion tag1Motion;
        UiTagColumnStaggerMotion tag2Motion;
        UiTagColumnStaggerMotion tag3Motion;
        CanvasGroup tag1Group;
        CanvasGroup tag2Group;
        CanvasGroup tag3Group;

        Transform activeSubRoot;
        UiTagColumnStaggerMotion activeSubMotion;
        CanvasGroup activeSubGroup;

        bool inSubLevel;
        string currentParent;
        bool transitioning;

        /// <summary>首次重绑前备份 TagA 原图标，切回 BodyPanel 时恢复。</summary>
        Sprite[] tagAIconBackup;

        public bool InSubLevel => inSubLevel;
        public bool IsBusy => transitioning;

        void Awake()
        {
            if (wardrobe == null)
                wardrobe = GetComponent<WardrobeController>()
                          ?? GetComponentInParent<WardrobeController>()
                          ?? FindAnyObjectByType<WardrobeController>();

            ResolveRefs();

            if (tag1Motion != null)
            {
                ApplyMotionSettings(tag1Motion);
                tag1Motion.SnapShown();
            }

            HideSubColumn(tag2Root, tag2Motion, tag2Group);
            HideSubColumn(tag3Root, tag3Motion, tag3Group);

            SetColumnClickable(tag1Group, true);
            inSubLevel = false;
        }

        public bool TryHandleTagClick(string category)
        {
            if (string.IsNullOrEmpty(category))
                return true;

            if (transitioning)
                return true;

            if (category == BackCategory || category == "返回")
            {
                DressUpAudio.Instance?.PlayBack();
                ExitSubLevel();
                return true;
            }

            ClothingCatalog catalog = wardrobe != null ? wardrobe.Catalog : null;
            if (catalog == null)
                return false;

            if (catalog.HasChildTags(category))
            {
                if (inSubLevel)
                    return true;
                EnterSubLevel(category);
                return true;
            }

            return false;
        }

        public void EnterSubLevel(string parentCategory)
        {
            if (transitioning || inSubLevel)
                return;

            ResolveRefs();
            if (tag1Root == null || wardrobe == null)
            {
                Debug.LogWarning("[WardrobeTagNavigator] 缺少 TagA 或 WardrobeController。", this);
                return;
            }

            ClothingCatalog catalog = wardrobe.Catalog;
            if (catalog == null || !catalog.HasChildTags(parentCategory))
                return;

            if (!TryResolveSubColumn(parentCategory, out activeSubRoot, out activeSubMotion, out activeSubGroup))
            {
                Debug.LogWarning($"[WardrobeTagNavigator] 「{parentCategory}」没有对应二级栏（TagB/TagC）。", this);
                return;
            }

            currentParent = parentCategory;
            ApplyDataVisibility(activeSubRoot);
            string first = FirstOpenCategory(activeSubRoot);
            if (string.IsNullOrEmpty(first))
            {
                Debug.LogWarning($"[WardrobeTagNavigator] 「{parentCategory}」没有已有衣服的 Tag。", this);
                activeSubRoot = null;
                activeSubMotion = null;
                activeSubGroup = null;
                currentParent = null;
                return;
            }

            inSubLevel = true;
            wardrobe.ParkPage();

            transitioning = true;
            SetColumnClickable(tag1Group, false);
            SetColumnClickable(activeSubGroup, false);

            activeSubRoot.gameObject.SetActive(true);
            if (activeSubMotion != null)
                activeSubMotion.SnapHidden();

            Transform subRoot = activeSubRoot;
            UiTagColumnStaggerMotion subMotion = activeSubMotion;
            CanvasGroup subGroup = activeSubGroup;

            PlayParallel(
                hide: tag1Motion,
                show: subMotion,
                onHideFallback: () =>
                {
                    if (tag1Root != null)
                        tag1Root.gameObject.SetActive(false);
                },
                onDone: () =>
                {
                    transitioning = false;
                    SetColumnClickable(tag1Group, false);
                    SetColumnClickable(subGroup, true);
                    if (tag1Root != null)
                        tag1Root.gameObject.SetActive(false);
                });
        }

        public void ExitSubLevel()
        {
            if (transitioning || !inSubLevel)
                return;

            Transform subRoot = activeSubRoot != null ? activeSubRoot : tag2Root;
            UiTagColumnStaggerMotion subMotion = activeSubMotion != null ? activeSubMotion : tag2Motion;
            CanvasGroup subGroup = activeSubGroup != null ? activeSubGroup : tag2Group;

            transitioning = true;
            inSubLevel = false;
            currentParent = null;
            wardrobe?.ParkPage();
            SetColumnClickable(tag1Group, false);
            SetColumnClickable(subGroup, false);

            if (tag1Root != null)
                tag1Root.gameObject.SetActive(true);
            if (tag1Motion != null)
                tag1Motion.SnapHidden();

            PlayParallel(
                hide: subMotion,
                show: tag1Motion,
                onHideFallback: () =>
                {
                    if (subRoot != null)
                        subRoot.gameObject.SetActive(false);
                },
                onDone: () =>
                {
                    transitioning = false;
                    if (subRoot != null)
                        subRoot.gameObject.SetActive(false);
                    SetColumnClickable(tag1Group, true);
                    SetColumnClickable(subGroup, false);
                    activeSubRoot = null;
                    activeSubMotion = null;
                    activeSubGroup = null;
                });
        }

        public void ResetToRootImmediate()
        {
            transitioning = false;
            inSubLevel = false;
            currentParent = null;

            HideSubColumn(tag2Root, tag2Motion, tag2Group);
            HideSubColumn(tag3Root, tag3Motion, tag3Group);

            if (tag1Root != null)
            {
                tag1Root.gameObject.SetActive(true);
                if (tag1Motion != null)
                    tag1Motion.SnapShown();
            }

            SetColumnClickable(tag1Group, true);
            activeSubRoot = null;
            activeSubMotion = null;
            activeSubGroup = null;
        }

        /// <summary>
        /// 按模板重绑 TagA：同一套八格壳子，换 category / 显隐 / 图标。古鸟无二级时不会进 TagB/C。
        /// </summary>
        /// <summary>按 TagA 子物体顺序读出现在挂着的 Category，不改按钮。</summary>
        public List<TagSlotDef> CaptureTagASlots()
        {
            ResolveRefs();
            List<WardrobeTag> tagA = CollectColumnSlots(tag1Root);
            var list = new List<TagSlotDef>(tagA.Count);
            for (int i = 0; i < tagA.Count; i++)
            {
                WardrobeTag slot = tagA[i];
                string category = slot != null ? slot.Category : "";
                bool on = slot != null && slot.gameObject.activeSelf && !string.IsNullOrEmpty(category);
                list.Add(new TagSlotDef { category = category ?? "", active = on });
            }

            return list;
        }

        public void ApplyTagASlots(IList<TagSlotDef> slots)
        {
            ResolveRefs();
            ResetToRootImmediate();
            if (tag1Root == null || slots == null)
                return;

            List<WardrobeTag> tagA = CollectColumnSlots(tag1Root);
            CacheTagAIconsIfNeeded(tagA);

            for (int i = 0; i < tagA.Count; i++)
            {
                WardrobeTag slot = tagA[i];
                if (slot == null)
                    continue;

                if (i >= slots.Count)
                {
                    slot.gameObject.SetActive(false);
                    continue;
                }

                TagSlotDef def = slots[i];
                bool on = def != null && def.active && !string.IsNullOrEmpty(def.category);
                slot.gameObject.SetActive(on);
                if (!on)
                    continue;

                slot.gameObject.name = def.category;
                slot.SetCategory(def.category);
                slot.SetSelectedVisual(false);

                if (def.icon != null)
                    SetTagIcon(slot, def.icon);
                else if (tagAIconBackup != null && i < tagAIconBackup.Length && tagAIconBackup[i] != null)
                    SetTagIcon(slot, tagAIconBackup[i]);
            }
        }

        void CacheTagAIconsIfNeeded(List<WardrobeTag> tagA)
        {
            if (tagAIconBackup != null || tagA == null)
                return;

            tagAIconBackup = new Sprite[tagA.Count];
            for (int i = 0; i < tagA.Count; i++)
                tagAIconBackup[i] = ReadTagIcon(tagA[i]);
        }

        static Sprite ReadTagIcon(WardrobeTag slot)
        {
            Image image = FindIconImage(slot);
            return image != null ? image.sprite : null;
        }

        static void SetTagIcon(WardrobeTag slot, Sprite sprite)
        {
            if (sprite == null)
                return;
            Image image = FindIconImage(slot);
            if (image != null)
                image.sprite = sprite;
        }

        /// <summary>Tag 根 Image 是槽底板；真正的分类图在子物体 Icon 上。</summary>
        static Image FindIconImage(WardrobeTag slot)
        {
            if (slot == null)
                return null;

            Transform icon = slot.transform.Find("Icon");
            if (icon == null)
            {
                for (int i = 0; i < slot.transform.childCount; i++)
                {
                    Transform child = slot.transform.GetChild(i);
                    if (child != null && child.name == "Icon")
                    {
                        icon = child;
                        break;
                    }
                }
            }

            if (icon != null)
                return icon.GetComponent<Image>();

            // 兜底：不要用根节点 Image（那是 Slot 底板）
            Image[] images = slot.GetComponentsInChildren<Image>(true);
            for (int i = 0; i < images.Length; i++)
            {
                if (images[i] != null && images[i].transform != slot.transform)
                    return images[i];
            }

            return null;
        }

        static List<WardrobeTag> CollectColumnSlots(Transform root)
        {
            var list = new List<WardrobeTag>();
            if (root == null)
                return list;

            for (int i = 0; i < root.childCount; i++)
            {
                Transform child = root.GetChild(i);
                WardrobeTag tag = child.GetComponent<WardrobeTag>();
                if (tag == null)
                    tag = child.GetComponentInChildren<WardrobeTag>(true);
                if (tag != null)
                    list.Add(tag);
            }

            return list;
        }

        bool TryResolveSubColumn(
            string parentCategory,
            out Transform root,
            out UiTagColumnStaggerMotion motion,
            out CanvasGroup group)
        {
            root = null;
            motion = null;
            group = null;

            ClothingCatalog catalog = wardrobe != null ? wardrobe.Catalog : null;
            string resolved = catalog != null ? catalog.ResolveTagName(parentCategory) : parentCategory;

            // 头发 → TagB；其它饰品 → TagC
            if (IsHairAlias(resolved) || IsHairAlias(parentCategory))
            {
                root = tag2Root;
                motion = tag2Motion;
                group = tag2Group;
            }
            else if (resolved == "其它饰品" || parentCategory == "其它饰品")
            {
                root = tag3Root;
                motion = tag3Motion;
                group = tag3Group;
            }
            else
            {
                // 默认 TagB
                root = tag2Root;
                motion = tag2Motion;
                group = tag2Group;
            }

            return root != null;
        }

        void HideSubColumn(Transform root, UiTagColumnStaggerMotion motion, CanvasGroup group)
        {
            if (motion != null)
                motion.SnapHidden();
            if (root != null)
                root.gameObject.SetActive(false);
            SetColumnClickable(group, false);
        }

        void PlayParallel(
            UiTagColumnStaggerMotion hide,
            UiTagColumnStaggerMotion show,
            System.Action onHideFallback,
            System.Action onDone)
        {
            int pending = 0;
            void OneDone()
            {
                pending--;
                if (pending <= 0)
                    onDone?.Invoke();
            }

            if (hide != null)
            {
                pending++;
                hide.PlayHide(OneDone);
            }
            else
                onHideFallback?.Invoke();

            if (show != null)
            {
                pending++;
                show.PlayShow(OneDone);
            }

            if (pending == 0)
                onDone?.Invoke();
        }

        public void RefreshTagButtons()
        {
            ResolveRefs();
            ApplyDataVisibility(tag1Root);
            if (inSubLevel && activeSubRoot != null)
                ApplyDataVisibility(activeSubRoot);
        }

        void ApplyDataVisibility(Transform root)
        {
            if (root == null || wardrobe == null)
                return;

            List<WardrobeTag> slots = CollectColumnSlots(root);
            for (int i = 0; i < slots.Count; i++)
            {
                WardrobeTag slot = slots[i];
                if (slot == null || IsBack(slot.Category))
                {
                    if (slot != null)
                        slot.gameObject.SetActive(true);
                    continue;
                }
                if (string.IsNullOrEmpty(slot.Category) || slot.Category == "角")
                {
                    slot.gameObject.SetActive(false);
                    continue;
                }

                bool show = wardrobe.CategoryHasSlots(slot.Category);
                slot.gameObject.SetActive(show);
                if (!show)
                    continue;
                CanvasGroup group = slot.GetComponent<CanvasGroup>();
                if (group != null)
                {
                    group.alpha = 1f;
                    group.interactable = true;
                    group.blocksRaycasts = true;
                }

                Button tagButton = slot.GetComponent<Button>();
                if (tagButton != null)
                    tagButton.interactable = true;
            }

            if (root.GetComponent<LayoutGroup>() != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(root as RectTransform);
        }

        string FirstOpenCategory(Transform root)
        {
            List<WardrobeTag> slots = CollectColumnSlots(root);
            for (int i = 0; i < slots.Count; i++)
            {
                WardrobeTag slot = slots[i];
                if (slot == null || !slot.gameObject.activeSelf || IsBack(slot.Category))
                    continue;
                if (!string.IsNullOrEmpty(slot.Category))
                    return slot.Category;
            }

            return null;
        }

        static bool IsBack(string category)
        {
            return category == BackCategory || category == "返回";
        }

        static bool IsHairAlias(string name)
        {
            return name == "头发";
        }

        void ResolveRefs()
        {
            if (tag1Root == null)
                tag1Root = FindTagColumn("TagA", "Tag1");
            if (tag2Root == null)
                tag2Root = FindTagColumn("TagB", "Tag2");
            if (tag3Root == null)
                tag3Root = FindTagColumn("TagC", "Tag3");
            if (wardrobe == null)
                wardrobe = GetComponent<WardrobeController>();

            tag1Motion = EnsureColumnMotion(tag1Root);
            tag2Motion = EnsureColumnMotion(tag2Root);
            tag3Motion = EnsureColumnMotion(tag3Root);
            tag1Group = EnsureCanvasGroup(tag1Root);
            tag2Group = EnsureCanvasGroup(tag2Root);
            tag3Group = EnsureCanvasGroup(tag3Root);
        }

        UiTagColumnStaggerMotion EnsureColumnMotion(Transform root)
        {
            if (root == null)
                return null;
            var motion = root.GetComponent<UiTagColumnStaggerMotion>();
            if (motion == null)
                motion = root.gameObject.AddComponent<UiTagColumnStaggerMotion>();
            ApplyMotionSettings(motion);
            return motion;
        }

        void ApplyMotionSettings(UiTagColumnStaggerMotion motion)
        {
            if (motion == null)
                return;
            motion.StaggerDelay = staggerDelay;
            motion.ShownX = shownX;
            motion.HiddenX = hiddenX;
        }

        static CanvasGroup EnsureCanvasGroup(Transform root)
        {
            if (root == null)
                return null;
            var g = root.GetComponent<CanvasGroup>();
            if (g == null)
                g = root.gameObject.AddComponent<CanvasGroup>();
            g.alpha = 1f;
            g.interactable = true;
            return g;
        }

        static void SetColumnClickable(CanvasGroup group, bool on)
        {
            if (group == null)
                return;
            group.blocksRaycasts = on;
            group.interactable = true;
            group.alpha = 1f;
        }

        Transform FindTagColumn(params string[] names)
        {
            for (int i = 0; i < names.Length; i++)
            {
                Transform t = transform.Find(names[i]) ?? FindDeep(transform, names[i]);
                if (t != null)
                    return t;
            }

            return null;
        }

        static Transform FindDeep(Transform root, string name)
        {
            if (root == null)
                return null;
            if (root.name == name)
                return root;
            for (int i = 0; i < root.childCount; i++)
            {
                Transform found = FindDeep(root.GetChild(i), name);
                if (found != null)
                    return found;
            }

            return null;
        }
    }
}
